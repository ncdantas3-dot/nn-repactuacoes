# N & N Repactuações Inteligentes — Web v0.5

Sistema **local de homologação** para a análise de pedidos de repactuação, independente do N & N Conta Vinculada.

## Instalação no Windows

1. Instale Python 3.11+ e mantenha o computador atualizado.
2. Extraia o ZIP completo. Não execute diretamente de dentro do ZIP.
3. Execute `INICIAR_WINDOWS.bat` (instala as dependências em ambiente `.venv`).
4. Abra **http://127.0.0.1:8000**.
5. No primeiro acesso, cadastre organização, usuário administrador e uma senha forte.

O banco SQLite e os uploads são armazenados em `data/`. Não exclua essa pasta durante atualizações; faça backup antes de trocar a versão.

## Fluxo das cinco abas

- **Painel:** indicadores e avisos.
- **Processos:** cadastre empresa, contrato e regime jurídico.
- **Documentos:** baixe a planilha oficial de **Vigilante diurno (ARM.)** e importe como `vigente` (versão aprovada), `pedido` (empresa) e `cct`; documentos recebem SHA-256.
- **Auditoria:** informe o piso CCT conferido manualmente, execute os cálculos parciais e consulte **Reconciliação interna de totais**. Grupos com campos vazios permanecem incompletos. Você pode criar cenários documentados de retroativos e custos, sem deferimento automático.
- **Parecer:** exporte a minuta HTML em layout N & N para impressão. A minuta registra as pendências e alerta se as planilhas mudaram após a auditoria.

## Ferramentas auxiliares

- `BACKUP_WINDOWS.bat`: produz backup ZIP na pasta `backups/`, com hashes.
- `python backup_local.py`: executa backup local equivalente.
- `backup_local.restore_to_new_directory(arquivo_zip, pasta_nova)`: restauração de teste; **não** sobrescreve banco existente.
- `GET /api/users` e `POST /api/users`: operações de administrador para criar perfis `ADMIN`, `ANALISTA`, `REVISOR` e `CONSULTA`. A configuração pela interface ainda não existe.
- `GET /api/processes/{id}/reconciliation`: consulta JSON das inconsistências matemáticas e lacunas por grupo.
- `GET /api/processes/{id}/documents/{doc_id}/download`: baixa o original autenticado com verificação de integridade.

## Segurança e responsabilidade

**Não publique na internet e não utilize dados sensíveis reais no MVP.** Este software não homologa despesas nem substitui a análise jurídica e financeira do fiscal. A leitura automática de CCT, o cálculo independente integral dos seis módulos, o fechamento financeiro definitivo e a infraestrutura comercial permanecem pendentes.

Consulte `RELATORIO_FINAL_V05.md` para evidências, funcionalidades e bloqueadores de produção.

## Evolução v0.6 — fechamento automático por composição
A aba Auditoria agora inclui um demonstrativo que soma exclusivamente rubricas recalculadas, separa subtotais parciais e integrais e bloqueia preços globais com lacunas. Uma operação adicional tenta calcular M6 diretamente dos subtotais automáticos (sem redigitação), apenas quando M1–M5 estiverem completos, e sempre como cenário condicionado. A CCT passou a integrar a verificação de integridade das auditorias novas.

Consulte `RELATORIO_TECNICO_V06.md` e `GUIA_ATUALIZACAO_V06.md`.

## Atualização v0.7 — integridade documental e revisão

- Cada auditoria nova recebe manifesto e hash SHA-256 (`GET /api/processes/{id}/versions`).
- Análises com planilha ou CCT substituídas não podem receber novas decisões.
- Relatórios exibem apenas decisões, checklist, retroativos e fechamentos associados à versão atual; registros legados sem vínculo não são incorporados.
- Revisão: `POST /api/processes/{id}/review` com `run_id`, `action` (`ENVIAR_REVISAO` ou `DEVOLVER`) e `note`.
- A aprovação final permanece bloqueada: não existe motor integral e homologação jurídica concluída.

Leia `RELATORIO_EXECUTIVO_V07.md` e `GUIA_ATUALIZACAO_V07.md` antes de instalar.

## Atualização v0.8 — Recálculo financeiro por fontes independentes

A versão v0.8 adiciona o motor `independent_costing.py`, o dicionário completo de rubricas do modelo e APIs autenticadas de cálculo sem usar valores solicitados como base. Veja `GUIA_USO_V08.md` e `RELATORIO_VALIDACAO_V08.md`.

**Não é versão comercial homologada.** O motor depende de configuração documental, regras jurídicas verificadas e testes com o contrato efetivamente aprovado.

## Atualização v0.9 — Conferência de fórmulas GJ multiabas

- Na aba **Documentos**, selecione **Planilha GJ / evidência multiabas** e envie o XLSX da contratada.
- Após o upload, clique em **Conferir fórmulas** na linha do documento. A verificação é autenticada, isolada por organização e somente leitura.
- Para análise completa exportável em JSON, rode `python VALIDAR_GJ_2025.py arquivo.xlsx saida.json`.
- **Não** confunda a categoria `planilha_evidencia` com a planilha `vigente` aprovada: não há inferência de aprovação contratual.
- O verificador bloqueia referências de intervalo escalar entre abas e seus descendentes; o preço final fica `null` quando não é possível comprovar todas as bases.
- Consulte `RELATORIO_VALIDACAO_V09.md` e `EVIDENCIA_TESTES_V09.txt`.
- **A v0.9 não conclui o motor integral dos seis módulos e não está homologada comercialmente.**

## Incremento v1.0 — validação de regiões mescladas

O módulo `workbook_forensics.py` agora reconhece regiões mescladas via XML `mergeCells` e permite, estritamente para a faixa mesclada exata, obter o valor calculado na célula-âncora. Intervalos comuns permanecem bloqueados quando usados em contexto escalar sem operação verificável. Executar `python VALIDAR_GJ_2025.py planilha.xlsx saida.json` para gerar a memória exploratória. Ver `RELATORIO_VALIDACAO_V10.md` para testes e limitações; não utilizar os resultados como deferimento automático.

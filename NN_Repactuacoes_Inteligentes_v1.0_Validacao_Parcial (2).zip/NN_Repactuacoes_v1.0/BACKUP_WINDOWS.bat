@echo off
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (
 .venv\Scripts\python.exe backup_local.py
) else (
 python backup_local.py
)
if errorlevel 1 ( echo ERRO: Backup nao concluido. & pause & exit /b 1 )
echo Backup local concluido. Copie o ZIP para armazenamento externo protegido.
pause

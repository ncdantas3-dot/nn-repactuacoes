"""Motor deterministico demonstrativo: somente rubricas com base explicitamente fixada.
Nao configura homologacao de CCT, parametros tributarios ou contrato.
"""
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from typing import Any

D = lambda x: Decimal(str(x))
CENT = Decimal('0.01')
def money(x): return D(x).quantize(CENT, rounding=ROUND_HALF_UP)
def as_decimal(value):
    if value is None or value == '': return None
    try:
        if isinstance(value, str):
            value = value.strip().replace('R$', '').replace(' ', '')
            if ',' in value: value=value.replace('.','').replace(',','.')
        v=D(value)
        return v if v.is_finite() else None
    except (InvalidOperation,ValueError,TypeError): return None

# Nao se presume incidencias para M3-M6, noturno, ausencias e beneficios unitarios.
RULES = {
  16:('M1','Salario-base','piso_cct',None),
  21:('M1','Periculosidade','salario',21),
  25:('M2','13º salario','remuneracao',25),
  26:('M2','Ferias e adicional','remuneracao',26),
  30:('M2','INSS','remuneracao_mais_21',30),
  31:('M2','SESI / SESC','remuneracao_mais_21',31),
  32:('M2','SENAI / SENAC','remuneracao_mais_21',32),
  33:('M2','INCRA','remuneracao_mais_21',33),
  34:('M2','Salario-educacao','remuneracao_mais_21',34),
  35:('M2','FGTS','remuneracao_mais_21',35),
  36:('M2','RAT x FAP — hipotese documental','remuneracao_mais_21',36),
  37:('M2','SEBRAE','remuneracao_mais_21',37)
}
# Sem salario CCT confirmado e plano de incidencia aprovado nao se calcula nada.
def audit(vigente:dict, pedido:dict, cct_piso=None, explicit_rules=None):
    prev=vigente.get('rows',{}) if vigente else {}
    req=pedido.get('rows',{}) if pedido else {}
    floor=as_decimal(cct_piso)
    results=[]
    base1=None; base2=None; base3=None
    def getv(rows,r,col='E'):
        return as_decimal(rows.get(str(r),{}).get(col))
    salary=getv(req,16)
    for r in sorted(RULES):
        module,label,base,rate_row=RULES[r]
        requested=getv(req,r)
        previous=getv(prev,r)
        rate=getv(prev,rate_row,'D') if rate_row else None
        if r==21: rate=getv(prev,21,'C')
        if r==16:
            calc=money(floor) if floor is not None and floor>0 else None
            base1=calc
        elif base=='salario':
            calc=money(base1*rate) if base1 is not None and rate is not None else None
            if calc is not None: base1=money(base1+calc)
        elif base=='remuneracao':
            calc=money(base1*rate) if base1 is not None and rate is not None else None
            if r==25: base2=calc
            elif r==26: base2=money(base2+calc) if base2 is not None and calc is not None else None
        else:
            calc=money((base1+base2)*rate) if base1 is not None and base2 is not None and rate is not None else None
        if calc is None: status='PENDENTE'
        elif requested is None: status='SEM_VALOR_SOLICITADO'
        elif money(requested)==calc: status='CONFERENCIA_ARITMETICA'
        else: status='DIVERGENCIA_ARITMETICA'
        results.append({'row':r,'module':module,'rubrica':label,'vigente':str(money(previous)) if previous is not None else None,'solicitado':str(money(requested)) if requested is not None else None,'apurado':str(calc) if calc is not None else None,'aliquota':str(rate) if rate is not None else None,'formula':f'{base} x {rate}' if rate is not None else ('piso CCT validado manualmente' if r==16 else 'pendente'), 'status':status,'evidencia':f'Planilha vigente: {"C" if r==21 else "D"}{rate_row}' if rate_row else 'Piso da CCT informado pelo analista; sujeito a comprovacao'})
    # Demais linhas analiticas de custo nunca se classificam como aprovadas por omissao.
    excluded={20,22,27,38,45,48,50,51,52,53,54,62,71,75,78,79,80,88,89,90,95,96,103,104,106,107,108,109,110,111,112,113,114}
    for r in [17,18,19,40,41,42,43,44,47,57,58,59,60,61,65,66,67,68,69,70,74,83,84,85,86,87,93,94,98,99,102]:
        if r in RULES or r in excluded: continue
        data=req.get(str(r),{})
        label=data.get('B') or data.get('A') or f'Linha {r}'
        value=getv(req,r)
        results.append({'row':r,'module':('M1' if r<23 else 'M2' if r<55 else 'M3' if r<63 else 'M4' if r<81 else 'M5' if r<91 else 'M6'),'rubrica':str(label),'vigente':str(money(getv(prev,r))) if getv(prev,r) is not None else None,'solicitado':str(money(value)) if value is not None else None,'apurado':None,'aliquota':None,'formula':'Regra e base documental ainda nao homologadas','status':'PENDENTE','evidencia':'Requer contrato/CCT/memoria ou comprovante de incidencia'})
    # Extensao controlada: rubricas dos modulos 3-6 com BASE DECLARADA e alíquota da planilha vigente.
    # Declaracoes nao sao homologacao da base: o resultado e apenas reprodutibilidade matematica condicionada.
    # As rubricas M5 tipicamente sao valores unitarios; sem alíquota comprovada, permanecem pendentes.
    eligible=set([57,58,59,60,61,65,66,67,68,69,70,74,83,84,85,86,87,93,94,98,99,102])
    applied=[]
    seen=set()
    for item in (explicit_rules or []):
        row=int(item['row'])
        if row not in eligible or row in seen: raise ValueError('Regra de linha nao permitida ou duplicada')
        seen.add(row)
        rawbase=as_decimal(item.get('base_value'))
        evidence=str(item.get('evidence') or '').strip()
        description=str(item.get('base_description') or '').strip()
        if rawbase is None or rawbase<0 or rawbase>Decimal('100000000000') or len(evidence)<6 or len(description)<5:
            raise ValueError('Base e referencia documental obrigatorias para regra explicita')
        # Somente percentual EXPLÍCITO DA PLANILHA VIGENTE, nao campo de valor requerido.
        rate=None; position=None
        for col in ('D','C'):
            candidate=getv(prev,row,col)
            if candidate is not None and Decimal('0')<=candidate<=Decimal('1'):
                rate=candidate;position=f'{col}{row}';break
        entry=next((x for x in results if x['row']==row),None)
        if entry is None: continue
        if rate is None:
            entry['evidencia']='Alíquota não comprovada em C/D da planilha vigente; regra declarada não calculada'
            continue
        calc=money(rawbase*rate)
        entry['apurado']=str(calc)
        entry['aliquota']=str(rate)
        entry['formula']=f'ARRED({rawbase} x {rate}; 2) = {calc}'
        entry['evidencia']=f'Planilha vigente {position}; base declarada: {description}; comprovacao a verificar: {evidence}'
        entry['status']='CALCULO_CONDICIONADO'
        entry['base_declarada']=str(rawbase)
        entry['referencia_aliquota']=position
        applied.append({'row':row,'base_value':str(rawbase),'base_description':description,'evidence':evidence,'source':position,'rate':str(rate),'result':str(calc)})
    results.sort(key=lambda a:a['row'])
    counts={s:sum(x['status']==s for x in results) for s in ['CONFERENCIA_ARITMETICA','DIVERGENCIA_ARITMETICA','SEM_VALOR_SOLICITADO','PENDENTE','CALCULO_CONDICIONADO']}
    return {'rubricas':results,'resumo':counts,'valor_solicitado':str(money(getv(req,113))) if getv(req,113) is not None else None,'valor_matematicamente_apurado':None,'valor_proposto_deferimento':None,'conclusivo':False,'regras_declaradas':applied,'restricao':'Recálculo parcial: bases M3-M6, benefícios, intrajornada e eventuais reflexos não homologados. Nenhum total integral pode ser emitido.'}

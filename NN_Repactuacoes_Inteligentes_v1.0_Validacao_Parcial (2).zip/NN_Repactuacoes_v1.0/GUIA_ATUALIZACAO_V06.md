# Atualização para N & N Repactuações Web v0.6

1. Faça backup da pasta `data` da instalação anterior. Não sobrescreva nem apague seus arquivos.
2. Extraia o novo pacote em uma **pasta nova** `NN_Repactuacoes_Web_v0.6`.
3. Para migrar dados locais da v0.5, com o servidor anterior parado, copie a pasta `data` inteira da instalação antiga para a nova (incluindo `nn.sqlite3` e `uploads`). Preserve a cópia original como backup.
4. Com Python 3.11+ instalado, execute `INICIAR_WINDOWS.bat` no Windows, ou instale as dependências com `pip install -r requirements.txt` e rode `uvicorn app:app --host 127.0.0.1 --port 8000`.
5. Acesse `http://127.0.0.1:8000` e entre com o usuário existente. Se a base estiver vazia, realize o cadastro inicial.
6. Em **Auditoria**, selecione o processo e execute uma nova auditoria após anexar CCT e planilhas atualizadas. Clique em **Recalcular diagnóstico** na seção **Fechamento automático**.
7. Examine as rubricas bloqueadas. O subtotal parcial **não pode** ser usado como preço integral.
8. Para tentar o M6 automático, selecione a metodologia de lucro e clique em **Calcular M6 com subtotais automáticos**. Se faltarem rubricas, o sistema bloqueará a operação.
9. Para rodar os testes: `python -m pytest -q tests` (requer pytest).

**Proteção:** Não disponibilize esta instalação local na internet ou em computadores não confiáveis. Antes de qualquer uso decisório é necessário homologar as fórmulas e os parâmetros contratuais.

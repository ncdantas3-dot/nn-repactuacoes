@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PYTHON=py -3") else (set "PYTHON=python")
if not exist .venv ( %PYTHON% -m venv .venv )
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if errorlevel 1 (echo Falha ao instalar as dependencias. & pause & exit /b 1)
echo.
echo Abra no navegador: http://127.0.0.1:8000
echo Use apenas localmente com dados ficticios.
echo.
python -m uvicorn app:app --host 127.0.0.1 --port 8000
pause

# N & N Repactuações Inteligentes — Relatório técnico v0.8

**Status:** implementação incremental testada localmente; **NÃO HOMOLOGADO PARA COMERCIALIZAÇÃO OU DEFERIMENTO ADMINISTRATIVO**.

## Escopo implementado

- Novo `independent_costing.py`, motor determinístico em `Decimal` com as operações autorizadas `SOURCE_AMOUNT`, `DOCUMENTED_AMOUNT`, `RATE`, `SUM` e `MULTIPLY`; não executa fórmulas arbitrárias.
- Regras com identificador, módulo, rubrica, evidência, origem, dependências, resultado e diferença frente ao valor solicitado; o **valor solicitado nunca alimenta o recálculo**.
- Detecção de dependências ausentes/circulares, valores inválidos, rubricas repetidas, dupla contagem em somatórios e falta de componentes exigidos no modelo Vigilante diurno (ARM.).
- Conclusão financeira integral bloqueada quando falta qualquer rubrica do dicionário, quando há valor não resolvido, quando o somatório final é inválido ou quando o nó final deixa rubrica analítica fora do cálculo.
- APIs `GET /api/independent-costing/template`, `POST /api/processes/{pid}/independent-costing` e `GET /api/processes/{pid}/independent-costing`.
- Memória armazenada em `independent_costing_runs`, separada por organização/processo/versão da auditoria com hash das regras. Invalidação de consulta de resultados depois de substituição de planilha ou CCT.
- Tela adicional **dentro de Auditoria**, sem criar sexta aba, para editar regras documentadas, obter dicionário completo, recalcular e visualizar memória comparativa.
- Inclusão da última memória independente da **mesma auditoria** na minuta de relatório, se a fonte continuar atual.

## Testes executados

- `pytest -q --disable-warnings`: **61 aprovados**, incluindo os 47 da v0.7 e 14 novos testes (aritmética, fonte do valor, API, autenticação, substituição da CCT, integridade e bloqueios).
- Verificação de compilação Python e verificação de sintaxe do JavaScript da aplicação: aprovadas.
- Não realizado teste completo de navegador, pentest, carga, PostgreSQL, infraestrutura hospedada ou validação centavo a centavo do caso GJ com contrato efetivamente aprovado.

## Limitações críticas

1. **O motor independente exige configuração e validação das fontes por rubrica.** O sistema não consegue extrair sozinho todas as fórmulas da planilha original, nem comprovar sozinho que a planilha vigente corresponde à última versão aprovada.
2. O dicionário de rubricas gerado está intencionalmente **sem valores**. Para executar o recálculo é necessário fornecer as regras e evidências de origem, sem presumir custo zero para células vazias.
3. A leitura da CCT continua parcialmente manual; o registro de uma referência de documento não significa conferência jurídica independente da cláusula.
4. A `reconciliation.py` legada ainda depende de linhas fixas. A nova apuração não utiliza os totais da reconciliação como base, mas o módulo legado deverá ser refatorado em versão posterior.
5. Não há homologação global de todos os Módulos 1 a 6 nem de cenários de postos/categorias diferentes; o resultado permanece **condicionado** mesmo quando todas as regras configuradas estão completas.
6. Segurança comercial (PostgreSQL, hardening, identidade multicliente, backups externos, recuperação testada) continua pendente.
7. O preço final de uma versão configura a soma explicitamente proposta pelo analista; a rastreabilidade matemática é testada, mas a elegibilidade, as premissas e as incidências dependem de validação contratual e jurídica.

## Critério para homologação futura

Comprovar, com as **planilhas originais efetivamente aprovadas e a CCT aplicável**, que cada rubrica possui fórmula, base, incidência, alíquota, valor, evidência e testes independentes; demonstrar preço por trabalhador e por posto, completo, reproduzível e reconciliante. Depois, testar segurança, histórico, assinatura e backups em ambiente de produção.

"""Matriz versionada de incidência para o modelo Vigilante diurno (ARM.).
Não certifica o regime jurídico nem a metodologia da proposta aprovada.
"""
from decimal import Decimal
from engine import as_decimal,money

MATRIX_VERSION='NN-INC-0.3.0'
# Cada regra explicita a base financeira e a célula documental de alíquota.
MATRIX = [
 {'row':16,'module':'M1','name':'Salário-base','base':'piso_cct','source':'CCT conferida manualmente','rate_cell':None,'deps':[]},
 {'row':21,'module':'M1','name':'Periculosidade','base':'salario_base','source':'Planilha vigente C21','rate_cell':'C21','deps':[16]},
 {'row':25,'module':'M2','name':'13º salário','base':'remuneracao_integral','source':'Planilha vigente D25','rate_cell':'D25','deps':[16,17,18,19,21]},
 {'row':26,'module':'M2','name':'Férias + 1/3','base':'remuneracao_integral','source':'Planilha vigente D26','rate_cell':'D26','deps':[16,17,18,19,21]},
 *[{'row':i,'module':'M2','name':name,'base':'remuneracao_mais_submodulo_2_1','source':f'Planilha vigente D{i}','rate_cell':f'D{i}','deps':[16,17,18,19,21,25,26]} for i,name in [(30,'INSS'),(31,'SESI/SESC'),(32,'SENAI/SENAC'),(33,'INCRA'),(34,'Salário-educação'),(35,'FGTS'),(36,'RAT/FAP'),(37,'SEBRAE')]],
 *[{'row':i,'module':'M3','name':name,'base':'remuneracao_mais_submodulo_2_1','source':f'Planilha vigente D{i} (incidência contratual a confirmar)','rate_cell':f'D{i}','deps':[16,17,18,19,21,25,26]} for i,name in [(57,'Aviso prévio indenizado'),(58,'FGTS sobre aviso indenizado'),(59,'Aviso prévio trabalhado'),(60,'Encargos sobre aviso trabalhado'),(61,'Multa sobre FGTS')]],
 *[{'row':i,'module':'M4','name':name,'base':'base_reposicao_nao_documentada','source':f'Planilha vigente D{i}; conferir memória aprovada','rate_cell':f'D{i}','deps':[]} for i,name in [(65,'Substituição de férias'),(66,'Ausências legais'),(67,'Licença-paternidade'),(68,'Acidente de trabalho'),(69,'Licença-maternidade')]],
 *[{'row':i,'module':'M5','name':name,'base':'valor_unitario_documentado','source':f'Planilha contratual E{i}; comprovação específica','rate_cell':None,'deps':[]} for i,name in [(83,'Uniformes'),(84,'Materiais'),(85,'Equipamentos'),(86,'Reciclagem'),(87,'Aprendizagem')]],
 {'row':93,'module':'M6','name':'Custos indiretos','base':'total_integral_modulos_1_a_5','source':'Planilha vigente C93','rate_cell':'C93','deps':[]},
 {'row':94,'module':'M6','name':'Lucro','base':'custo_mais_indiretos','source':'Planilha vigente C94','rate_cell':'C94','deps':[93]},
 *[{'row':i,'module':'M6','name':name,'base':'faturamento_por_dentro','source':f'Planilha vigente D{i}; conferir regime e município','rate_cell':f'D{i}','deps':[]} for i,name in [(98,'PIS'),(99,'COFINS'),(102,'ISS')]]
]

def analyze_matrix(vigente,pedido,results):
    """Resolve apenas fórmulas com todas as dependências e fontes necessárias.
    Linhas M3 são cenários aritméticos condicionados, jamais aprovação jurídica.
    """
    prev=vigente.get('rows',{}) if vigente else {}
    req=pedido.get('rows',{}) if pedido else {}
    by={x['row']:x for x in results['rubricas']}
    def v(rows,row,col='E'):
        return as_decimal(rows.get(str(row),{}).get(col))
    # Uma célula vazia não prova custo zero. Exigir zero explícito nas rubricas restantes de M1.
    extra_m1=[17,18,19]
    verified_m1=all(v(req,r) == Decimal('0') for r in extra_m1)
    reliable_base=all(by.get(r,{}).get('apurado') is not None for r in (16,21,25,26))
    base=None
    if verified_m1 and reliable_base:
        base=sum((as_decimal(by[r]['apurado']) for r in (16,21,25,26)),Decimal('0'))
    report=[]
    for rule in MATRIX:
        row=rule['row']; rate=None
        if rule['rate_cell']:
            key=rule['rate_cell'];rate=v(prev,int(key[1:]),key[0])
        entry=by.get(row)
        can_base=base is not None
        if rule['module']=='M3' and row in (57,58,59,60,61):
            blockers=[]
            if not verified_m1: blockers.append('Informe explicitamente E17, E18 e E19 (inclusive zero); campos vazios não comprovam ausência de custo')
            if not reliable_base: blockers.append('Salário, periculosidade, 13º e férias precisam de recálculo documentado')
            if rate is None or not Decimal('0')<=rate<=Decimal('1'):blockers.append(f'Alíquota vigente {rule["rate_cell"]} ausente/inválida')
            if not blockers:
                amount=money(base*rate)
                # Cálculo automático condicionado: modalidade, incidência e alíquota exigem conferência jurídica.
                if entry and entry.get('status')=='PENDENTE':
                    entry.update(apurado=str(amount),aliquota=str(rate),base_calculo=str(base),formula=f'ARRED((E16 + E21 + E25 + E26) × {rate}; 2) = {amount}',evidencia=f'{rule["source"]}; base M1 + submódulo 2.1. Requer homologação contratual.',status='CALCULO_CONDICIONADO_AUTO',referencia_aliquota=rule['rate_cell'])
                reason='Base composta conferida aritmeticamente; incidência jurídica e contrato ainda sujeitos à validação'
                status='CALCULO_CONDICIONADO_AUTO'
            else:
                reason='; '.join(blockers);status='BLOQUEADO'
        elif entry and entry.get('status') not in ('PENDENTE',):
            status=entry['status']; reason='Memória disponível no recálculo parcial; conferir se todas as incidências estão provadas'
        else:
            status='BLOQUEADO';reason='Base de incidência não reconstruída independentemente ou documentação insuficiente'
        report.append({**rule,'aliquota_vigente':str(rate) if rate is not None else None,'status_matriz':status,'motivo':reason,'base_apurada':str(base) if rule['module']=='M3' and can_base else None})
    results['rubricas'].sort(key=lambda x:x['row'])
    results['resumo']={s:sum(x['status']==s for x in results['rubricas']) for s in sorted({x['status'] for x in results['rubricas']})}
    results['matriz_incidencias']={'version':MATRIX_VERSION,'regras':report,'remuneracao_sem_adicionais_pendentes':verified_m1,'base_rescisao_condicionada':str(base) if base is not None else None,'aviso':'Cálculos condicionados não constituem homologação de base jurídica, percentuais ou pedido.'}
    return results

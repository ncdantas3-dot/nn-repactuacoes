"""Fechamento aritmético condicionado dos módulos 4–6.
As bases são DECLARAÇÕES do analista com evidência textual; não são homologação.
Regra do lucro parametrizada e não presumida como a proposta original.
"""
from decimal import Decimal
from engine import money, as_decimal

MODULES=('M1','M2','M3','M4','M5')
COST_ROWS={'M4':(65,66,67,68,69,70,74),'M5':(83,84,85,86,87),'M6':(93,94,98,99,102)}

def diagnostics(run):
    grouped={}
    for module in ('M1','M2','M3','M4','M5','M6'):
        values=[x for x in run.get('rubricas',[]) if x.get('module')==module]
        unresolved=[{'linha':x['row'],'rubrica':x['rubrica'],'motivo':x['status']} for x in values if x.get('apurado') is None]
        conditional=[x['row'] for x in values if 'CONDICIONADO' in x.get('status','')]
        grouped[module]={'rubricas':len(values),'pendentes':unresolved,'condicionadas':conditional,'situacao':'INCOMPLETO' if unresolved else 'CALCULADO_SOB_CONDICOES'}
    return {'modulos':grouped,'integralmente_homologado':False,'motivo':'Conferência dos cálculos não prova regularidade contratual ou jurídica.'}

def closing_m6(vigente, declared, evidences, method):
    """M6: valor de referência derivado exclusivamente de cinco subtotais DECLARADOS,
    nunca dos valores pedidos. PIS/COFINS/ISS alíquotas documentais e não validadas.
    method: 'sobre_custo_mais_indiretos' ou 'sobre_custo' (contratual a confirmar).
    """
    if method not in ('sobre_custo_mais_indiretos','sobre_custo'):
        raise ValueError('Metodologia de lucro não reconhecida')
    values={}
    for module in MODULES:
        raw=declared.get(module)
        value=as_decimal(raw)
        if value is None or not value.is_finite() or value < 0 or value>Decimal('10000000000'):
            raise ValueError('Subtotal não informado/inválido para '+module)
        ev=str(evidences.get(module,'')).strip()
        if len(ev)<10:raise ValueError('Evidência de subtotal obrigatória: '+module)
        if value != money(value):raise ValueError('Subtotal deve ter no máximo duas casas decimais: '+module)
        values[module]=value
    rows=vigente.get('rows',{})
    def rate(cell):
        key=int(cell[1:]); raw=rows.get(str(key),{}).get(cell[0]); d=as_decimal(raw)
        if d is None or not d.is_finite() or d<0 or d>=1:
            raise ValueError('Alíquota ausente ou inválida na planilha vigente: '+cell)
        return d
    rates={c:rate(c) for c in ('C93','C94','D98','D99','D102')}
    tax=rates['D98']+rates['D99']+rates['D102']
    if tax>=Decimal('1'):raise ValueError('Tributos totais inviabilizam gross-up')
    base=money(sum(values.values(),Decimal('0')))
    indirect=money(base*rates['C93'])
    profitbase=base+indirect if method=='sobre_custo_mais_indiretos' else base
    profit=money(profitbase*rates['C94'])
    net=base+indirect+profit
    billed=money(net/(Decimal('1')-tax))
    taxamount=money(billed-net)
    details={k:str(v) for k,v in values.items()}
    return {'status':'CENARIO_ARITMETICO_CONDICIONADO','valor_proposto_deferimento':None,
      'metodologia_lucro':method,'subtotais_declarados':details,'referencias_subtotais':evidences,
      'taxas_fonte':{c:str(r) for c,r in rates.items()},'custo_modulos_1_a_5':str(base),
      'indiretos':str(indirect),'base_lucro':str(profitbase),'lucro':str(profit),
      'base_sem_tributos':str(net),'aliquota_total_tributos':str(tax),
      'tributos_por_dentro':str(taxamount),'preco_cenario':str(billed),
      'memoria':[
        f'Custo M1+M2+M3+M4+M5 = {base}',
        f'Indiretos = ARRED({base} × {rates["C93"]};2) = {indirect}',
        f'Lucro = ARRED({profitbase} × {rates["C94"]};2) = {profit}',
        f'Preço = ARRED(({base}+{indirect}+{profit})/(1-{tax});2) = {billed}',
        f'Tributos por dentro = {billed} - {net} = {taxamount}'
      ],
      'pendencias':['Comprovar que cada subtotal declarado deriva de recálculo independente integral',
       'Conferir bases de lucro/indiretos com a última proposta aprovada',
       'Comprovar regime tributário e alíquotas efetivamente aplicáveis',
       'Validar CCT, quantitativos, elegibilidade e parecer jurídico'],
      'aviso':'Cenário aritmético baseado em DECLARAÇÕES; não é resultado auditado integral nem autorização de pagamento.'}

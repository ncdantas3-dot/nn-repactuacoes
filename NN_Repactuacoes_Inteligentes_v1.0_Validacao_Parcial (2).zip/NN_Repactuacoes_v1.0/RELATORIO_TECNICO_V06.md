# N & N Repactuações Inteligentes — Relatório técnico v0.6

## Objetivo e escopo
A versão 0.6 complementa a v0.5 com **fechamento automático e conservador dos componentes financeiros já apurados**, sem exigir a digitação de subtotais para a conferência da cadeia M1–M5.

## Implementações verificáveis
- `automatic.py`: lista explícita de rubricas analíticas por M1, M2.1, M2.2, M2.3, M2.4, M3, M4 e M5. Linhas de subtotal e preço final não entram novamente na soma.
- Para cada grupo: quantidade de rubricas previstas, quantidade de rubricas recalculadas, subtotal **parcial**, subtotal **completo** (somente se não há lacunas), rubricas condicionadas e lista de bloqueios.
- M2 é composto exclusivamente por M2.1+M2.2+M2.3+M2.4; não se somam os quadros-resumo novamente.
- Novo endpoint autenticado `GET /api/processes/{id}/automatic-closing`, limitado à organização do usuário, recusa auditorias desatualizadas e responde com memória por grupo.
- Novo endpoint `POST /api/processes/{id}/automatic-m6`, que usa somente subtotais do recálculo, exige cadeia completa e metodologia de lucro selecionada. Seu resultado é **cenário condicionado**, jamais deferimento.
- Inclusão do hash da CCT nas fontes das novas auditorias; mudanças da CCT invalidam os resultados, assim como mudanças das duas planilhas.
- Interface com novo quadro de completude automática dentro da aba Auditoria, preservando as cinco abas e os cenários antigos.
- Nenhuma coluna de valor solicitado substitui valores calculados ausentes, e células vazias não viram zero.

## Testes e evidências
- `python -m pytest -q tests`: **44 testes passaram** em execução local.
- Entre eles: não somar subtotais duplicados, bloquear rubricas não calculadas, rejeitar subcentavos, manter valores condicionados sem homologação, determinar sempre o mesmo resultado, impedir M6 automático parcial, reconhecer mudança da CCT e bloquear acesso a dados de outras organizações pelas regras existentes.
- `python -m compileall`: compilação Python sem erros.
- `node --check` no JavaScript embutido: sintaxe aprovada.
- **Não foi executada homologação financeira integral com os documentos contratuais aprovados, nem teste de implantação pública.**

## Limitações e riscos remanescentes (bloqueadores comerciais)
1. O motor `engine.py` não recalcula integralmente todas as rubricas de M1–M5; benefícios unitários, adicionais e custos específicos ainda podem permanecer sem base matemática documentada.
2. A metodologia das rubricas M3/M4 depende da comprovação da planilha originalmente aprovada; resultados condicionados não possuem aprovação automática.
3. O M6 automático fica bloqueado até o fechamento de todas as rubricas M1–M5 e exige metodologia de lucro escolhida expressamente.
4. A CCT é anexada com hash, mas a interpretação de cláusulas, datas e pisos ainda é manual.
5. A conferência de percentuais no modelo não prova que são juridicamente admissíveis para o contrato.
6. Persistência e autenticação ainda utilizam uma arquitetura local em SQLite; a migração PostgreSQL, controles de produção e backup externo não estão homologados.
7. A UI possui integração funcional, mas ainda necessita testes ponta a ponta em navegador e validação operacional com usuário fiscal.
8. A emissão de parecer permanece **MINUTA**; não existe deferimento automatizado autorizado.

## Resultado
**Versão funcional para evolução e testes locais, não comercialmente homologada.** O fechamento automático substitui digitação de subtotais na visão de completude e permite M6 apenas em cenários matematicamente completos; não declara fechamento financeiro onde restam pendências.

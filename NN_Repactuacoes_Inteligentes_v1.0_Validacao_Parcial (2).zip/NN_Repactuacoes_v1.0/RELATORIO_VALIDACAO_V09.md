# N & N Repactuações Inteligentes — Verificação documental v0.9
**Data:** 17/11/2026  
**Escopo:** continuação incremental do projeto web v0.8, com auditoria forense da planilha GJ 2025 e CCT AC000018/2025.  
**Decisão:** **NÃO HOMOLOGADO para preço final por posto, deferimento ou produção comercial**.

## 1. Implementações realizadas

1. Novo módulo `workbook_forensics.py`: lê fórmulas e cache XLSX diretamente do contêiner Office Open XML, de forma somente leitura, preservando o original. Usa `Decimal`, `ROUND_HALF_UP` e um subconjunto controlado de expressões; não executa macros ou código arbitrário.
2. Exibe separadamente a **fórmula**, o **resultado recalculado** e o **valor armazenado**; o cache não entra como base do cálculo da fórmula.
3. Bloqueia intervalos de duas colunas usados como expressão escalar, a exemplo de `'Material e uniforme'!H13:I13`, e bloqueia os cálculos descendentes dependentes dessa expressão. Não presume soma ou interseção implícita.
4. Detecta automaticamente a divergência `D25 = 1/12` vs cache e seu primeiro reflexo `E25`; detecta conflito `C18=25%` vs `20%` literal na fórmula `E18` nas duas categorias noturnas.
5. Nova categoria documental `planilha_evidencia`, para carregar a pasta GJ multiabas **sem fingir que ela é o modelo estruturado de aba única**; mantém upload, SHA-256, download e segregação por organização.
6. API autenticada `GET /api/processes/{pid}/documents/{doc_id}/formula-audit`, com validação de proprietário, integridade do arquivo e retorno da memória documental.
7. Na aba **Documentos**, botão **Conferir fórmulas** para XLSX; preserva as cinco abas principais.
8. Script `VALIDAR_GJ_2025.py`, executável localmente com qualquer XLSX.

## 2. Testes executados

`pytest -q`: **69 testes aprovados**, sendo 61 testes já existentes e 8 novos testes da v0.9, incluindo execução autenticada do endpoint. `python -m py_compile` e `node --check`: aprovados.

A suíte testou interpretação de `1/12`, diferença de R$ 0,07 no 13º para uma base de R$ 2.130,88, bloqueio de referência ambígua entre abas e seus descendentes, integridade SHA-256, precisão do `ROUND` negativo, rejeição de referências externas e funções não suportadas, acesso autenticado e não exposição de documentos inexistentes.

## 3. Resultado sobre a planilha efetivamente enviada

**Documento:** `Planilha de Custos 2025 - GJ(1).xlsx`  
**SHA-256:** `f9fff22301107faf59f97cc4ca71b75cba5ab40e87d32021dfd6e37d9ac75956`.

Total de **514 células com fórmulas** em **todas as abas da pasta** (escopo ampliado em relação às 483 fórmulas das seis abas operacionais da auditoria anterior):

| Resultado | Quantidade | Significado |
|---|---:|---|
| Confere com cache na precisão de comparação | 206 | Não demonstra validade jurídica nem da fórmula |
| Diverge do cache | 151 | Pode envolver arredondamento, versão de cálculo ou diferença originária; não representa automaticamente erro de cobrança |
| Pendente: fórmula/descendente | 150 | Não há resultado independente confiável com as funções ou dependências disponíveis |
| Pendente: intervalo escalar entre abas | 7 | Exige definir/validar a semântica Excel do intervalo |
| **Total** | **514** | Inclui abas auxiliares |

### Achados financeiros reproduzidos
- **GJ-001:** as quatro abas regulares de vigilante têm `D25 = 1/12` com cache `0,0833`; o primeiro reflexo `E25` é R$ 0,07 no diurno e R$ 0,09 no noturno. Esses valores são **diferenças entre recálculo da fórmula e cache**, não propostas de glosa.
- **GJ-002:** nos dois vigilantes noturnos, `C18=25%` e `E18` contém `20%` literal. Confirmar se os parâmetros exibidos refletem contrato, CCT e jornada; não concluir o percentual devido apenas pelo confronto.
- **Cadeia de Módulo 5 e preço:** `E83` utiliza intervalo `'Material e uniforme'!H13:I13`, cuja interpretação escalar pode variar; o motor v0.9 **bloqueia `E83` e todos os preços que dela dependam**. Assim, `E113/E114` permanece sem recálculo conclusivo.

### Fontes CCT identificadas documentalmente
- AC000018/2025; vigência de 01/03/2025 a 28/02/2027, data-base 01/03 (cláusula 1ª, p. 1).
- Vigilante: salário-base de R$ 1.639,14 (cláusula 3ª, p. 2).
- Adicional noturno: cálculo indicado com 20% e divisor 220, com exemplos de 7 horas (cláusula 9ª, p. 5).
- Alimentação: R$ 36,00/dia de efetivo serviço em 2025 (cláusula 11ª, p. 6).
- Saúde: R$ 30,00/mês em 2025 (cláusula 12ª, p. 6).
- Aprendizagem: R$ 63,00 em cláusula 21ª, §13 (p. 10), frente à referência 22ª na planilha.
- Intrajornada: referência 38ª na CCT (p. 19), frente à referência 31ª na planilha.

**A conferência da CCT é documental/manual nesta versão**; não foi implementado um leitor jurídico automático homologado.

## 4. Bloqueadores que continuam pendentes

1. Confirmar a última planilha contratualmente aprovada; não assumir que a planilha GJ 2024 disponível no histórico tenha essa qualidade.
2. Formalizar a semântica de fórmulas com intervalos entre abas no motor, conforme a versão efetiva do Excel, sem presumir soma.
3. Homologar as fórmulas de todas as rubricas e bases de incidência dos Módulos 1 a 6 com documentos oficiais, inclusive número de trabalhadores por posto e cálculos por competência.
4. Documentar a metodologia contratual de arredondamento (incluindo a diferença entre 8,33% e 1/12).
5. Completar parser e leitura de CCT, parâmetros de admissibilidade e decisões do revisor.
6. Completar infraestrutura de produção: PostgreSQL, autenticação multicliente homologada, backup externo e testes ponta a ponta.

## 5. Regra inegociável de homologação

> Só considerar **PREÇO POR POSTO RECONSTRUÍDO** quando todas as rubricas aplicáveis tiverem resultado, origem verificável, dependências fechadas, metodologia de incidência aceita e ausência de bloqueios críticos. O total da empresa **nunca** deve ser utilizado para preencher a lacuna, e a mera coincidência dos totais não prova conformidade.

**Resultado da GJ nesta versão:** `preco_por_posto_reconstruido = null`, `deferimento = null`, `aprovado_financeiramente = false`.

## 6. Reproduzir

Na pasta do sistema, execute:

```bash
python VALIDAR_GJ_2025.py "Planilha de Custos 2025 - GJ(1).xlsx" resultado.json
pytest -q
```

A planilha é inspecionada em modo somente leitura, sem modificações. O processo de homologação jurídica e comercial continua pendente.

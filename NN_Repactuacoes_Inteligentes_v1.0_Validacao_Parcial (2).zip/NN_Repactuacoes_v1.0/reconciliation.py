"""Conferência de consistência interna das planilhas; não é auditoria independente da elegibilidade."""
from decimal import Decimal
from engine import as_decimal, money
# Somente valores analíticos. Subtotais nunca entram como componentes.
GROUPS = {
    'M1': {'items':[16,17,18,19,21], 'total':22},
    'M2.1': {'items':[25,26], 'total':27},
    'M2.2': {'items':list(range(30,38)), 'total':38},
    'M2.3': {'items':[40,41,42,43,44], 'total':45},
    'M2.4': {'items':[47], 'total':48},
    'M2': {'items':[50,51,52,53], 'total':54},
    'M3': {'items':[57,58,59,60,61], 'total':62},
    'M4.1': {'items':[65,66,67,68,69,70], 'total':71},
    'M4': {'items':[78,79], 'total':80},
    'M5': {'items':[83,84,85,86,87], 'total':88},
    'M1-M5': {'items':[106,107,108,109,110], 'total':111},
    'M6': {'items':[93,94,98,99,102], 'total':104},
    'PRECO': {'items':[111,112], 'total':113},
}
# Cabeçalhos e totais possuem variações entre planilhas. Se um item não for provado,
# o grupo deve permanecer parcial — não completar silenciosamente com zero.
def reconcile(doc):
    rows=doc.get('rows',{})
    result=[]
    for key, spec in GROUPS.items():
        items=[]; missing=[]; invalid=[]
        for n in spec['items']:
            raw=rows.get(str(n),{}).get('E')
            if raw is None or str(raw).strip()=='': missing.append(n);continue
            v=as_decimal(raw)
            if v is None or not v.is_finite():invalid.append(n);continue
            items.append({'linha':n,'valor':str(money(v))})
        total_raw=rows.get(str(spec['total']),{}).get('E')
        total=as_decimal(total_raw)
        if total is not None and not total.is_finite(): total=None
        calculated=money(sum((Decimal(x['valor']) for x in items),Decimal('0'))) if not missing and not invalid else None
        delta=money(total-calculated) if total is not None and calculated is not None else None
        state=('INCONSISTENTE' if delta is not None and abs(delta)>Decimal('0.01') else 'CONSISTENTE_ARITMETICAMENTE') if delta is not None else 'INCOMPLETO'
        result.append({'grupo':key,'componentes':items,'faltantes':missing,'invalidos':invalid,'linha_total':spec['total'],
                       'total_informado':str(money(total)) if total is not None else None,
                       'soma_calculada':str(calculated) if calculated is not None else None,
                       'diferenca':str(delta) if delta is not None else None,'situacao':state})
    return {'grupos':result,'inconsistencias':sum(x['situacao']=='INCONSISTENTE' for x in result),
            'pendencias':sum(x['situacao']=='INCOMPLETO' for x in result),
            'aviso':'Conferência aritmética de valores informados. Não demonstra base de cálculo nem admissibilidade jurídica. Linhas opcionais vazias não são presumidas zero.'}

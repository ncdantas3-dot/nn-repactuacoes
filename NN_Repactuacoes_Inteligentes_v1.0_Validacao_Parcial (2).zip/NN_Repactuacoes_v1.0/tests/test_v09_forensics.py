"""Conjunto portátil de regressão do analisador XLSX; não requer dados sigilosos GJ."""
import io,zipfile,xml.etree.ElementTree as ET
from decimal import Decimal
import pytest
from workbook_forensics import inspect_workbook, Evaluator, Blocked
from test_system import authorized,client

MAIN='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'

def fixture_book(tmp_path):
    p=tmp_path/'exemplo.xlsx'
    wb=f'''<workbook xmlns="{MAIN}" xmlns:r="{REL}"><sheets><sheet name="Vigilante diurno (ARM.)" sheetId="1" r:id="rId1"/><sheet name="Material e uniforme" sheetId="2" r:id="rId2"/></sheets></workbook>'''
    rel='''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"/><Relationship Id="rId2" Target="worksheets/sheet2.xml" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"/></Relationships>'''
    sh=f'''<worksheet xmlns="{MAIN}"><sheetData><row r="22"><c r="E22"><v>2130.88</v></c></row><row r="25"><c r="D25"><f>1/12</f><v>0.0833</v></c><c r="E25"><f>ROUND(E22*D25,2)</f><v>177.50</v></c></row><row r="83"><c r="E83"><f>'Material e uniforme'!H13:I13</f><v>87.34</v></c></row><row r="88"><c r="E88"><f>E83+10</f><v>97.34</v></c></row></sheetData></worksheet>'''
    material=f'''<worksheet xmlns="{MAIN}"><sheetData><row r="13"><c r="H13"><v>50</v></c><c r="I13"><v>37.34</v></c></row></sheetData></worksheet>'''
    with zipfile.ZipFile(p,'w') as z:
        for name,data in [('xl/workbook.xml',wb),('xl/_rels/workbook.xml.rels',rel),('xl/worksheets/sheet1.xml',sh),('xl/worksheets/sheet2.xml',material)]:z.writestr(name,data)
    return p

def test_formula_is_source_and_cached_rate_is_not(tmp_path):
    x=inspect_workbook(fixture_book(tmp_path))
    d={f['celula']:f for f in x['celulas'] if f['aba']=='Vigilante diurno (ARM.)'}
    assert d['D25']['recalculado']=='0.083333'
    assert d['E25']['recalculado']=='177.57'
    assert d['E25']['diferenca_monetaria']=='0.07'
    assert any(f['codigo']=='GJ-001' for f in x['achados_relevantes'])

def test_cross_sheet_ambiguous_range_blocks_downstream_price(tmp_path):
    x=inspect_workbook(fixture_book(tmp_path))
    d={f['celula']:f for f in x['celulas'] if f['aba']=='Vigilante diurno (ARM.)'}
    assert d['E83']['status']=='PENDENTE_FORMULA'
    assert d['E83']['motivo']=='INTERVALO_ESCALAR_NAO_MESCLADO'
    assert d['E88']['status']=='PENDENTE_FORMULA'
    assert d['E88']['recalculado'] is None
    assert x['preco_por_posto_reconstruido'] is None
    assert x['deferimento'] is None

def test_hash_and_sheets(tmp_path):
    p=fixture_book(tmp_path)
    x=inspect_workbook(p)
    import hashlib
    assert x['sha256']==hashlib.sha256(p.read_bytes()).hexdigest()
    assert len(x['folhas'])==2
    assert x['formulas_inspecionadas']==4

def test_decimal_negative_rounding_excel_style():
    e=Evaluator({'A':{}})
    assert e.formula('A','ROUND(-1.005,2)')==Decimal('-1.01')

def test_external_reference_not_executed():
    e=Evaluator({'A':{}})
    with pytest.raises(Blocked):e.formula('A','[remote.xlsx]Folha!A1')

def test_unsupported_functions_blocked():
    e=Evaluator({'A':{}})
    with pytest.raises(Blocked):e.formula('A','INDIRECT("A1")')

def test_rate_not_misclassified_as_monetary_error(tmp_path):
    x=inspect_workbook(fixture_book(tmp_path))
    d={f['celula']:f for f in x['celulas']}
    assert d['D25']['status']=='DIVERGE_CACHE'
    assert d['D25']['diferenca_monetaria']=='0.00'

def test_authenticated_document_forensics_endpoint(authorized,tmp_path):
    c,h=authorized
    pid=c.post('/api/processes',headers=h,json={'company':'Evidencias GJ','contract':'009'}).json()['id']
    raw=fixture_book(tmp_path).read_bytes()
    u=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'planilha_evidencia'},
       files={'file':('caso_multiplas_abas.xlsx',raw,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')})
    assert u.status_code==200,u.text
    doc=u.json()['id']
    endpoint=f'/api/processes/{pid}/documents/{doc}/formula-audit'
    assert c.get(endpoint).status_code==401
    report=c.get(endpoint,headers=h)
    assert report.status_code==200,report.text
    assert report.json()['formulas_inspecionadas']==4
    assert report.json()['preco_por_posto_reconstruido'] is None
    assert c.get(f'/api/processes/{pid}/documents/{doc+10000}/formula-audit',headers=h).status_code==404

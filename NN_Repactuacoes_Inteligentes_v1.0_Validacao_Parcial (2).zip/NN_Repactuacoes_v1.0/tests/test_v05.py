import hashlib,io,sys,os,json,sqlite3,zipfile
from pathlib import Path
from fastapi.testclient import TestClient
from decimal import Decimal
import pytest
from test_system import authorized,client,BASE
from app import DB,app
from reconciliation import reconcile
from engine import as_decimal
from backup_local import create_backup,verify_backup

def test_reconciliation_exact_and_mismatch():
 doc={'rows':{'16':{'E':'1000.00'},'17':{'E':'0'},'18':{'E':'0'},'19':{'E':'0'},'21':{'E':'300'},'22':{'E':'1300'}}}
 x=next(g for g in reconcile(doc)['grupos'] if g['grupo']=='M1')
 assert x['situacao']=='CONSISTENTE_ARITMETICAMENTE'
 doc['rows']['22']['E']='1300.02'
 x=next(g for g in reconcile(doc)['grupos'] if g['grupo']=='M1')
 assert x['situacao']=='INCONSISTENTE' and x['diferenca']=='0.02'
 del doc['rows']['17']
 x=next(g for g in reconcile(doc)['grupos'] if g['grupo']=='M1')
 assert x['situacao']=='INCOMPLETO' and 17 in x['faltantes']

def test_nonfinite_numbers_blocked():
 assert as_decimal('NaN') is None
 assert as_decimal('Infinity') is None
 assert as_decimal('-Infinity') is None

def test_reconciliation_api_and_download(authorized):
 c,h=authorized
 pid=c.post('/api/processes',headers=h,json={'company':'Teste documental','contract':'DOC-001'}).json()['id']
 raw=(BASE/'assets/modelo_vigilante_diurno_armado.xlsx').read_bytes()
 d=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'vigente'},files={'file':('vigente.xlsx',raw)}).json()
 r=c.get(f'/api/processes/{pid}/reconciliation',headers=h)
 assert r.status_code==200 and r.json()['conclusivo'] is False
 assert 'vigente' in r.json()['planilhas']
 r=c.get(f'/api/processes/{pid}/documents/{d["id"]}/download',headers=h)
 assert r.status_code==200 and hashlib.sha256(r.content).hexdigest()==d['sha256']
 assert c.get(f'/api/processes/{pid}/documents/999999/download',headers=h).status_code==404

def test_roles_restrict_mutations(authorized):
 c,h=authorized
 user='consulta_v05'
 r=c.post('/api/users',headers=h,json={'username':user,'password':'SenhaSegura1234!','role':'CONSULTA'})
 assert r.status_code in (200,409),r.text
 login=c.post('/api/login',json={'username':user,'password':'SenhaSegura1234!'})
 assert login.status_code==200
 limited={'Authorization':'Bearer '+login.json()['token']}
 assert c.get('/api/processes',headers=limited).status_code==200
 assert c.post('/api/processes',headers=limited,json={'company':'Indevido','contract':'000'}).status_code==403
 assert c.get('/api/users',headers=limited).status_code==403
 assert c.post('/api/users',headers=limited,json={'username':'hacker_v05','password':'SenhaSegura123!','role':'ADMIN'}).status_code==403

def test_cross_tenant_denied(authorized):
 c,h=authorized
 a=c.post('/api/processes',headers=h,json={'company':'Organizacao A','contract':'A1'}).json()['id']
 from app import db
 with db() as cx:
  o=cx.execute('INSERT INTO orgs(name) VALUES(?)',('Organizacao B',)).lastrowid
  cx.execute('INSERT INTO users(org_id,username,pw_hash,role) VALUES(?,?,?,?)',(o,'other_v05',__import__('app').pw_hash('SegredoSeparado123!'),'ANALISTA'))
 lg=c.post('/api/login',json={'username':'other_v05','password':'SegredoSeparado123!'})
 assert lg.status_code==200
 other={'Authorization':'Bearer '+lg.json()['token']}
 assert c.get(f'/api/processes/{a}/documents',headers=other).status_code==404
 assert c.get(f'/api/processes/{a}/report',headers=other).status_code==404
 assert c.get(f'/api/processes/{a}/reconciliation',headers=other).status_code==404

def test_session_expiration(authorized):
 c,h=authorized
 from app import db
 token=h['Authorization'][7:]
 with db() as cx:cx.execute('UPDATE sessions SET created=? WHERE token_hash=?',('2020-01-01T00:00:00+00:00',hashlib.sha256(token.encode()).hexdigest()))
 assert c.get('/api/me',headers=h).status_code==401

def test_backup_integrity(authorized,monkeypatch,tmp_path):
 import backup_local as bk
 monkeypatch.setattr(bk,'DATA',DB.parent)
 monkeypatch.setattr(bk,'BACKUP',tmp_path)
 p=bk.create_backup()
 assert bk.verify_backup(p)
 with zipfile.ZipFile(p) as z: assert 'database.sql' in z.namelist()

def test_upload_zip_bomb_guard(authorized):
 c,h=authorized
 pid=c.post('/api/processes',headers=h,json={'company':'Teste de defesa','contract':'ZIP-1'}).json()['id']
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('huge.xml',b' '* (31*1024*1024))
 r=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'pedido'},files={'file':('ataque.xlsx',buf.getvalue())})
 assert r.status_code==413,r.text

def test_backup_restore_separate_directory(authorized,monkeypatch,tmp_path):
 import backup_local as bk
 monkeypatch.setattr(bk,'DATA',DB.parent)
 monkeypatch.setattr(bk,'BACKUP',tmp_path/'archive')
 archive=bk.create_backup()
 restored=bk.restore_to_new_directory(archive,tmp_path/'restored')
 assert (restored/'nn.sqlite3').exists()
 with sqlite3.connect(restored/'nn.sqlite3') as cx:
  assert cx.execute('SELECT COUNT(*) FROM users').fetchone()[0]>=1
 with pytest.raises(FileExistsError):bk.restore_to_new_directory(archive,restored)

def test_reconciliation_matches_official_template_summary_rows():
 from reconciliation import GROUPS
 assert GROUPS['M2']=={'items':[50,51,52,53],'total':54}
 assert GROUPS['M1-M5']=={'items':[106,107,108,109,110],'total':111}
 assert GROUPS['PRECO']=={'items':[111,112],'total':113}

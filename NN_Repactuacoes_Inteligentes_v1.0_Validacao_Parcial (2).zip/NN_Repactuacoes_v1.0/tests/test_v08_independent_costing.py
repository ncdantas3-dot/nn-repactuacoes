from decimal import Decimal
import pytest
from independent_costing import reconstruct, CostingValidationError

OLD={'rows':{'16':{'E':'1639.14'},'21':{'C':'0.30'},'35':{'D':'0.08'},'83':{'E':'87.34'}}}
NEW={'rows':{'16':{'E':'1800.00'},'21':{'E':'999.99'},'35':{'E':'300.00'},'83':{'E':'199.00'}}}
E='Memória documental conferida SEI 123'
def r(id,module,op,**kw): return {'id':id,'module':module,'op':op,'evidence':E,**kw}

def test_independent_rate_ignores_requested_as_basis():
 rules=[r('sal','M1','DOCUMENTED_AMOUNT',row=16,value='1735.37'),r('per','M1','RATE',row=21,refs=['sal'],rate_cell='C21')]
 x=reconstruct(OLD,NEW,rules)
 assert x['rubricas'][1]['amount']=='520.61'
 assert x['rubricas'][1]['requested']=='999.99'
 assert x['rubricas'][1]['difference']=='479.38'
 assert x['recalculo_financeiro_condicionado'] is None
 assert 17 in x['required_missing_rows']['M1']

def test_source_amount_only_from_approved_previous():
 x=reconstruct(OLD,NEW,[r('uniform','M5','SOURCE_AMOUNT',row=83,cell='E83')])
 assert x['rubricas'][0]['amount']=='87.34'
 assert x['rubricas'][0]['requested']=='199.00'

def test_missing_evidence_blocks_descendant():
 x=reconstruct(OLD,NEW,[r('s','M1','DOCUMENTED_AMOUNT',value='10',evidence=''),r('f','M1','RATE',refs=['s'],rate='0.30',rate_source='Contrato original 2024')])
 assert x['unresolved']==['s','f']

def test_no_cycle_allowed():
 with pytest.raises(CostingValidationError,match='circular'):
  reconstruct(OLD,NEW,[r('a','M1','SUM',refs=['b']),r('b','M1','SUM',refs=['a'])])

def test_missing_reference_or_duplicate_rejected():
 with pytest.raises(CostingValidationError,match='inexistente'):
  reconstruct(OLD,NEW,[r('a','M1','SUM',refs=['z'])])
 with pytest.raises(CostingValidationError,match='duplicada'):
  reconstruct(OLD,NEW,[r('a','M1','DOCUMENTED_AMOUNT',row=16,value='1'),r('b','M1','DOCUMENTED_AMOUNT',row=16,value='2')])

def test_cannot_fake_full_price_with_six_partial_modules():
 rules=[r(f'r{i}',f'M{i}','DOCUMENTED_AMOUNT',value='1') for i in range(1,7)]
 rules.append(r('TOTAL','M6','SUM',refs=[f'r{i}' for i in range(1,7)],final_price=True))
 x=reconstruct(OLD,NEW,rules)
 assert x['recalculo_financeiro_condicionado'] is None
 assert not x['all_rules_complete']

def test_half_up_rounding():
 rules=[r('x','M1','DOCUMENTED_AMOUNT',value='1.005')]
 x=reconstruct(OLD,NEW,rules)
 assert x['rubricas'][0]['amount']=='1.01'

def test_arbitrary_formula_not_executed():
 with pytest.raises(CostingValidationError,match='não permitido'):
  reconstruct(OLD,NEW,[r('x','M1','EVAL',formula='__import__("os")')])

def test_multiplier_requires_quantity_proof():
 rules=[r('unit','M1','DOCUMENTED_AMOUNT',value='2'),r('posto','M1','MULTIPLY',refs=['unit'],factor='3',factor_source='')]
 x=reconstruct(OLD,NEW,rules)
 assert x['rubricas'][-1]['amount'] is None

def test_decimal_bad_numbers_rejected():
 x=reconstruct(OLD,NEW,[r('v','M1','DOCUMENTED_AMOUNT',value='NaN')])
 assert x['rubricas'][0]['status']=='PENDENTE'

def test_detects_double_counting_in_sum():
 rules=[r('a','M1','DOCUMENTED_AMOUNT',value='5'),r('b','M1','SUM',refs=['a']),r('c','M1','SUM',refs=['a','b'])]
 with pytest.raises(CostingValidationError,match='dupla contagem'):
  reconstruct(OLD,NEW,rules)

def test_draft_is_complete_and_not_approved():
 from independent_costing import draft_rules, REQUIRED_ROWS
 draft=draft_rules()
 assert len(draft)==sum(len(v) for v in REQUIRED_ROWS.values())
 assert all(not item['evidence'] and not item['value'] for item in draft)
 x=reconstruct(OLD,NEW,draft)
 assert x['recalculo_financeiro_condicionado'] is None
 assert len(x['unresolved'])==len(draft)

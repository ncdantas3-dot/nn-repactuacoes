import sys
from pathlib import Path
from decimal import Decimal
import pytest
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
from closing import closing_m6,diagnostics

PREV={'rows':{'93':{'C':'0.043'},'94':{'C':'0.0401'},'98':{'D':'0.0065'},'99':{'D':'0.03'},'102':{'D':'0.05'}}}
TOTALS={'M1':'2000.00','M2':'1800.00','M3':'150.00','M4':'100.00','M5':'300.00'}
EVID={k:'SEI 123456 - memória aprovada' for k in TOTALS}

def test_documented_m6_arithmetic_independent():
  r=closing_m6(PREV,TOTALS,EVID,'sobre_custo_mais_indiretos')
  assert r['custo_modulos_1_a_5']=='4350.00'
  assert r['indiretos']=='187.05'
  assert r['lucro']=='181.94'
  assert r['base_sem_tributos']=='4718.99'
  assert r['preco_cenario']=='5165.83'
  assert r['tributos_por_dentro']=='446.84'
  assert Decimal(r['preco_cenario'])-Decimal(r['tributos_por_dentro'])==Decimal(r['base_sem_tributos'])
  assert r['valor_proposto_deferimento'] is None
  assert r==closing_m6(PREV,TOTALS,EVID,'sobre_custo_mais_indiretos')

def test_missing_document_blocks():
  with pytest.raises(ValueError,match='Evidência'):
    closing_m6(PREV,TOTALS,{**EVID,'M5':''},'sobre_custo')

def test_missing_rate_blocks():
  with pytest.raises(ValueError,match='D102'):
    closing_m6({'rows':{k:v for k,v in PREV['rows'].items() if k!='102'}},TOTALS,EVID,'sobre_custo')

def test_declared_precision_rejected():
  with pytest.raises(ValueError,match='duas casas'):
    closing_m6(PREV,{**TOTALS,'M4':'100.001'},EVID,'sobre_custo')

def test_profit_method_must_be_explicit():
  with pytest.raises(ValueError,match='Metodologia'):
    closing_m6(PREV,TOTALS,EVID,'')

def test_diagnostics_preserves_pending():
  r=diagnostics({'rubricas':[{'module':'M4','row':65,'rubrica':'Férias','apurado':None,'status':'PENDENTE'},{'module':'M5','row':83,'rubrica':'Uniforme','apurado':'100.00','status':'CALCULO_CONDICIONADO'}]})
  assert r['modulos']['M4']['situacao']=='INCOMPLETO'
  assert r['modulos']['M5']['situacao']=='CALCULADO_SOB_CONDICOES'
  assert r['integralmente_homologado'] is False

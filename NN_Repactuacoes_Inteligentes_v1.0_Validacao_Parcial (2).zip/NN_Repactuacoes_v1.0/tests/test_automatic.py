from decimal import Decimal
import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from automatic import automatic_closure, COMPONENTS
class TestAutomatic(unittest.TestCase):
 def sample(self):
  return {'rubricas':[],'valor_solicitado':'999.00'}
 def test_empty_blocked(self):
  r=automatic_closure(self.sample())
  self.assertEqual(r['status'],'PENDENTE')
  self.assertIsNone(r['preco_integral_auditado'])
  self.assertEqual(r['rubricas_calculadas'],0)
 def test_only_salary_no_false_total(self):
  r=automatic_closure({'rubricas':[{'row':16,'apurado':'2000.00','status':'CONFERENCIA_ARITMETICA','formula':'CCT'}]})
  self.assertEqual(r['modulos']['M1']['subtotal_parcial'],'2000.00')
  self.assertIsNone(r['modulos']['M1']['subtotal_completo'])
  self.assertIsNone(r['custo_integral_m1_m5'])
 def test_no_double_count_aggregates(self):
  rows=[{'row':i,'apurado':'1.00','status':'CONFERENCIA_ARITMETICA'} for group in COMPONENTS.values() for i in group]
  rows += [{'row':22,'apurado':'999999.00','status':'CONFERENCIA_ARITMETICA'}, {'row':111,'apurado':'999999.00','status':'CONFERENCIA_ARITMETICA'}]
  r=automatic_closure({'rubricas':rows})
  expected=sum(map(len,COMPONENTS.values()))
  self.assertEqual(r['rubricas_calculadas'],expected)
  self.assertEqual(r['custo_integral_m1_m5'],f'{expected:.2f}')
  self.assertEqual(r['modulos']['M2']['subtotal_completo'],f'{sum(len(COMPONENTS[x]) for x in ('M2.1','M2.2','M2.3','M2.4')):.2f}')
 def test_conditional_not_homologated(self):
  rows=[{'row':i,'apurado':'1.00','status':'CALCULO_CONDICIONADO_AUTO'} for group in COMPONENTS.values() for i in group]
  r=automatic_closure({'rubricas':rows})
  self.assertTrue(r['completude_m1_m5'])
  self.assertEqual(r['status'],'BASE_M1_M5_COMPLETA_SEM_VALIDACAO_JURIDICA')
  self.assertIsNone(r['valor_proposto_deferimento'])
  self.assertIsNone(r['preco_integral_auditado'])
 def test_missing_null_not_zero(self):
  rows=[{'row':16,'apurado':'0.00','status':'CONFERENCIA_ARITMETICA'}, {'row':17,'apurado':None,'status':'PENDENTE'}]
  r=automatic_closure({'rubricas':rows})
  self.assertEqual(len(r['modulos']['M1']['pendencias']),4)
 def test_reject_fractional_cent(self):
  r=automatic_closure({'rubricas':[{'row':16,'apurado':'1.001','status':'CONFERENCIA_ARITMETICA'}]})
  self.assertEqual(r['modulos']['M1']['componentes_calculados'],0)
 def test_determinism(self):
  v={'rubricas':[{'row':16,'apurado':'123.40','status':'CONFERENCIA_ARITMETICA'}]}
  self.assertEqual(automatic_closure(v),automatic_closure(v))
if __name__=='__main__':unittest.main()

class TestM6(unittest.TestCase):
 def test_m6_blocks_partial(self):
  from automatic import conditional_m6_from_run
  with self.assertRaisesRegex(ValueError,'bloqueado'):
   conditional_m6_from_run({'rows':{}},{'rubricas':[]},'sobre_custo')
 def test_m6_from_calculated_only(self):
  from automatic import conditional_m6_from_run,COMPONENTS
  rows=[{'row':i,'apurado':'1.00','status':'CALCULO_CONDICIONADO_AUTO'} for group in COMPONENTS.values() for i in group]
  vigente={'rows':{str(n):{c:v} for c,n,v in [('C',93,'0.05'),('C',94,'0.04'),('D',98,'0.0065'),('D',99,'0.03'),('D',102,'0.05')]}}
  out=conditional_m6_from_run(vigente,{'rubricas':rows},'sobre_custo')
  self.assertEqual(out['origem_subtotais'],'RECALCULO_AUTOMATICO_DOS_COMPONENTES_NN_AUTO_0.6')
  self.assertIsNone(out['valor_proposto_deferimento'])
  self.assertTrue(Decimal(out['preco_cenario'])>Decimal(out['custo_modulos_1_a_5']))

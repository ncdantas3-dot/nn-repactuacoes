"""Testes para distinguir intervalo simples de referência a faixa mesclada."""
import zipfile
from decimal import Decimal
import pytest
from workbook_forensics import SheetCells,Evaluator,Blocked,load,inspect_workbook

def test_merged_scalar_anchor_independent_of_cached_value():
    a=SheetCells(merged_ranges=['H13:I13'])
    a['H13']={'formula':'12*3','raw':'999'}
    a['I13']={'formula':None,'raw':None}
    ev=Evaluator({'Origem':a, 'Custo':{'E83':{'formula':"'Origem'!H13:I13",'raw':'0'}}})
    assert ev.get('Custo','E83')==Decimal('36')

def test_nonmerged_scalar_range_is_blocked():
    a=SheetCells(merged_ranges=[])
    a['H13']={'formula':None,'raw':'50'}
    a['I13']={'formula':None,'raw':'37.34'}
    ev=Evaluator({'Origem':a})
    with pytest.raises(Blocked,match='INTERVALO_ESCALAR_NAO_MESCLADO'):
        ev.formula('Origem',"'Origem'!H13:I13")

def test_merged_requires_existing_anchor():
    a=SheetCells(merged_ranges=['H13:I13'])
    ev=Evaluator({'Origem':a})
    with pytest.raises(Blocked,match='ANCORA_MESCLAGEM_AUSENTE'):
        ev.formula('Origem',"'Origem'!H13:I13")

def test_unrelated_merges_do_not_resolve():
    a=SheetCells(merged_ranges=['H13:I13'])
    a['H14']={'formula':None,'raw':'100'}
    ev=Evaluator({'Origem':a})
    with pytest.raises(Blocked):ev.formula('Origem',"'Origem'!H14:I14")

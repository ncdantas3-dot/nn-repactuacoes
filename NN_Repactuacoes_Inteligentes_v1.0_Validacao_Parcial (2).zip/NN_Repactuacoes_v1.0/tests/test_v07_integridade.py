from test_system import authorized, client, BASE


def _make_run(c,h,contract='NEW'):
    pid=c.post('/api/processes',headers=h,json={'company':'Empresa integridade','contract':contract}).json()['id']
    raw=(BASE/'assets/modelo_vigilante_diurno_armado.xlsx').read_bytes()
    for kind in ('vigente','pedido'):
        r=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':kind},files={'file':('model.xlsx',raw)})
        assert r.status_code==200,r.text
    r=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'cct'},files={'file':('conv.pdf',b'%PDF-1.4 DADOS CCT')})
    assert r.status_code==200,r.text
    run=c.post(f'/api/processes/{pid}/audit',headers=h,json={'cct_piso':'1639.14'})
    assert run.status_code==200,run.text
    return pid,run.json()['id']

def test_manifest_version_and_review_block(authorized):
    c,h=authorized
    pid,rid=_make_run(c,h,'TEST-MANIFEST')
    v=c.get(f'/api/processes/{pid}/versions',headers=h)
    assert v.status_code==200
    assert v.json()[0]['run_id']==rid
    assert len(v.json()[0]['manifest_sha256'])==64
    assert v.json()[0]['current_documents'] is True
    rev=c.post(f'/api/processes/{pid}/review',headers=h,json={'run_id':rid,'action':'ENVIAR_REVISAO','note':'Conferir o demonstrativo antes da conclusão'})
    assert rev.status_code==200,rev.text
    assert rev.json()['status']=='EM_REVISAO'
    dec={'run_id':rid,'row_number':16,'decision':'PENDENTE','justification':'Aguardando cláusula comprobatória','evidence':'SEI-123'}
    assert c.post(f'/api/processes/{pid}/decisions',headers=h,json=dec).status_code==409
    approval=c.post(f'/api/processes/{pid}/review',headers=h,json={'run_id':rid,'action':'APROVAR','note':'Aprovação deve ser bloqueada por pendências'})
    assert approval.status_code in (403,409)
    rpt=c.get(f'/api/processes/{pid}/report',headers=h)
    assert rpt.status_code==200
    assert 'Manifesto SHA-256:' in rpt.text
    assert 'MINUTA' in rpt.text

def test_document_replacement_stales_and_prevents_decision(authorized):
    c,h=authorized
    pid,rid=_make_run(c,h,'TEST-SWAP')
    r=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'cct'},files={'file':('nova.pdf',b'%PDF-1.4 NOVO CCT')})
    assert r.status_code==200
    v=c.get(f'/api/processes/{pid}/versions',headers=h).json()
    assert v[0]['current_documents'] is False
    dec={'run_id':rid,'row_number':16,'decision':'MANTER','justification':'Não é permitido decidir versão obsoleta','evidence':'SEI 789'}
    assert c.post(f'/api/processes/{pid}/decisions',headers=h,json=dec).status_code==409
    rpt=c.get(f'/api/processes/{pid}/report',headers=h)
    assert 'DOCUMENTOS SUBSTITUÍDOS' in rpt.text

def test_report_is_scoped_to_single_run(authorized):
    c,h=authorized
    pid,one=_make_run(c,h,'TEST-REPORT')
    dec={'run_id':one,'row_number':16,'decision':'PENDENTE','justification':'Registro único primeira auditoria','evidence':'SEI-OLD'}
    assert c.post(f'/api/processes/{pid}/decisions',headers=h,json=dec).status_code==200
    # Segunda auditoria sobre os mesmos documentos: decisões da primeira não devem aparecer
    two=c.post(f'/api/processes/{pid}/audit',headers=h,json={'cct_piso':'1700.00'})
    assert two.status_code==200
    assert two.json()['id']!=one
    rpt=c.get(f'/api/processes/{pid}/report',headers=h)
    assert rpt.status_code==200
    assert 'SEI-OLD' not in rpt.text
    assert 'Versão da auditoria:' in rpt.text

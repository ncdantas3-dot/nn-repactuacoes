from test_system import authorized, client, BASE
from test_v07_integridade import _make_run


def payload(rid):
 return {'run_id':rid,'rules':[{'id':'SAL','module':'M1','op':'DOCUMENTED_AMOUNT','row':16,'value':'1639.14','evidence':'CCT registrada e conferida pelo analista'}]}

def test_api_records_independent_memory_and_blocks_stale(authorized):
 c,h=authorized
 pid,rid=_make_run(c,h,'TEST-V08')
 res=c.post(f'/api/processes/{pid}/independent-costing',headers=h,json=payload(rid))
 assert res.status_code==200,res.text
 body=res.json()
 assert body['rubricas'][0]['amount']=='1639.14'
 assert body['recalculo_financeiro_condicionado'] is None
 assert len(body['rules_sha256'])==64
 getter=c.get(f'/api/processes/{pid}/independent-costing',headers=h)
 assert getter.status_code==200
 assert getter.json()['costing_id']==body['costing_id']
 c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'cct'},files={'file':('cct_modificada.pdf',b'%PDF-1.4 DADOS NOVA CCT')})
 stale=c.get(f'/api/processes/{pid}/independent-costing',headers=h)
 assert stale.json()['status']=='DESATUALIZADO'
 attempted=c.post(f'/api/processes/{pid}/independent-costing',headers=h,json=payload(rid))
 assert attempted.status_code==409

def test_api_requires_authorization_and_rules(authorized):
 c,h=authorized
 pid,rid=_make_run(c,h,'TEST-AUTH-08')
 assert c.post(f'/api/processes/{pid}/independent-costing',json=payload(rid)).status_code==401
 bad=payload(rid);bad['rules'][0]['op']='EXEC'
 assert c.post(f'/api/processes/{pid}/independent-costing',headers=h,json=bad).status_code==422

import os,sys,tempfile
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
os.environ['NN_DATA_DIR']=tempfile.mkdtemp(prefix='nn_test_')
from app import app
from engine import audit

@pytest.fixture
def client():return TestClient(app)
@pytest.fixture
def authorized(client):
 assert client.post('/api/setup',json={'org':'Cliente A','username':'admin','password':'SenhaForte123!'}).status_code in (200,403)
 r=client.post('/api/login',json={'username':'admin','password':'SenhaForte123!'})
 assert r.status_code==200
 return client,{'Authorization':'Bearer '+r.json()['token']}
def test_setup_and_login(authorized):
 c,h=authorized
 assert c.get('/api/me',headers=h).status_code==200
 assert c.get('/api/processes').status_code==401
 assert c.post('/api/setup',json={'org':'Outra Organizacao','username':'outro','password':'senhaSegura1234'}).status_code==403

def test_process_and_access(authorized):
 c,h=authorized
 p=c.post('/api/processes',headers=h,json={'company':'GJ Seguranca','contract':'123/2025'});assert p.status_code==200
 i=p.json()['id'];assert c.get('/api/processes',headers=h).json()[0]['id']==i
 assert c.get(f'/api/processes/{i}/documents',headers=h).status_code==200
 assert c.get('/api/template',headers=h).status_code==200
 assert c.post(f'/api/processes/{i}/audit',headers=h,json={}).status_code==409

def test_decimal_cents_and_pending():
 prev={'rows':{'21':{'C':.3},'25':{'D':1/12},'26':{'D':.121},'30':{'D':.2}}}
 req={'rows':{'16':{'E':2000},'21':{'E':600},'25':{'E':216.67},'26':{'E':314.60},'30':{'E':626.25}}}
 res=audit(prev,req,'2000')
 by={r['row']:r for r in res['rubricas']}
 assert by[16]['apurado']=='2000.00'
 assert by[21]['apurado']=='600.00'
 assert by[25]['apurado']=='216.67'
 assert by[26]['apurado']=='314.60'
 assert by[30]['apurado']=='626.25'
 assert by[83]['apurado'] is None
 assert res['valor_proposto_deferimento'] is None

def test_import_model(authorized):
 c,h=authorized
 pid=c.post('/api/processes',headers=h,json={'company':'Teste','contract':'001'}).json()['id']
 raw=(BASE/'assets/modelo_vigilante_diurno_armado.xlsx').read_bytes()
 r=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'vigente'},files={'file':('modelo.xlsx',raw,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')})
 assert r.status_code==200,r.text
 assert r.json()['extracted']['row_count']==125
 r=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'pedido'},files={'file':('pedido.xlsx',raw,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')})
 assert r.status_code==200,r.text
 r=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'cct'},files={'file':('cct.pdf',b'%PDF-1.4 test','application/pdf')})
 assert r.status_code==200,r.text
 a=c.post(f'/api/processes/{pid}/audit',headers=h,json={'cct_piso':'1639.14'})
 assert a.status_code==200,a.text
 assert a.json()['conclusivo'] is False
 assert a.json()['resumo']['PENDENTE']>0
 report=c.get(f'/api/processes/{pid}/report',headers=h)
 assert report.status_code==200
 assert 'MINUTA' in report.text

def test_reject_invalid_document(authorized):
 c,h=authorized
 pid=c.post('/api/processes',headers=h,json={'company':'Testes','contract':'002'}).json()['id']
 r=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'pedido'},files={'file':('corrompido.xlsx',b'arquivo texto','application/octet-stream')})
 assert r.status_code==400
 assert c.get(f'/api/processes/{pid}/documents',headers=h).json()==[]

def test_process_not_found(authorized):
 c,h=authorized
 assert c.get('/api/processes/999999/documents',headers=h).status_code==404
 assert c.get('/api/processes/999999/report',headers=h).status_code==404

def test_decision_requires_real_run(authorized):
 c,h=authorized
 pid=c.post('/api/processes',headers=h,json={'company':'Teste','contract':'003'}).json()['id']
 r=c.post(f'/api/processes/{pid}/decisions',headers=h,json={'run_id':999,'row_number':16,'decision':'MANTER','justification':'Conferencia documental realizada','evidence':'SEI 123'})
 assert r.status_code==404

def test_no_global_total_on_partial_audit():
 a=audit({'rows':{'21':{'C':.3},'25':{'D':1/12}}},{'rows':{'113':{'E':99999},'16':{'E':1000},'21':{'E':300}}},'1000')
 assert a['valor_solicitado']=='99999.00'
 assert a['valor_matematicamente_apurado'] is None
 assert a['valor_proposto_deferimento'] is None
 assert a['conclusivo'] is False


def test_declared_base_requires_evidence_and_preserves_pending():
 prev={'rows':{'57':{'D':0.0042},'93':{'C':0.043}}}
 req={'rows':{'57':{'E':13.21},'93':{'E':243.47}}}
 rules=[{'row':57,'base_value':'3146.05','base_description':'Remuneracao revisada documental','evidence':'SEI 1001; base revisada'}]
 r=audit(prev,req,None,rules)
 row=next(x for x in r['rubricas'] if x['row']==57)
 assert row['apurado']=='13.21'
 assert row['status']=='CALCULO_CONDICIONADO'
 assert row['referencia_aliquota']=='D57'
 assert r['valor_proposto_deferimento'] is None
 assert next(x for x in r['rubricas'] if x['row']==93)['apurado'] is None

def test_declared_base_reject_invalid():
 with pytest.raises(ValueError):
  audit({'rows':{}},{'rows':{}},None,[{'row':57,'base_value':'-1','base_description':'base insuficiente','evidence':'SEI 123456'}])
 with pytest.raises(ValueError):
  audit({'rows':{}},{'rows':{}},None,[{'row':16,'base_value':'100','base_description':'base documentada','evidence':'SEI 123456'}])

def test_retroactive_arithmetic_and_persistence(authorized):
 c,h=authorized
 pid=c.post('/api/processes',headers=h,json={'company':'Cenario financeiro','contract':'RET-01'}).json()['id']
 lines=[{'month':'2025-01','quantity':'25','previous_unit':'5600','new_unit':'5800','executed_fraction':'1','previous_paid':'1000','glosa':'500','justification':'Medição SEI 2025-01'},
        {'month':'2025-02','quantity':'20','previous_unit':'5600','new_unit':'5800','executed_fraction':'0.5','previous_paid':'0','glosa':'0','justification':'Medição SEI 2025-02'}]
 r=c.post(f'/api/processes/{pid}/retroactive',headers=h,json={'lines':lines})
 assert r.status_code==200,r.text
 assert r.json()['total_provisorio']=='5500.00'
 assert r.json()['homologado'] is False
 assert len(c.get(f'/api/processes/{pid}/retroactive',headers=h).json())==1

def test_retroactive_reject_duplicates_and_bad_fraction(authorized):
 c,h=authorized
 pid=c.post('/api/processes',headers=h,json={'company':'Validacao','contract':'RET-02'}).json()['id']
 line={'month':'2025-01','quantity':'10','previous_unit':'500','new_unit':'600','justification':'Medição oficial SEI 2025'}
 assert c.post(f'/api/processes/{pid}/retroactive',headers=h,json={'lines':[line,line]}).status_code==422
 assert c.post(f'/api/processes/{pid}/retroactive',headers=h,json={'lines':[{**line,'executed_fraction':'1.5'}]}).status_code==422


from incidence import MATRIX,analyze_matrix

def test_matrix_exposes_documented_rates():
    by={x['row']:x for x in MATRIX}
    assert by[35]['rate_cell']=='D35'
    assert by[57]['base']=='remuneracao_mais_submodulo_2_1'
    assert by[93]['base']=='total_integral_modulos_1_a_5'
    assert len({x['row'] for x in MATRIX})==len(MATRIX)

def test_m3_auto_requires_explicit_zero_for_other_m1():
    prev={'rows':{'21':{'C':'0.3'},'25':{'D':'0.0833333333333333333333'},'26':{'D':'0.121'},'57':{'D':'0.0042'}}}
    req={'rows':{'16':{'E':2000},'21':{'E':600},'25':{'E':'216.67'},'26':{'E':'314.60'},'57':{'E':'13.15'}}}
    out=analyze_matrix(prev,req,audit(prev,req,'2000'))
    row=next(x for x in out['rubricas'] if x['row']==57)
    assert row['status']=='PENDENTE'
    assert out['matriz_incidencias']['base_rescisao_condicionada'] is None
    for r in (17,18,19):req['rows'][str(r)]={'E':0}
    out=analyze_matrix(prev,req,audit(prev,req,'2000'))
    row=next(x for x in out['rubricas'] if x['row']==57)
    assert row['status']=='CALCULO_CONDICIONADO_AUTO'
    assert row['apurado']=='13.15'
    assert row['base_calculo']=='3131.27'
    assert out['valor_matematicamente_apurado'] is None
    assert out['valor_proposto_deferimento'] is None
    assert out['conclusivo'] is False

def test_m3_invalid_rate_stays_pending():
    prev={'rows':{'21':{'C':'0.30'},'25':{'D':'0.08333333333333333333'},'26':{'D':'0.121'},'57':{'D':'1.4'}}}
    req={'rows':{'16':{'E':2000},'21':{'E':600},'25':{'E':'216.67'},'26':{'E':'314.60'},'17':{'E':0},'18':{'E':0},'19':{'E':0}}}
    out=analyze_matrix(prev,req,audit(prev,req,'2000'))
    assert next(x for x in out['rubricas'] if x['row']==57)['status']=='PENDENTE'

def test_api_matrix_authorization_and_audit(authorized):
    c,h=authorized
    assert c.get('/api/incidence-matrix').status_code==401
    r=c.get('/api/incidence-matrix',headers=h)
    assert r.status_code==200
    assert any(x['row']==57 for x in r.json()['rules'])

def test_conditional_closing_api(authorized):
 c,h=authorized
 pid=c.post('/api/processes',headers=h,json={'company':'Empresa de teste','contract':'M6-04'}).json()['id']
 data=(BASE/'assets/modelo_vigilante_diurno_armado.xlsx').read_bytes()
 for kind in ('vigente','pedido'):
  response=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':kind},files={'file':('modelo.xlsx',data,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')})
  assert response.status_code==200,response.text
 assert c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'cct'},files={'file':('cct.pdf',b'%PDF-1.4 teste','application/pdf')}).status_code==200
 run=c.post(f'/api/processes/{pid}/audit',headers=h,json={'cct_piso':'2000'})
 assert run.status_code==200,run.text
 totals={'M1':'2000.00','M2':'1800.00','M3':'150.00','M4':'100.00','M5':'300.00'}
 evidences={key:'Planilha aprovada SEI 123456' for key in totals}
 body={'run_id':run.json()['id'],'module_totals':totals,'evidences':evidences,'profit_method':'sobre_custo_mais_indiretos'}
 r=c.post(f'/api/processes/{pid}/closing',headers=h,json=body)
 assert r.status_code==200,r.text
 assert r.json()['valor_proposto_deferimento'] is None
 assert r.json()['status']=='CENARIO_ARITMETICO_CONDICIONADO'
 assert len(c.get(f'/api/processes/{pid}/closing',headers=h).json())==1
 assert c.get(f'/api/processes/{pid}/closing').status_code==401
 report=c.get(f'/api/processes/{pid}/report',headers=h)
 assert report.status_code==200
 assert 'cenário aritmético condicionado' in report.text
 assert 'não é valor de deferimento' in report.text
 bad=c.post(f'/api/processes/{pid}/closing',headers=h,json={**body,'run_id':999999})
 assert bad.status_code==404

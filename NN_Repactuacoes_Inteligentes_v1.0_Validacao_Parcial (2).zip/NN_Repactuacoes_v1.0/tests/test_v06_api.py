from test_system import authorized,client,BASE

def test_auto_requires_run_and_tenant(authorized):
 c,h=authorized
 pid=c.post('/api/processes',headers=h,json={'company':'Teste v06','contract':'06-A'}).json()['id']
 r=c.get(f'/api/processes/{pid}/automatic-closing',headers=h)
 assert r.status_code==409
 assert c.get('/api/processes/999999/automatic-closing',headers=h).status_code==404
 assert c.get(f'/api/processes/{pid}/automatic-closing').status_code==401

def test_auto_closing_responds_and_remains_blocked(authorized):
 c,h=authorized
 pid=c.post('/api/processes',headers=h,json={'company':'Teste v06 auditoria','contract':'06-B'}).json()['id']
 raw=(BASE/'assets/modelo_vigilante_diurno_armado.xlsx').read_bytes()
 for k in ['vigente','pedido']:
  resp=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':k},files={'file':(k+'.xlsx',raw)})
  assert resp.status_code==200,resp.text
 cct=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'cct'},files={'file':('cct.pdf',b'%PDF-1.4\nendobj\n%%EOF')})
 assert cct.status_code==200,cct.text
 run=c.post(f'/api/processes/{pid}/audit',headers=h,json={'cct_piso':'1639.14'})
 assert run.status_code==200,run.text
 data=c.get(f'/api/processes/{pid}/automatic-closing',headers=h)
 assert data.status_code==200,data.text
 r=data.json()
 assert r['status']=='PENDENTE'
 assert r['preco_integral_auditado'] is None
 assert r['valor_proposto_deferimento'] is None
 assert r['bloqueios']
 assert r['auditoria_id']==run.json()['id']
 # Substituicao da CCT invalida o fechamento, mesmo sem alterar as planilhas.
 new=c.post(f'/api/processes/{pid}/documents',headers=h,data={'kind':'cct'},files={'file':('cctnova.pdf',b'%PDF-1.4\nchanged\n%%EOF')})
 assert new.status_code==200
 assert c.get(f'/api/processes/{pid}/automatic-closing',headers=h).status_code==409

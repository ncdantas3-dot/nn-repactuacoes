# Relatório técnico — N & N Repactuações Inteligentes (MVP)

**Data:** 17/11/2026. **Estado:** MVP de desenvolvimento executável localmente, NÃO HOMOLOGADO para produção.

## Entregas efetivamente implementadas

1. Aplicação de cinco abas, responsiva: Painel, Processos, Documentos, Auditoria e Parecer.
2. Backend FastAPI, banco SQLite persistente, criação de administrador e tokens de sessão.
3. Modelo original `Vigilante diurno (ARM.)` para download sem modificar sua estrutura.
4. Upload e análise estruturada da aba oficial, com verificação de rubricas-chave, histórico de versões e SHA-256 dos arquivos.
5. Motor separado em `engine.py`, com cálculos em `Decimal`, arredondamento explícito, classificação aritmética e registro de rubricas pendentes.
6. Registro de decisões humanas e verificações jurídico-processuais por contrato.
7. Geração de minuta HTML institucional pronta para impressão em PDF, contendo rastreabilidade dos documentos e ressalvas.

## Limitações verificáveis

- Não há interpretação automatizada da CCT: o analista deve informar e conferir o piso; presença do PDF é apenas verificação documental.
- A conformidade financeira completa não é calculada: não há parâmetros suficientes para fundamentar automaticamente todas as bases de incidência, em especial módulos 3–6.
- O motor não suporta outras categorias de planilha sem mapeamento e homologação.
- A verificação da estrutura XLSX foca os rótulos e células-chave; validação integral de fórmulas, tipagem, layout e assinatura ainda falta.
- O banco é SQLite para execução local e não PostgreSQL; não há provisionamento de clientes, TLS, 2FA, recuperação de senha, controle de papéis completo nem backups verificados.
- Sem relatórios DOCX ou Excel de parecer, sem PDF nativo, sem cálculo por competência ou integração de pagamentos.
- Não há motor de interpretação jurídica automática: checklist permite decisão humana e registro de fundamento.
- **Não existe valor apurado integral ou deferimento automatizado.** Os campos são explicitamente nulos em todas as respostas enquanto o cálculo for parcial.

## Referências normativas a parametrizar

- Lei Federal nº 14.133/2021, especialmente art. 135: https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm
- IN SEGES/MP nº 05/2017 atualizada e Anexo VII-D: https://www.gov.br/compras/pt-br/acesso-a-informacao/legislacao/instrucoes-normativas/instrucao-normativa-no-5-de-26-de-maio-de-2017-atualizada
- Atenção: a IN é federal, e sua incidência nos contratos estaduais depende da adoção normativa, dos atos locais e do regime contratual aplicável.

## Testes

`pytest -q`. Os testes de execução devem ser avaliados com o banco temporário isolado e não se confundem com homologação jurídica/financeira. Ver `tests/test_system.py`.

## Próximo marco de homologação

Obter contrato e planilha original de custos formalmente aprovada, CCT aplicável e evidências de quantitativos. Reproduzir centavo a centavo os seis módulos e exercícios de retroativo, submeter à revisão de especialista e implementar infraestrutura segura para produção.

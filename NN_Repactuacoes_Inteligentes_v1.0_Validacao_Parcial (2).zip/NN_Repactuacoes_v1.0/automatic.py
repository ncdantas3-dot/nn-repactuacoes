"""Fechamento automático conservador da cadeia de dependências M1–M6.
NUNCA completa lacunas por estimativa nem toma valores solicitados como apurados.
A saída é diagnóstico financeiro; não constitui deferimento jurídico.
"""
from decimal import Decimal
from engine import money, as_decimal

# Apenas componentes analíticos: linhas de subtotal/total são EXCLUÍDAS.
COMPONENTS = {
 'M1':[16,17,18,19,21],
 'M2.1':[25,26],
 'M2.2':list(range(30,38)),
 'M2.3':[40,41,42,43,44],
 'M2.4':[47],
 'M3':[57,58,59,60,61],
 'M4':[65,66,67,68,69,70,74],
 'M5':[83,84,85,86,87],
}
REQUIRES={
 'M1':[],
 'M2.1':['M1'],
 'M2.2':['M1','M2.1'],
 'M2.3':[],
 'M2.4':[],
 'M3':['M1','M2.1'],
 'M4':['M1','M2.1','M2.2'],
 'M5':[],
}
M2_PARTS=['M2.1','M2.2','M2.3','M2.4']
COST_PARTS=['M1','M2.1','M2.2','M2.3','M2.4','M3','M4','M5']

def automatic_closure(run:dict):
    by={item['row']:item for item in run.get('rubricas',[])}
    segments={}
    for name, rows in COMPONENTS.items():
        calculated=[]; outstanding=[]; conditional=[]
        for row in rows:
            item=by.get(row)
            if not item:
                outstanding.append({'linha':row,'motivo':'Rubrica não mapeada pelo motor'});continue
            amount=as_decimal(item.get('apurado'))
            status=item.get('status','PENDENTE')
            if amount is None:
                outstanding.append({'linha':row,'motivo':status});continue
            if amount<0 or amount!=money(amount):
                outstanding.append({'linha':row,'motivo':'Montante inválido ou sem precisão de centavos'});continue
            calculated.append({'linha':row,'valor':str(amount),'formula':item.get('formula'), 'situacao':status})
            if 'CONDICIONADO' in status:conditional.append(row)
        total=money(sum((Decimal(r['valor']) for r in calculated),Decimal('0')))
        segments[name]={
           'componentes_esperados':len(rows),'componentes_calculados':len(calculated),
           'calculados':calculated, 'pendencias':outstanding, 'condicionados':conditional,
           'subtotal_parcial':str(total),
           'subtotal_completo':str(total) if not outstanding else None,
           'completude_aritmetica':not outstanding,
           'elegibilidade_juridica':'NAO_HOMOLOGADA',
           'dependencias':REQUIRES[name],
        }
    # Módulo 2 só será fechado se seus quatro submódulos estiverem completos.
    m2_complete=all(segments[k]['completude_aritmetica'] for k in M2_PARTS)
    m2_total=money(sum((Decimal(segments[k]['subtotal_parcial']) for k in M2_PARTS),Decimal('0')))
    segments['M2']={'submodulos':M2_PARTS,'subtotal_parcial':str(m2_total),'subtotal_completo':str(m2_total) if m2_complete else None,
                    'completude_aritmetica':m2_complete,'elegibilidade_juridica':'NAO_HOMOLOGADA'}
    all_complete=all(segments[k]['completude_aritmetica'] for k in COST_PARTS)
    cost_partial=money(sum((Decimal(segments[k]['subtotal_parcial']) for k in COST_PARTS),Decimal('0')))
    blockers=[]
    for name in COST_PARTS:
        for missing in segments[name]['pendencias']:
            blockers.append({'modulo':name,**missing})
    cost_total=str(cost_partial) if all_complete else None
    return {
       'motor':'NN-AUTO-0.6','modulos':segments,
       'preco_solicitado':run.get('valor_solicitado'),
       'custo_parcial_rubricas_calculadas':str(cost_partial),
       'custo_integral_m1_m5':cost_total,
       'm6_recalculado':None,'preco_integral_auditado':None,'valor_proposto_deferimento':None,
       'rubricas_calculadas':sum(x['componentes_calculados'] for x in segments.values() if 'componentes_calculados' in x),
       'rubricas_esperadas':sum(len(v) for v in COMPONENTS.values()),
       'bloqueios':blockers,
       'completude_m1_m5':all_complete,
       'status':'PENDENTE' if not all_complete else 'BASE_M1_M5_COMPLETA_SEM_VALIDACAO_JURIDICA',
       'restricao':'Subtotais parciais NÃO são valores contratualmente devidos. M6 e valor global não são fechados com componentes faltantes; alíquotas/bases condicionadas exigem validação.'
    }

def conditional_m6_from_run(vigente,run,method):
    """Calcula M6 somente com subtotais EXTRAÍDOS do mesmo recálculo.
    Nunca aceita subtotais informados pela empresa/analista neste caminho.
    """
    from closing import closing_m6
    report=automatic_closure(run)
    if not report['completude_m1_m5']:
        raise ValueError('Fechamento automático bloqueado: rubricas sem base apurada nos módulos 1 a 5')
    totals={m:report['modulos'][m]['subtotal_completo'] for m in ('M1','M3','M4','M5')}
    totals['M2']=report['modulos']['M2']['subtotal_completo']
    if any(v is None for v in totals.values()):
        raise ValueError('Total de módulo ausente; não é permitido estimar')
    evidences={m:'Motor NN-AUTO-0.6: soma das rubricas calculadas com fonte identificada' for m in totals}
    r=closing_m6(vigente,totals,evidences,method)
    r['origem_subtotais']='RECALCULO_AUTOMATICO_DOS_COMPONENTES_NN_AUTO_0.6'
    r['rubricas_condicionadas']={m:d.get('condicionados',[]) for m,d in report['modulos'].items() if d.get('condicionados')}
    r['pendencias'].append('Mesmo com total matemático completo, a validação da CCT, bases e elegibilidade jurídica permanece obrigatória')
    r['valor_proposto_deferimento']=None
    r['status']='CENARIO_CONDICIONADO_SEM_HOMOLOGACAO'
    return r

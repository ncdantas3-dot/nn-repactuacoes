# Guia — Motor de cálculo independente v0.8

## Preparação
1. Instale a aplicação em pasta nova; **não copie por cima da versão anterior**. Preserve o banco anterior; migre apenas com backup testado.
2. Execute `INICIAR_WINDOWS.bat` e abra `http://127.0.0.1:8000`.
3. Acesse Painel → Processos e crie ou selecione um processo.
4. Em Documentos, importe a **planilha vigente efetivamente aprovada**, a planilha solicitada e a CCT.
5. Em Auditoria, informe o piso da CCT após conferência, execute a auditoria preliminar e anote a versão.

## Recálculo independente
6. Em **Motor independente v0.8**, clique **Carregar dicionário de rubricas**.
7. Configure cada rubrica: `op`, `evidence`, origem, dependências e, conforme o caso, `cell`, `value`, `rate_cell` ou `rate`/`rate_source`.
8. Utilize `DOCUMENTED_AMOUNT` para valores comprovados, `SOURCE_AMOUNT` para custo fixo da planilha vigente, `RATE` para alíquota sobre referências anteriores, `SUM` para somatórios e `MULTIPLY` para preço por posto (com quantidade comprovada).
9. **Não coloque valores do pedido nos campos de origem.** O sistema lê o solicitado apenas para comparação. Identifique não incidência por valor zero **expresso e documentado**.
10. Registre o fechamento por módulo e o preço final como regras `SUM`, sendo a última marcada `"final_price": true` e referenciando os módulos apropriados.
11. Clique **Recalcular fontes independentes** e confira valor, fórmula, documento, diferença e bloqueios. Depois consulte a minuta em Parecer.

### Exemplo exclusivamente matemático de duas rubricas (não é aprovação contratual)
```json
[
  {"id":"SAL","name":"Salário-base","module":"M1","row":16,"op":"DOCUMENTED_AMOUNT","value":"1639.14","evidence":"CCT cláusula salarial conferida pelo analista"},
  {"id":"PER","name":"Periculosidade","module":"M1","row":21,"op":"RATE","refs":["SAL"],"rate_cell":"C21","evidence":"Planilha vigente aprovada, linha 21; conferir incidência"}
]
```
O recálculo demonstrará somente **duas parcelas**. O preço por posto e o deferimento continuarão **PENDENTES**.

## Alertas
- Os percentuais do modelo são **referências contratuais a validar**, não garantias universais da IN nº 05/2017.
- Não use a apuração parcial para produzir decisões financeiras definitivas.
- Mudanças na CCT ou em qualquer planilha invalidam a utilização corrente das memórias antigas.

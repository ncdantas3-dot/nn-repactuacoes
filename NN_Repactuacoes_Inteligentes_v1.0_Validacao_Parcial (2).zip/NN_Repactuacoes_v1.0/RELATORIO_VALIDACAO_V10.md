# N & N Repactuações Inteligentes — v1.0 (candidata parcial, não homologada)

## Escopo realizado

Evolução incremental da versão v0.9, preservando a interface de cinco abas e o histórico das rotinas existentes. Corrigido o suporte a sete fórmulas de referência a **regiões mescladas entre abas**, sem converter indevidamente o intervalo em soma. O avaliador usa o registro `mergeCells` do XLSX para reconhecer a região exata e resolver apenas o valor da célula-âncora calculado pela expressão original. Intervalos escalares não mesclados continuam bloqueados.

## Testes com a planilha real GJ 2025

- Arquivo de referência: `Planilha de Custos 2025 - GJ(1).xlsx`.
- Regra de validação: avaliação matemática de fórmulas, **não** homologação contratual.
- Total de fórmulas analisadas: **514**.
- Coincidentes com os valores armazenados: **244**.
- Divergentes dos valores armazenados: **270**.
- Sete referências de regiões mescladas resolvidas estruturalmente; nenhuma delas substituída por soma presumida.
- Rubrica 13º `Vigilante diurno (ARM.)!E25`: cache R$ 177,50; fórmula recalculada R$ 177,57; diferença R$ 0,07.
- Insumo `Vigilante diurno (ARM.)!E83`: referência à mesclagem `Material e uniforme!H13:I13`; âncora recalculada R$ 87,34; cache R$ 87,34.
- Insumo `Vigilante diurno (ARM.)!E85`: referência à mesclagem `Material e uniforme!H32:I32`; âncora recalculada R$ 98,53; cache R$ 98,52; diferença R$ 0,01.

O desaparecimento dos bloqueios técnicos do avaliador **não** comprova a validade das bases contratuais nem a equivalência integral com o motor de cálculo do Microsoft Excel. Valores divergentes podem ser consequência de precisão, caches antigos, dependências ou critérios contratuais diferentes. É indispensável rastrear causas-raiz e avaliar juridicamente cada efeito.

## Referências documentais da CCT

Documento fornecido: CCT 2025/2027, MTE AC000018/2025. Parâmetros para validação: piso do vigilante de R$ 1.639,14 (cláusula terceira), auxílio-alimentação de R$ 36/dia em 2025 (cláusula 11ª), assistência à saúde de R$ 30/mês a partir de março de 2025 (cláusula 12ª). A efetiva elegibilidade dos custos exige enquadramento contratual e análise do analista habilitado.

## Testes de regressão

**73 testes automatizados aprovados**, incluindo quatro novos testes de intervalos mesclados e bloqueio de intervalos não mesclados. Compilação Python e sintaxe JavaScript verificadas. Não houve execução de testes completos em navegador, integração com PostgreSQL ou homologação de segurança em produção.

## Impedimentos remanescentes

1. Planilha anterior efetivamente aprovada e comprovação contratual das bases, alíquotas e arredondamentos.
2. Reconciliação por causa-raiz das 270 diferenças encontradas, com comparação independente em ambiente Excel homologado.
3. Homologação por rubrica dos Módulos 1 a 6, sem inferir percentuais ou usar o valor pedido como insumo do cálculo.
4. Comprovação da quantidade efetiva de trabalhadores por posto e evolução das competências de execução.
5. Revisão jurídica, aprovação humana, segurança multicliente, backup externo e testes ponta a ponta.

**STATUS: Preço por posto NÃO reconstruído; parecer financeiro conclusivo BLOQUEADO; versão NÃO apta para comercialização como auditor integral.**

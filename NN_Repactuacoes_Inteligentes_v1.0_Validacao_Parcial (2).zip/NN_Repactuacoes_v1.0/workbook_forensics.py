"""Verificação forense e não conclusiva de fórmulas XLSX (read-only).

Somente funções explicitamente previstas podem ser interpretadas; não executa macros,
links externos nem código das planilhas. O algoritmo NÃO é motor Excel homologado.
Resultados são testes matemáticos, não valores juridicamente deferíveis.
"""
import re,ast,hashlib,zipfile,xml.etree.ElementTree as ET,collections
from decimal import Decimal,InvalidOperation,ROUND_HALF_UP
from pathlib import Path
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
def q(x):return '{'+NS+'}'+x
class SheetCells(dict):
 def __init__(self,*args,merged_ranges=None,**kwargs):
  super().__init__(*args,**kwargs)
  self.merged_ranges=frozenset(merged_ranges or ())
def load(path):
 with zipfile.ZipFile(path) as z:
  ss=[]
  if 'xl/sharedStrings.xml' in z.namelist():
   ss=[''.join(t.itertext()) for t in ET.fromstring(z.read('xl/sharedStrings.xml')).findall(q('si'))]
  w=ET.fromstring(z.read('xl/workbook.xml'))
  rs=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
  targets={i.attrib['Id']:i.attrib['Target'] for i in rs}
  result={}
  for sh in w.find(q('sheets')):
   tar=targets[sh.attrib['{%s}id'%REL]].lstrip('/');tar=tar if tar.startswith('xl/') else 'xl/'+tar
   root=ET.fromstring(z.read(tar)); merges=root.find(q('mergeCells'))
   merged_ranges=[el.attrib['ref'].replace('$','').upper() for el in merges] if merges is not None else []
   cells=SheetCells(merged_ranges=merged_ranges)
   for c in root.iter(q('c')):
    v=c.find(q('v'));f=c.find(q('f'));inline=c.find(q('is'));raw=v.text if v is not None else None
    if c.attrib.get('t')=='s' and raw is not None:raw=ss[int(raw)]
    if inline is not None:raw=''.join(inline.itertext())
    cells[c.attrib['r']]={'raw':raw,'formula':f.text if f is not None else None, 'type':c.attrib.get('t')}
   result[sh.attrib['name']]=cells
  return result

class Blocked(Exception):pass
class Evaluator:
 def __init__(self,sheets):self.sheets=sheets;self.memo={};self.active=set()
 def get(self,sheet,addr):
  addr=addr.replace('$','').upper();key=(sheet,addr)
  if key in self.memo:return self.memo[key]
  if key in self.active:raise Blocked('REFERENCIA_CIRCULAR')
  data=self.sheets.get(sheet,{}).get(addr)
  if not data or (data['raw'] is None and not data['formula']):return Decimal(0)
  f=data['formula']
  if not f:
   try:return Decimal(str(data['raw']))
   except: raise Blocked('REFERENCIA_TEXTUAL')
  self.active.add(key)
  try:value=self.formula(sheet,f);self.memo[key]=value;return value
  finally:self.active.remove(key)
 def merged_scalar(self,sheet,a,b):
  # Somente a faixa IDENTICA a uma mesclagem real pode resolver para a âncora.
  # Não aplicável a intervalos comuns; não é soma nem consulta ao cache.
  a=a.replace('$','').upper();b=b.replace('$','').upper()
  cells=self.sheets.get(sheet)
  if cells is None or f'{a}:{b}' not in getattr(cells,'merged_ranges',()):
   raise Blocked('INTERVALO_ESCALAR_NAO_MESCLADO')
  if a not in cells:raise Blocked('ANCORA_MESCLAGEM_AUSENTE')
  return self.get(sheet,a)
 def range_values(self,sheet,a,b):
  def decompose(x):
   m=re.fullmatch(r'([A-Z]+)([0-9]+)',x.upper().replace('$',''))
   if not m:raise Blocked('INTERVALO_INVALIDO')
   n=0
   for c in m[1]:n=n*26+ord(c)-64
   return n,int(m[2])
  ac,ar=decompose(a);bc,br=decompose(b)
  if abs((bc-ac+1)*(br-ar+1))>1000:raise Blocked('INTERVALO_EXTENSO')
  def ltr(x):
   s=''
   while x:x,r=divmod(x-1,26);s=chr(65+r)+s
   return s
  return [self.get(sheet,ltr(c)+str(r)) for c in range(ac,bc+1) for r in range(ar,br+1)]
 def formula(self,sheet,f):
  expression=f.strip().lstrip('=');expression=expression.replace('$','')
  if re.search(r'\b(_xlfn|VLOOKUP|INDEX|OFFSET|INDIRECT|LOOKUP|MATCH|SUMIF|TEXT|DATE|NOW)\b',expression,re.I):raise Blocked('FUNCAO_NAO_SUPORTADA')
  if '[' in expression or ']' in expression or '^' in expression or '&' in expression:raise Blocked('EXPRESSAO_NAO_SUPORTADA')
  # Substitui referencias entre aspas de aba, ex.: 'Material e uniforme'!H13
  def replcross(m):return 'CELL('+repr(m.group(1))+','+repr(m.group(2).upper())+')'
  # Uma faixa entre abas sem agregador somente pode ser resolvida quando
  # corresponde EXATAMENTE a uma região mesclada do arquivo de origem.
  expression=re.sub(r"'([^']+)'!([A-Z]{1,3}[0-9]+):([A-Z]{1,3}[0-9]+)",lambda m:'MERGED('+repr(m[1])+','+repr(m[2])+','+repr(m[3])+')',expression,flags=re.I)
  expression=re.sub(r"'([^']+)'!([A-Z]{1,3}[0-9]+)",replcross,expression,flags=re.I)
  expression=re.sub(r'(?<![A-Z0-9])([0-9]+(?:\.[0-9]+)?)%',lambda m:'('+m[1]+'/100)',expression,flags=re.I)
  # Outras referencias de aba sem espacos
  expression=re.sub(r'\b([A-Za-z_][A-Za-z_0-9]*)!([A-Z]{1,3}[0-9]+)',lambda m:'CELL('+repr(m[1])+','+repr(m[2])+')',expression,flags=re.I)
  # Expande intervalos sem prefixo de aba; evitar substituicao no interior de strings
  # tokenize por tokens e preservar literais gerados
  pattern=re.compile(r"'(?:[^'\\]|\\.)*'|\b[A-Za-z]{1,3}[0-9]+\s*:\s*[A-Za-z]{1,3}[0-9]+\b|\b[A-Za-z]{1,3}[0-9]+\b")
  def replace(m):
   t=m[0]
   if t.startswith("'"):return t
   if ':' in t:
    a,b=t.split(':');return 'RANGE('+repr(sheet)+','+repr(a.strip().upper())+','+repr(b.strip().upper())+')'
   return 'CELL('+repr(sheet)+','+repr(t.upper())+')'
  # Problem: generated CELL('sheet','H13') would replace H13 inside quotes single literal protected
  expression=pattern.sub(replace,expression).replace(';',',')
  try:root=ast.parse(expression,mode='eval')
  except SyntaxError:raise Blocked('SINTAXE_NAO_SUPORTADA')
  def calc(node):
   if isinstance(node,ast.Expression):return calc(node.body)
   if isinstance(node,ast.Constant):
    if isinstance(node.value,(int,float)):return Decimal(str(node.value))
    if isinstance(node.value,str):return node.value
    raise Blocked('TIPO_NAO_SUPORTADO')
   if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
    val=calc(node.operand);return val if isinstance(node.op,ast.UAdd) else -val
   if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult,ast.Div)):
    a,b=calc(node.left),calc(node.right)
    if isinstance(node.op,ast.Add):return a+b
    if isinstance(node.op,ast.Sub):return a-b
    if isinstance(node.op,ast.Mult):return a*b
    return a/b
   if isinstance(node,ast.Call) and isinstance(node.func,ast.Name):
    fun=node.func.id.upper();args=[calc(a) for a in node.args]
    if fun=='CELL' and len(args)==2:return self.get(*args)
    if fun=='RANGE' and len(args)==3:return self.range_values(*args)
    if fun=='MERGED' and len(args)==3:return self.merged_scalar(*args)
    if fun=='SUM':return sum((sum(v,Decimal(0)) if isinstance(v,list) else v for v in args),Decimal(0))
    if fun=='ROUND' and len(args)==2:
     n=int(args[1]);return args[0].quantize(Decimal('1').scaleb(-n),rounding=ROUND_HALF_UP)
    if fun=='MIN':return min(args)
    if fun=='MAX':return max(args)
   raise Blocked('EXPRESSAO_NAO_SUPORTADA')
  try:return calc(root)
  except (InvalidOperation,ZeroDivisionError,TypeError):raise Blocked('ERRO_NUMERICO')


def _quantize(v, rate=False):
    return v.quantize(Decimal('0.000001') if rate else Decimal('0.01'),rounding=ROUND_HALF_UP)

def inspect_workbook(path, max_findings=700):
    path=Path(path)
    if path.stat().st_size>6_000_000:raise ValueError('Planilha excede o limite de 6MB')
    with zipfile.ZipFile(path) as z:
        contents=z.infolist()
        if len(contents)>350 or sum(x.file_size for x in contents)>30_000_000:
            raise ValueError('Conteúdo XLSX excessivo')
        if any(x.file_size>8_000_000 for x in contents):raise ValueError('Componente XLSX excessivo')
        if 'xl/workbook.xml' not in z.namelist():raise ValueError('Estrutura de planilha inválida')
    sheets=load(path)
    evaluator=Evaluator(sheets)
    findings=[]; totals=collections.Counter()
    for sheet,cells in sheets.items():
        for addr,data in cells.items():
            formula=data['formula']
            if formula is None:continue
            raw=data['raw']
            try:cached=Decimal(str(raw)) if raw not in (None,'') else None
            except (InvalidOperation,ValueError):cached=None
            is_rate=addr.startswith(('C','D')) and addr[1:].isdigit()
            reason='';computed=None
            try:
                computed=evaluator.get(sheet,addr)
                if not isinstance(computed,Decimal):raise Blocked('RESULTADO_NAO_NUMERICO')
                if cached is None:status='SEM_CACHE'
                elif _quantize(computed,is_rate)!=_quantize(cached,is_rate):status='DIVERGE_CACHE'
                else:status='CONFERE_CACHE'
            except (Blocked,ArithmeticError,TypeError,ValueError,KeyError) as e:
                status='PENDENTE_FORMULA';reason=str(e)[:120]
            totals[status]+=1
            if len(findings)<max_findings:
                delta=None
                if computed is not None and cached is not None:
                    delta=str(_quantize(computed)-_quantize(cached))
                findings.append({'aba':sheet,'celula':addr,'formula':'='+formula,
                  'cache':str(cached) if cached is not None else None,
                  'recalculado':str(_quantize(computed,is_rate)) if computed is not None else None,
                  'diferenca_monetaria':delta,'status':status,'motivo':reason})
    # Achados são testes exploratórios, não classificação jurídica ou glosa.
    lookup={(x['aba'],x['celula']):x for x in findings}
    flagged=[]
    for sheet in sheets:
        if not sheet.lower().startswith('vigilante'):continue
        d=lookup.get((sheet,'D25'));e=lookup.get((sheet,'E25'))
        if d and e and d['status']=='DIVERGE_CACHE':
            flagged.append({'codigo':'GJ-001','aba':sheet,'origem':'D25',
               'reflexo':'E25','descricao':'Fórmula 1/12 difere da alíquota armazenada',
               'impacto_e25':e['diferenca_monetaria'],'classificacao':'ORIGEM_COM_REFLEXO',
               'ressalva':'Depende da metodologia contratual de precisão e da confirmação da planilha aprovada'})
        if 'noturno' in sheet.lower():
            cells=sheets[sheet]; c18=cells.get('C18',{}).get('raw'); f18=cells.get('E18',{}).get('formula') or ''
            if c18 is not None and re.search(r'20\s*%',f18) and Decimal(str(c18))!=Decimal('0.20'):
                flagged.append({'codigo':'GJ-002','aba':sheet,'origem':'C18/E18',
                   'classificacao':'CONFLITO_DE_PARAMETRO','descricao':'C18 difere do 20% literal em E18',
                   'parametro_exibido':str(c18),'formula':'='+f18,
                   'ressalva':'7h/8h dependem de escala e cálculo noturno efetivo'})
    return {'arquivo':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
      'folhas':list(sheets),'totais':dict(totals),'formulas_inspecionadas':sum(totals.values()),
      'achados_relevantes':flagged,'celulas':findings,'limite_detalhes':max_findings,
      'aprovado_financeiramente':False,'preco_por_posto_reconstruido':None,
      'deferimento':None,'observacao':'Verificação exploratória das fórmulas; caches são exclusivamente comparação. Não prova vínculo contratual, bases de incidência nem equivalência integral ao Excel.'}

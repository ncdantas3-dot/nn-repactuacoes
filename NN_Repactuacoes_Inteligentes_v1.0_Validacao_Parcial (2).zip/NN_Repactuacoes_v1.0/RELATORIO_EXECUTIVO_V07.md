# N & N Repactuações — Relatório técnico de execução v0.7

**Natureza:** evolução funcional de v0.6 para **v0.7 de desenvolvimento**, NÃO candidata homologada à comercialização.

## Origem e preservação

A implementação usa o projeto Web v0.6, mantendo as cinco abas, motor financeiro conservador, template XLSX, código-fonte, endpoints e rotinas de backup existentes. Dados de produção não foram migrados nem utilizados nos testes. A alteração de banco é **aditiva**, criando tabelas novas e colunas opcionais para registros de versão; isso não garante migração para PostgreSQL.

## Correções efetivamente executadas

1. **Manifesto documental por auditoria:** cada execução nova recebe uma entrada `analysis_snapshots`, identificando a auditoria, documentos vigentes/pedido/CCT, hashes e versão do motor. O SHA-256 do manifesto está disponível pela API.
2. **Controle de obsolescência:** o servidor compara *ID e SHA-256* de todos os três documentos com as fontes da auditoria antes de permitir decisões e movimentações de revisão.
3. **Histórico de alterações:** eventos de auditoria, decisões, checklist, retroativos e movimentações são registrados em `audit_events`, com autor e data.
4. **Relatório coerente por versão:** decisões, checklist, cenário de fechamento e retroativos são filtrados pela auditoria corrente. O relatório exibe o manifesto e informa quando os documentos foram substituídos.
5. **Retroativos e checklist:** novas movimentações ficam associadas à auditoria corrente; cálculos anteriores sem vínculo ficam preservados como históricos, sem serem misturados automaticamente no novo relatório.
6. **Fluxo inicial de revisão:** `RASCUNHO`, `EM_REVISAO`, `DEVOLVIDO`; o bloqueio de edição durante a revisão funciona. A ação de aprovação final está **intencionalmente bloqueada** enquanto o motor e o checklist jurídico estiverem incompletos.
7. **Interface:** seção de histórico de versões e movimentação na aba Auditoria, sem novas abas principais.

## Verificações reproduzíveis

Comando: `PYTHONPATH=. pytest -q` na raiz do projeto.

- Suíte original v0.6: **44/44 passaram**.
- Novos testes de manifesto/revisão, invalidação por substituição da CCT e relatório limitado à auditoria correta: **3/3 passaram**.
- Total: **47/47 passaram**.
- Sintaxe Python: `python -m py_compile app.py` — aprovada.
- Sintaxe JavaScript embutido: `node --check` — aprovada.

**Limitação dos testes:** não constituem revisão de segurança ofensiva, validação jurídica, ensaio completo em navegador, testes de carga ou homologação contábil de todas as rubricas.

## Pendências críticas: não declarar versão comercial

| Criticidade | Item não entregue nesta etapa | Por que bloqueia comercialização |
|---|---|---|
| P0 | Cálculo independente completo dos módulos 1–6 com bases aprovadas e CCT aplicada | Não é possível apurar o preço integral com segurança |
| P0 | Dicionário semântico homologado de fórmulas/células e reconciliação sem números de linhas fixos | Reconciliação ainda pode apresentar inconsistências em layouts distintos |
| P0 | Contrato/aditivos e planilha aprovada de origem certificados | Sem esses documentos não é possível concluir admissibilidade |
| P1 | Interpretação/validação da CCT por cláusula, categoria, vigência e região | Piso manual não é extração documental homologada |
| P1 | Aprovação final de revisor com conferência jurídica integral | A aprovação está bloqueada por proteção |
| P1 | Retroativos integrados aos valores homologados e medições efetivas | Valores são cenários condicionados |
| P2 | PostgreSQL, criptografia e backup externo/restauração em produção | Persistência e continuidade comercial não homologadas |
| P2 | Testes reais HTTPS, isolamento multicliente em hospedagem, recuperação de acesso e proteção contra CSRF | Segurança de produção não demonstrada |
| P2 | Exportação nativa PDF, DOCX e XLSX dos pareceres | Persistem minutas HTML e relatórios técnicos limitados |

## Operação

Executar `INICIAR_WINDOWS.bat` no Windows, com Python 3.11+ e dependências instaladas. Usar **somente em ambiente de testes local**, sem dados pessoais sensíveis. Criar backup de `data/` antes de atualizar. A consulta de versões é feita em **Auditoria → Versões e rastreabilidade**; a API permite `GET /api/processes/{id}/versions` e `POST /api/processes/{id}/review`.

**Conclusão:** correções reais de integridade e rastreabilidade entregues; o sistema **permanece em desenvolvimento**, não sendo adequado a decisões de pagamento ou à comercialização como auditor integral.

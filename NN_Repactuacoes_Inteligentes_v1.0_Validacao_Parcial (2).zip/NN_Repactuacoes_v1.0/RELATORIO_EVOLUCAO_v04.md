# N & N Web v0.4 — Fechamento condicionado

## Implementações reais
- `closing.py`: diagnóstico por módulo, explicando rubricas sem recálculo e as bases condicionadas.
- Cenário matemático do Módulo 6, com custo M1–M5, indiretos, lucro e tributos calculados **por dentro** utilizando somente alíquotas C93/C94/D98/D99/D102 da planilha vigente.
- Cinco subtotais e evidências obrigatórios, sem aproveitamento automático do valor solicitado como base; modalidade do lucro selecionada pelo usuário.
- API autenticada e escopada à organização; resultados de cenários armazenados com histórico em SQLite, associados a uma auditoria existente.
- Interface na aba Auditoria, com fórmula e memória; mantém as cinco abas principais.

## Limitações críticas
- Totais informados são declarações, não resultados conferidos independentemente.
- Lucro e alíquotas tributárias precisam ser confrontados com a proposta, regime e situação do contribuinte.
- Os módulos 4 e 5 continuam sem apuração automática integral; as regras condicionadas da v0.3 permanecem.
- Não há conclusão global ou autorização de pagamento.
- Segurança, multicliente e conformidade jurídica não estão homologados para produção.

## Evidência de testes (17/11/2026)

- Suíte original e ampliada: **23 testes aprovados**, executados com `python -m pytest -q tests/test_system.py tests/test_closing.py`.
- Sintaxe Python: `compileall` aprovado.
- Sintaxe JavaScript: `node --check` aprovado para o script da interface.
- Teste ponta a ponta: cadastro, importação do modelo, auditoria, cenário M6, leitura do histórico, autorização, emissão de minuta, rejeição de auditoria inexistente.
- Exemplo artificial de teste do M6, usando cinco totais hipotéticos: M1–M5 R$ 4.350,00, indiretos R$ 187,05, lucro R$ 181,94, tributos R$ 446,84, preço simulado R$ 5.165,83. **Não são valores da GJ.**
- Os testes não validam a metodologia jurídica/tributária ou a conformidade do sistema para produção.

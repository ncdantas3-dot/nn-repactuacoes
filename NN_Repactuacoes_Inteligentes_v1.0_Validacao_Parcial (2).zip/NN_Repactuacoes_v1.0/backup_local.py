"""Backup offline autenticado pela posse do diretório local; mantenha cópias externas criptografadas."""
import os,sqlite3,hashlib,json,zipfile,datetime,io
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('NN_DATA_DIR',str(ROOT/'data')))
BACKUP=Path(os.environ.get('NN_BACKUP_DIR',str(ROOT/'backups')))

def create_backup():
    BACKUP.mkdir(parents=True,exist_ok=True)
    name=datetime.datetime.now(datetime.timezone.utc).strftime('NN_backup_%Y%m%d_%H%M%S_%f.zip')
    dst=BACKUP/name
    files=[]
    with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        if (DATA/'nn.sqlite3').exists():
            # SQLite online backup API garante snapshot transacional
            mem=sqlite3.connect(':memory:');source=sqlite3.connect(DATA/'nn.sqlite3')
            try:source.backup(mem)
            finally:source.close()
            dump='\n'.join(mem.iterdump()).encode('utf-8');mem.close()
            z.writestr('database.sql',dump);files.append({'path':'database.sql','sha256':hashlib.sha256(dump).hexdigest()})
        for f in sorted((DATA/'uploads').glob('*')) if (DATA/'uploads').exists() else []:
            if not f.is_file():continue
            blob=f.read_bytes();label='uploads/'+f.name;z.writestr(label,blob)
            files.append({'path':label,'sha256':hashlib.sha256(blob).hexdigest()})
        z.writestr('manifest.json',json.dumps({'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files},indent=2))
    return dst

def verify_backup(path):
    with zipfile.ZipFile(path) as z:
        mani=json.loads(z.read('manifest.json'))
        for item in mani['files']:
            if hashlib.sha256(z.read(item['path'])).hexdigest()!=item['sha256']:return False
        return True

if __name__=='__main__':
    p=create_backup();print(p);print('Hash de cada arquivo:', 'OK' if verify_backup(p) else 'FALHOU')

def restore_to_new_directory(archive, destination):
    """Restaura em pasta NOVA para testes. Nunca sobrescreve banco de producao."""
    destination=Path(destination)
    if destination.exists():raise FileExistsError('Destino deve ser inexistente para evitar sobrescrita')
    if not verify_backup(archive):raise ValueError('Hash do backup invalido')
    destination.mkdir(parents=True)
    with zipfile.ZipFile(archive) as z:
        manifest=json.loads(z.read('manifest.json'))
        for entry in manifest['files']:
            if entry['path']=='database.sql':
                db=sqlite3.connect(destination/'nn.sqlite3')
                try:db.executescript(z.read('database.sql').decode('utf-8'));db.commit()
                finally:db.close()
            elif entry['path'].startswith('uploads/'):
                f=Path(entry['path']).name
                (destination/'uploads').mkdir(exist_ok=True)
                (destination/'uploads'/f).write_bytes(z.read(entry['path']))
    return destination

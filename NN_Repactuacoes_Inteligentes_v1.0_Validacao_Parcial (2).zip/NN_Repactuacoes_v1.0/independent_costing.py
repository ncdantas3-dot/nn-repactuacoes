"""Motor financeiro independente e estrito baseado em evidências versionadas.

Nenhum total da empresa compõe a base de cálculo. Regras sem evidência,
valores inválidos ou dependências faltantes ficam PENDENTES. O motor não decide
juridicamente sobre o deferimento. São aceitas somente operações enumeradas;
nenhuma expressão arbitrária é executada.
"""
from __future__ import annotations
from decimal import Decimal, ROUND_HALF_UP
from collections import defaultdict
from engine import as_decimal, money

VERSION = 'NN-COSTING-0.8.0'
CENT = Decimal('0.01')
VALID_OPS = {'SOURCE_AMOUNT', 'DOCUMENTED_AMOUNT', 'RATE', 'SUM', 'MULTIPLY'}
VALID_MODULES = {'M1','M2','M3','M4','M5','M6'}
MAX_NODES = 140
# Mapa do modelo oficial Vigilante diurno (ARM.), derivado dos itens analíticos.
# Uma rubrica sem incidência precisa ser informada explicitamente como valor zero,
# com documentação justificativa; ausente nunca equivale a zero.
REQUIRED_ROWS = {
 'M1': {16,17,18,19,21},
 'M2': {25,26,*range(30,38),40,41,42,43,44,47},
 'M3': {57,58,59,60,61},
 'M4': {65,66,67,68,69,70,74},
 'M5': {83,84,85,86,87},
 'M6': {93,94,98,99,102},
}

class CostingValidationError(ValueError):
    pass

def _decimal(value, field):
    v = as_decimal(value)
    if v is None or not v.is_finite() or abs(v) > Decimal('1e12'):
        raise CostingValidationError(f'{field}: número ausente/inválido ou fora do limite')
    return v

def _evidence(item):
    # Evidência é texto fornecido pelo analista, não validação jurídica automática.
    e = str(item.get('evidence') or '').strip()
    if len(e) < 8 or len(e) > 500:
        return None
    return e

def reconstruct(vigente:dict, pedido:dict, rules:list[dict], *, strict=True):
    """Recalcula um conjunto versionado de regras com rastreabilidade.

    SOURCE_AMOUNT: lê uma célula do documento VIGENTE, nunca da solicitada.
    DOCUMENTED_AMOUNT: valor parametrizado e evidenciado (ex.: piso CCT conferido).
    RATE: (soma das referências) x alíquota localizada na planilha VIGENTE
          ou fonte externa explicitamente identificada; percentuais são frações.
    SUM: soma dependências (sem voltar a incluir subtotal em outro subtotal).
    MULTIPLY: valor de uma dependência x fator comprovado, como postos.
    """
    if not isinstance(rules,list) or not (1 <= len(rules) <= MAX_NODES):
        raise CostingValidationError('Informe de 1 a 140 regras')
    old = (vigente or {}).get('rows',{})
    requested = (pedido or {}).get('rows',{})
    nodes={}
    mapped_rows={}
    for i, item in enumerate(rules):
        if not isinstance(item,dict): raise CostingValidationError(f'Regra {i}: objeto inválido')
        rid=str(item.get('id','')).strip()
        if not rid or len(rid)>72 or rid in nodes:
            raise CostingValidationError('Identificador de rubrica ausente, duplicado ou extenso')
        op=item.get('op'); module=item.get('module')
        if op not in VALID_OPS or module not in VALID_MODULES:
            raise CostingValidationError(f'{rid}: tipo de cálculo ou módulo não permitido')
        refs=item.get('refs',[])
        if not isinstance(refs,list) or len(refs)>40 or len(set(refs))!=len(refs):
            raise CostingValidationError(f'{rid}: dependências repetidas ou inválidas')
        if op in ('SOURCE_AMOUNT','DOCUMENTED_AMOUNT') and refs:
            raise CostingValidationError(f'{rid}: valor de origem não aceita dependências')
        if op in ('SUM','RATE') and not refs:
            raise CostingValidationError(f'{rid}: é obrigatória a base documentada')
        if op=='MULTIPLY' and len(refs)!=1:
            raise CostingValidationError(f'{rid}: MULTIPLY requer uma dependência')
        row=item.get('row')
        if row is not None:
            if not isinstance(row,int) or row not in REQUIRED_ROWS[module]:
                raise CostingValidationError(f'{rid}: célula de rubrica não reconhecida para {module}')
            if row in mapped_rows:
                raise CostingValidationError(f'{rid}: rubrica E{row} duplicada; anterior {mapped_rows[row]}')
            mapped_rows[row]=rid
        nodes[rid]=item
    for rid,item in nodes.items():
        for dep in item.get('refs',[]):
            if dep not in nodes:
                raise CostingValidationError(f'{rid}: dependência {dep} inexistente')
    visiting=set();visited=set();order=[]
    def visit(rid):
        if rid in visiting:raise CostingValidationError(f'Dependência circular envolvendo {rid}')
        if rid in visited:return
        visiting.add(rid)
        for dep in nodes[rid].get('refs',[]): visit(dep)
        visiting.remove(rid);visited.add(rid);order.append(rid)
    for rid in nodes:visit(rid)
    # No nível de somatórios, o mesmo componente não pode entrar duas vezes.
    # Bases usadas por percentuais são cálculos derivados e não são somadas
    # novamente: interrompe-se a expansão em RATE.
    def additive_leaves(rid):
        node=nodes[rid]
        if node['op'] in ('SUM','MULTIPLY'):
            leaves=[]
            for dep in node.get('refs',[]):leaves.extend(additive_leaves(dep))
            return leaves
        return [rid]
    for rid,item in nodes.items():
        if item['op']=='SUM':
            leaves=additive_leaves(rid)
            if len(leaves)!=len(set(leaves)):
                raise CostingValidationError(f'{rid}: componente duplicado na soma (risco de dupla contagem)')
    outputs={}
    for rid in order:
        item=nodes[rid]; op=item['op'];refs=item.get('refs',[])
        evidence=_evidence(item)
        row=item.get('row')
        base={'id':rid,'module':item['module'],'name':str(item.get('name') or rid),
              'operation':op,'refs':refs,'row':row,'source':item.get('source'),
              'evidence':evidence,'amount':None,'status':'PENDENTE',
              'formula':None,'blockers':[],'requested':None,'difference':None,
              'legally_eligible':None}
        if isinstance(row,int) and 1<=row<=125:
            request_value=as_decimal(requested.get(str(row),{}).get('E'))
            base['requested']=str(money(request_value)) if request_value is not None else None
        if not evidence:base['blockers'].append('Ausência de referência documental da regra')
        missing=[dep for dep in refs if outputs[dep]['amount'] is None]
        if missing:base['blockers'].append('Dependências não concluídas: '+', '.join(missing))
        try:
            value=None;formula=None
            if op=='SOURCE_AMOUNT':
                cell=str(item.get('cell') or '')
                if (len(cell)<2 or cell[0] not in 'ABCDE' or not cell[1:].isdigit()
                    or not 1<=int(cell[1:])<=125):
                    raise CostingValidationError('Célula vigente inválida')
                raw=old.get(cell[1:],{}).get(cell[0]);value=_decimal(raw,cell)
                formula=f'VIGENTE!{cell} = {value}'
            elif op=='DOCUMENTED_AMOUNT':
                value=_decimal(item.get('value'),'valor documentado')
                formula=f'Valor documental: {value}'
            elif not missing:
                basis=sum((Decimal(outputs[d]['amount']) for d in refs),Decimal(0))
                if op=='SUM':value=basis;formula=' + '.join(refs)
                elif op=='RATE':
                    rate_cell=item.get('rate_cell')
                    if rate_cell:
                        cell=str(rate_cell)
                        if cell[0] not in 'CD' or not cell[1:].isdigit() or not 1<=int(cell[1:])<=125:
                            raise CostingValidationError('Célula da alíquota inválida')
                        rate=_decimal(old.get(cell[1:],{}).get(cell[0]),'alíquota vigente '+cell)
                        rate_source=f'VIGENTE!{cell}'
                    else:
                        rate=_decimal(item.get('rate'),'alíquota documentada')
                        rate_source=str(item.get('rate_source') or '').strip()
                        if len(rate_source)<6:raise CostingValidationError('Origem da alíquota ausente')
                    if not 0 <= rate <= 1:raise CostingValidationError('Alíquota fora de 0% a 100%')
                    value=basis*rate;formula=f'({" + ".join(refs)}) = {basis}; x {rate} ({rate_source})'
                elif op=='MULTIPLY':
                    factor=_decimal(item.get('factor'),'quantitativo/fator')
                    if factor<0:raise CostingValidationError('Fator negativo não permitido')
                    if not str(item.get('factor_source') or '').strip():raise CostingValidationError('Fator sem fonte')
                    value=basis*factor;formula=f'{refs[0]} ({basis}) x {factor} ({item["factor_source"]})'
            if value is not None and evidence and not missing:
                amount=money(value)
                base.update(amount=str(amount),formula=formula,status='CALCULO_CONDICIONADO',
                            rounding='ROUND_HALF_UP / 0,01 por rubrica')
        except CostingValidationError as exc:
            base['blockers'].append(str(exc))
        if base['amount'] is not None and base['requested'] is not None:
            base['difference']=str(money(Decimal(base['requested'])-Decimal(base['amount'])))
        outputs[rid]=base
    # O preço por posto só é emitido quando há nó final explicitamente definido
    # e TODAS as rubricas analíticas da modelagem estão completas.
    finals=[r for r in rules if r.get('final_price') is True]
    if len(finals)>1:raise CostingValidationError('Apenas um nó pode ser o preço final')
    final_id=finals[0]['id'] if finals else None
    missing_rows={m:sorted(REQUIRED_ROWS[m]-set(mapped_rows)) for m in sorted(VALID_MODULES)}
    has_all_modules=VALID_MODULES.issubset({r['module'] for r in rules})
    # O total final precisa ser uma soma explícita, sem depender de total do pedido.
    valid_final=(final_id is not None and nodes[final_id]['op']=='SUM'
                 and nodes[final_id].get('row') is None)
    final_coverage=set()
    def expand_all(rid):
        if rid in final_coverage:return
        final_coverage.add(rid)
        for dep in nodes[rid].get('refs',[]):expand_all(dep)
    if final_id:expand_all(final_id)
    orphan_analytical=[rid for rid,item in nodes.items() if item.get('row') is not None and rid not in final_coverage]
    complete=(has_all_modules and not any(missing_rows.values()) and not orphan_analytical
              and all(v['amount'] is not None for v in outputs.values()) and valid_final)
    # Marcador de avaliação financeira condicionado: não representa apuração homologada.
    price=outputs[final_id]['amount'] if complete else None
    module_summaries={}
    for module in sorted(VALID_MODULES):
        leaves=[v for v in outputs.values() if v['module']==module and v['operation'] not in ('SUM','MULTIPLY')]
        module_summaries[module]={'rubricas':len(leaves),'pendentes':sum(v['amount'] is None for v in leaves),
                                  'status':'COMPLETO_CONDICIONADO' if leaves and all(v['amount'] is not None for v in leaves) else 'PENDENTE'}
    return {'motor':VERSION,'rubricas':[outputs[rid] for rid in order], 'modules':module_summaries,
            'recalculo_financeiro_condicionado':price,'valor_proposto_deferimento':None,
            'all_rules_complete':complete,'orphan_analytical_ids':orphan_analytical,'required_missing_rows':missing_rows,'unresolved':[v['id'] for v in outputs.values() if v['amount'] is None],
            'status':'CENARIO_COMPLETO_CONDICIONADO' if complete else 'PENDENTE',
            'notice':'Resultado usa fontes declaradas e alíquotas da planilha vigente; não comprova aprovação da proposta, incidências jurídicas ou exigibilidade. Totais solicitados não integram cálculo.'}


def draft_rules():
    """Esqueleto integral sem valores ou bases presumidas.

    O analista precisa associar cada rubrica à fonte e operação adequada.
    Nunca é usado automaticamente para fechar um pedido.
    """
    from incidence import MATRIX
    names={item['row']:item['name'] for item in MATRIX}
    return [dict(id=f'R{row}',module=module,row=row,name=names.get(row,f'Rubrica E{row}'),
                 op='DOCUMENTED_AMOUNT',value='',evidence='',
                 source='PENDENTE: vincular contrato/CCT/planilha vigente',refs=[])
            for module, rows in sorted(REQUIRED_ROWS.items()) for row in sorted(rows)]

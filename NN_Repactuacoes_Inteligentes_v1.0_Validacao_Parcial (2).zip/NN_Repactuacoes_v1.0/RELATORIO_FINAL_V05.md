# N & N Repactuações Inteligentes — Relatório de entrega v0.5

**Status:** MVP operacional local ampliado. **NÃO HOMOLOGADO PARA COMERCIALIZAÇÃO OU DEFERIMENTO AUTOMÁTICO.**

## Origem e preservação

A versão é derivada do aplicativo web v0.4; preserva as cinco abas (Painel, Processos, Documentos, Auditoria e Parecer), o banco SQLite, as rotinas existentes de cálculo, a importação XLSX e o modelo **Vigilante diurno (ARM.)**. Não substitui os arquivos originais entregues em versões anteriores.

## Implementações efetivamente realizadas

| Item | Situação | Observação técnica |
|---|---|---|
| Reconciliação independente de somatórios | Implementado e testado | 13 grupos/submódulos com identificação de lacunas e diferenças; verifica soma de valores recebidos e não incidências legais |
| Associação de hashes de documentos a cada auditoria | Implementado | Fonte `vigente` e `pedido` permanece registrada com ID e SHA-256 em `runs.results.fontes` |
| Alerta de documento substituído após a auditoria | Implementado | Minuta destaca alteração de hash na fonte |
| Bloqueio de fechamento com planilha vigente substituída | Implementado | Exige novo cálculo a partir da planilha vigente recém-importada |
| RBAC inicial | Implementado | Perfis ADMIN/ANALISTA autorizados a registrar alterações; REVISOR/CONSULTA somente leitura nesta versão |
| Cadastro de usuários pelo administrador | API funcional, sem interface de administração | Endpoints `GET/POST /api/users` |
| Expiração de sessões | Implementado | Oito horas, verificação no backend |
| Limite de tentativas de login | Implementado localmente | Janela de 5 minutos por usuário, apenas adequado à instância local, não a múltiplos workers |
| Headers HTTP e prevenção de cache | Implementado | CSP básico, X-Frame-Options, nosniff, no-store |
| Validação básica de arquivos Office compactados | Implementado | Limite de tamanho descompactado, número de itens e caminhos; não substitui verificação antimalware |
| Download de original por ID/organização/hash | Implementado | Retorna erro diante de quebra de integridade |
| Backup de banco + documentos | Implementado | Snapshot SQL e arquivos com manifesto de hashes |
| Restauração segura para pasta nova | Implementado e testado | Não sobrescreve dados existentes |
| Motor Decimal parcial, retroativos condicionados e fechamento provisório | Preservados | Não configura recálculo integral homologado |

## Testes e evidência

Executado `pytest -q` no código da v0.5: **32 testes passaram**. Verificação de sintaxe Python (`python -m py_compile *.py`) e JavaScript (`node` compilando script da interface): **aprovadas**. Testes adicionais cobrem reconciliação exata e divergente, células não preenchidas, valores NaN/Infinity, controle de acesso por papel, isolamento entre organizações, expiração de sessão, upload de ZIP inflado, download de documento e backup/restauração.

## Limitações críticas para versão comercial

1. Cálculos dos seis módulos não foram integralmente reimplementados com todas as bases contratuais e cadeias de incidência. A v0.5 **não produz valor global de deferimento**.
2. O arquivo oficial disponibilizado possui rubricas e percentuais de referência; alíquotas tributárias, provisões, encargos e jornadas precisam ser confrontados com **a última planilha aprovada e o instrumento coletivo**. Um arquivo importado não prova sua aprovação.
3. A CCT é anexada, porém **não é extraída e validada automaticamente**; o piso ainda é informado pelo analista.
4. O modelo específico da aba Vigilante diurno armado ainda limita as importações: não é um parser genérico de XLSX e não cobre todas as categorias.
5. Os retroativos dependem de quantidades, glosas e efeitos financeiros inseridos pelo analista e não representam medições verificadas.
6. O banco SQLite, tokens do lado do navegador, RBAC básico e a política de login local não equivalem a uma implantação web multicliente robusta; faltam PostgreSQL, trilhas imutáveis, políticas de senhas e recuperação, backups externos criptografados, gerenciamento de segredos, proteção anti-CSRF/cookies adequados e testes de penetração.
7. Não há assinaturas digitais nem parecer conclusivo juridicamente validado; apenas **minuta técnica**.
8. A validação visual ponta a ponta em navegador real não foi executada nesta rodada. Os testes são majoritariamente de backend e verificação sintática da interface.
9. O teste de restauração foi realizado em diretório novo e com dados de teste, não em infraestrutura de produção.
10. Os 13 grupos de reconciliação são baseados em posições do modelo oficial e requerem homologação de mapeamento para cada versão do layout; em caso de falta de item, o grupo fica `INCOMPLETO`.

## Bloqueio de produção

**Não publicar em endereço acessível pela internet com dados reais de contratos ou trabalhadores.** O presente pacote é destinado à homologação funcional local. O aceite comercial demanda, no mínimo: verificação jurídica das regras, motor integral independente, teste de amostras reais com gabaritos independentes, autenticação e isolamento formalmente homologados, backups externos e restauração comprovada, documentação de segurança e validação por responsável técnico.

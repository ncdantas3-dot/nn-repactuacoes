# N & N Repactuações Inteligentes — evolução MVP v0.2

Data de desenvolvimento: 17/11/2026. **Uso local de desenvolvimento; não homologado para produção.**

## Melhorias efetivamente implementadas

1. **Regras adicionais por rubrica (M3–M6):** no menu Auditoria, o analista pode declarar a linha, o valor da base, sua descrição e uma evidência. O sistema localiza uma alíquota explícita da **planilha vigente** nas colunas C ou D e calcula `ROUND_HALF_UP(base × alíquota, 2)` com `Decimal`.
2. O resultado recebe status `CALCULO_CONDICIONADO`, distinto de concordância matemática integral ou deferimento jurídico. Sem alíquota válida na planilha vigente, a rubrica permanece pendente. O mesmo código impede declarações duplicadas e fora da lista de linhas suportadas.
3. **Retroativos por competência:** nova seção dentro da quarta aba, sem criar menu extra. Permite declarar mês, quantidade, valor anterior e novo, fração efetivamente executada, pagamentos anteriores, glosas e justificativa. Apuração `arred((novo − anterior) × quantidade × fração, 2) − pago − glosa` por competência. Registra o cálculo e a entrada no SQLite sem sobrescrever execuções anteriores.
4. **Parecer:** inclui a memória do último cálculo de retroativos do processo e permanece rotulado como **MINUTA**, sem homologação automática.
5. **Segurança lógica das operações:** processos continuam vinculados à organização da sessão; validações de competência duplicada, fração 0–1 e limites numéricos; nenhuma regra altera a planilha original.

## Testes e evidências

`pytest -q` — **12 testes aprovados** no ambiente de desenvolvimento. `python -m py_compile app.py engine.py` e `node --check` no script extraído da interface — aprovados. Os testes abrangem o fluxo anterior, cálculo condicionado, bloqueio de regras inválidas, retroativos por competências distintas, persistência, rejeição de duplicidade e fração fora da faixa. Não houve homologação visual completa em navegadores ou implantação em HTTPS.

## Limitações críticas ainda não resolvidas

- **Não existe recálculo automático integral dos módulos 3–6.** A base informada pelo analista não é extraída ou homologada automaticamente; apenas a operação matemática é reproduzível.
- **Não há prova de que os percentuais ou as bases constem da última planilha contratual aprovada.** A existência de uma célula não prova admissibilidade jurídica.
- **Remuneração noturna, jornadas, benefícios e incidências complexas** continuam pendentes de metodologia documentada e testes independentes.
- **Retroativos** dependem de quantitativos e valores informados manualmente; não há integração com medições, histórico de postos, datas de eficácia, feriados ou pagamentos.
- **Não há confirmação automatizada de CCT**, nem análise jurídica completa de anualidade, preclusão, bases e versões das normas.
- **MVP local SQLite**, login inicial e isolamento lógico por organização não substituem infraestrutura multicliente homologada, HTTPS, backups externos ou testes de segurança de produção.
- O importador aceita apenas o modelo de uma aba. A exportação PDF é por impressão do HTML, não gerador PDF nativo.

## Critério para avanço

Próximo marco: fixar a matriz **rubrica → base de incidência → documento → fórmula → arredondamento**, consolidar a última planilha aprovada e demonstrar valores analíticos para M1–M6 com testes centavo a centavo, antes de permitir qualquer total integral ou deferimento.

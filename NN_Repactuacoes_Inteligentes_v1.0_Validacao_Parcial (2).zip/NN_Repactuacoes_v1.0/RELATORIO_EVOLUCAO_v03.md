# N & N Repactuações Web v0.3 — Matriz de incidências

## Entrega
- `incidence.py`: matriz versionada por rubrica com fonte da taxa, base necessária e dependências.
- Endpoint autenticado `GET /api/incidence-matrix`.
- Nova área de consulta na aba **Auditoria**, mantendo as cinco abas principais.
- Recálculo **condicionado** das rubricas M3 E57–E61 quando salário, periculosidade, 13º e férias estão calculados, e o pedido informa zeros explícitos nas demais parcelas de remuneração E17–E19.
- Qualquer campo de remuneração não informado bloqueia esse cálculo; nenhuma linha de M4–M6 tem cálculo automático sem base integral comprovada.
- Resultados mantêm `valor_matematicamente_apurado=null` e `valor_proposto_deferimento=null` até conclusão de todas as rubricas.

## Limitações críticas
- A fórmula de M3 (M1 + submódulo 2.1) foi parametrizada conforme o layout exemplificativo e precisa de validação contra a planilha contratual efetivamente aprovada.
- A conclusão jurídica e a aderência de percentuais rescisórios ao contrato não são automáticas.
- A CCT é anexada, mas suas cláusulas ainda não são extraídas automaticamente; piso continua declarado pelo analista.
- A leitura atual da planilha preserva valores, mas não valida ainda toda a árvore de fórmulas do Excel.
- SQLite e autenticação MVP não têm homologação de segurança multicliente para produção.

## Uso
1. Atualizar pela pasta v0.3 (não substituir banco de dados em produção); preservar a pasta `data` antiga.
2. Iniciar `INICIAR_WINDOWS.bat`.
3. Importar o modelo vigente e solicitado, anexar CCT e informar piso validado.
4. Em casos sem adicionais de M1, informar `0` explicitamente em E17, E18 e E19.
5. Executar auditoria e consultar `Matriz de incidências documentadas`.
6. Tratar recálculo M3 como **cenário condicionado**, não autorização de pagamento.

"""Verificação local read-only de planilha, sem usar resultados do pedido como base.
Uso: python VALIDAR_GJ_2025.py caminho/planilha.xlsx caminho/saida.json
"""
import sys,json
from pathlib import Path
from workbook_forensics import inspect_workbook

def main():
    if len(sys.argv)!=3:
        print('Uso: python VALIDAR_GJ_2025.py arquivo.xlsx resultado.json')
        return 2
    source,output=Path(sys.argv[1]),Path(sys.argv[2])
    if not source.is_file() or source.suffix.lower()!='.xlsx':
        print('Informe uma planilha XLSX existente')
        return 2
    out=inspect_workbook(source)
    output.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Fórmulas verificadas:',out['formulas_inspecionadas'])
    print('Estados:',out['totais'])
    print('Preço por posto reconstruído:',out['preco_por_posto_reconstruido'])
    print('Resultado:',output)
    return 0
if __name__=='__main__':raise SystemExit(main())

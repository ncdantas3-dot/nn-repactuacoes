# Guia de atualização — v0.7

1. Interrompa a instância antiga do servidor.
2. Faça backup do diretório `data/` da v0.6; armazene cópia em local protegido.
3. Extraia este pacote em diretório **novo**, sem sobrescrever os arquivos-fonte da v0.6.
4. Se for migrar dados locais, copie `data/` com o banco e documentos para o diretório novo antes de iniciar; não troque os bancos durante a execução.
5. Execute `INICIAR_WINDOWS.bat` ou instale dependências em um ambiente virtual e inicie `uvicorn app:app --host 127.0.0.1 --port 8000`.
6. A inicialização executa alterações de esquema **aditivas** em SQLite. Os registros preexistentes não terão manifestos retroativos inventados; gere uma nova auditoria para obter versão e vínculo documental.
7. Entre na aba **Auditoria** e confira a seção **Versões e rastreabilidade da análise**.
8. Execute os testes: `python -m pytest -q` (necessário `pytest` no ambiente de testes).
9. Confirme que não há erros nem documentos originais faltando.

**Atenção:** não implantar em servidor público. V0.7 não representa homologação financeira, tributária ou jurídica; modelos e parâmetros de 2024/2025 requerem conferência com documentos efetivamente aprovados.

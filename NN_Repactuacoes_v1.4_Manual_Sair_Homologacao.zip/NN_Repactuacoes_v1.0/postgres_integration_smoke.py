"""Teste transacional e isolado de PostgreSQL.
Cria tabelas em SCHEMA descartável e encerra tudo com ROLLBACK, sem tocar
em tabelas existentes; exige explicitamente NN_ALLOW_PG_SMOKE=1.
Executar SOMENTE no banco exclusivo de homologação N&N Repactuações.
"""
import hashlib, json, os, secrets, sys
from postgres_store import DDL, DbConnection


def run(url):
    import psycopg
    from psycopg.rows import dict_row
    name='nn_smoke_'+secrets.token_hex(6)
    con=psycopg.connect(url,row_factory=dict_row,connect_timeout=10)
    result={'ok':False,'isolated_schema':True,'rolled_back':False,
            'tests':[],'scope':'PostgreSQL transacional, sem alteração persistida'}
    try:
        with con.cursor() as cursor:
            # schema aleatório gerado localmente (identificador não vem do usuário)
            cursor.execute('CREATE SCHEMA '+name)
            cursor.execute('SET LOCAL search_path TO '+name)
        db=DbConnection(con)
        db.executescript(DDL)
        oid=db.execute('INSERT INTO orgs(name) VALUES(?)',('Organizacao ficticia e temporaria',)).lastrowid
        uid=db.execute('INSERT INTO users(org_id,username,pw_hash,role) VALUES(?,?,?,?)',
                       (oid,'usuario_smoke','hash_ficticio_nao_utilizavel','ADMIN')).lastrowid
        row=db.execute('SELECT id,org_id FROM users WHERE id=?',(uid,)).fetchone()
        assert row['org_id']==oid
        result['tests'].append('INSERT/SELECT com identities e tenant')
        pid=db.execute('INSERT INTO processes(org_id,company,contract,status,created) VALUES(?,?,?,?,?)',
                       (oid,'Empresa ficticia','SMOKE-NAO-REAL','EM_ANALISE','2026-11-23')).lastrowid
        payload=b'%PDF-1.4\nconteudo de teste sem dados reais\n%%EOF'
        digest=hashlib.sha256(payload).hexdigest()
        did=db.execute('INSERT INTO documents(org_id,process_id,kind,filename,sha256,path,created) VALUES(?,?,?,?,?,?,?)',
                       (oid,pid,'cct','ficticio.pdf',digest,'/tmp/nn_nao_persistir','2026-11-23')).lastrowid
        db.execute('INSERT INTO document_blobs(document_id,content) VALUES(?,?)',(did,payload))
        blob=db.execute('SELECT content FROM document_blobs WHERE document_id=?',(did,)).fetchone()
        assert hashlib.sha256(bytes(blob['content'])).hexdigest()==digest
        result['tests'].append('documento BYTEA e SHA-256')
        assert not db.execute('SELECT id FROM processes WHERE id=? AND org_id=?',(pid,oid+12345)).fetchone()
        result['tests'].append('consulta com filtro de organizacao')
        result['ok']=True
    finally:
        con.rollback()
        result['rolled_back']=True
        con.close()
    return result


def main():
    if os.environ.get('NN_ALLOW_PG_SMOKE')!='1':
        print(json.dumps({'ok':False,'reason':'Confirmação NN_ALLOW_PG_SMOKE=1 ausente'}));return 2
    url=os.environ.get('NN_TEST_DATABASE_URL','').strip()
    if not url:
        print(json.dumps({'ok':False,'reason':'NN_TEST_DATABASE_URL ausente'}));return 2
    try:
        r=run(url)
        print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r['ok'] else 3
    except Exception as exc:
        # Nunca imprimir erro contendo URL de banco, senhas ou valores sigilosos.
        print(json.dumps({'ok':False,'reason':type(exc).__name__}));return 4
if __name__=='__main__':sys.exit(main())

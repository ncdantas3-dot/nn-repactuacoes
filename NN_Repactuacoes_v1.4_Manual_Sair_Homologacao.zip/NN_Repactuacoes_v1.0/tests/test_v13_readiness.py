from pathlib import Path
import sys, hashlib, subprocess, os, tempfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from postgres_readiness import inspect_connection
from workbook_forensics import load, Evaluator
from decimal import Decimal

class FakeCursor:
 def __init__(self, missing=(),blob_type='bytea',scoped=True):
  self.missing=set(missing);self.blob_type=blob_type;self.scoped=scoped;self.query=''
 def __enter__(self):return self
 def __exit__(self,*exc):pass
 def execute(self,query,params=None):self.query=query
 def fetchone(self):return ('nn_repactuacoes_homologacao','public','17.6')
 def fetchall(self):
  from postgres_readiness import TABLES
  if 'table_name FROM information_schema.tables' in self.query:return [(s,) for s in TABLES-self.missing]
  if 'column_name, data_type' in self.query:return [('document_id','bigint'),('content',self.blob_type)]
  if 'column_name=%s' in self.query:
   all_org={'users','processes','documents','runs','decisions','checklist','retroactive_runs','closing_runs','analysis_snapshots','audit_events','independent_costing_runs'}
   return [(s,) for s in (all_org if self.scoped else all_org-{'documents'})]
  return []
class FakeConn:
 def __init__(self, **kw):self.kw=kw
 def cursor(self):return FakeCursor(**self.kw)

def test_pg_readiness_good_schema():
 r=inspect_connection(FakeConn()); assert r['ready'] and not r['missing_tables']
def test_pg_readiness_rejects_missing_blob():
 r=inspect_connection(FakeConn(missing={'document_blobs'}));assert not r['ready']
def test_pg_readiness_rejects_incorrect_blob_type():
 r=inspect_connection(FakeConn(blob_type='text'));assert not r['ready']
def test_pg_readiness_rejects_missing_tenant_col():
 r=inspect_connection(FakeConn(scoped=False));assert not r['ready']
def test_pg_readiness_no_url_no_secret_in_stdout():
 root=Path(__file__).resolve().parents[1];env={k:v for k,v in os.environ.items() if k!='NN_DATABASE_URL'}
 r=subprocess.run([sys.executable,str(root/'postgres_readiness.py')],env=env,capture_output=True,text=True)
 assert r.returncode==2 and 'NN_DATABASE_URL ausente' in r.stdout

def test_gj_2025_formula_vs_cached_value_if_reference_attached():
 path=Path('/mnt/data/Planilha de Custos 2025 - GJ.xlsx')
 if not path.is_file():return
 sheets=load(path);s=sheets['Vigilante diurno (ARM.)']
 assert s['D25']['formula']=='1/12'
 cached=Decimal(str(s['E25']['raw']))
 calculated=Evaluator(sheets).get('Vigilante diurno (ARM.)','E25')
 assert abs(calculated-cached)>Decimal('0.01')
 # Uma diferença de cache NÃO determina deferimento nem classifica cobrança indevida.

def test_sqlite_persists_admin_process_document_across_process_restart(tmp_path):
 """Teste operacional local de persistência: dois processos Python independentes."""
 root=Path(__file__).resolve().parents[1]
 env={**os.environ,'NN_DATA_DIR':str(tmp_path),'NN_DATABASE_URL':''}
 create='''
from fastapi.testclient import TestClient
from app import app
from pathlib import Path
c=TestClient(app)
a=c.post('/api/setup',json={'org':'Empresa Teste Persistencia','username':'admin_teste','password':'S3nh4!Segura2026'})
assert a.status_code==200,a.text
login=c.post('/api/login',json={'username':'admin_teste','password':'S3nh4!Segura2026'})
assert login.status_code==200,login.text
h={'Authorization':'Bearer '+login.json()['token']}
p=c.post('/api/processes',headers=h,json={'company':'Teste de Persistencia','contract':'TESTE-2026'})
assert p.status_code==200,p.text
raw=(Path('assets')/'modelo_vigilante_diurno_armado.xlsx').read_bytes()
r=c.post(f"/api/processes/{p.json()['id']}/documents",headers=h,data={'kind':'vigente'},files={'file':('modelo.xlsx',raw)})
assert r.status_code==200,r.text
'''
 verify='''
from fastapi.testclient import TestClient
from app import app
c=TestClient(app)
assert c.get('/api/setup-status').json()['setup_required'] is False
r=c.post('/api/login',json={'username':'admin_teste','password':'S3nh4!Segura2026'})
assert r.status_code==200,r.text
h={'Authorization':'Bearer '+r.json()['token']}
ps=c.get('/api/processes',headers=h).json();assert len(ps)==1
pid=ps[0]['id']
docs=c.get(f'/api/processes/{pid}/documents',headers=h).json();assert len(docs)==1
resp=c.get(f"/api/processes/{pid}/documents/{docs[0]['id']}/download",headers=h)
assert resp.status_code==200
assert resp.content[:2]==b'PK'
'''
 for source in (create,verify):
  p=subprocess.run([sys.executable,'-c',source],cwd=root,env=env,text=True,capture_output=True)
  assert p.returncode==0,p.stdout+'\n'+p.stderr

def test_multisheet_real_gj_selection_does_not_pretend_full_coverage():
 path=Path('/mnt/data/Planilha de Custos 2025 - GJ.xlsx')
 if not path.is_file():return
 from xlsx_reader import read_first_sheet,workbook_sheet_names
 names=workbook_sheet_names(path)
 assert len(names)>1 and 'Vigilante noturno (ARM.)' in names
 name,rows=read_first_sheet(path)
 assert name=='Vigilante diurno (ARM.)' and len(rows)==125
 assert rows[15][4]==1639.14
 from app import extract
 report=extract(path)
 assert report['scope']=='UMA_CATEGORIA' and report['limitations']
 assert report['row_count']==125

def test_postgres_integration_smoke_requires_explicit_permission():
 root=Path(__file__).resolve().parents[1]
 env={k:v for k,v in os.environ.items() if k not in ('NN_ALLOW_PG_SMOKE','NN_TEST_DATABASE_URL')}
 p=subprocess.run([sys.executable,str(root/'postgres_integration_smoke.py')],env=env,text=True,capture_output=True)
 assert p.returncode==2 and 'NN_ALLOW_PG_SMOKE=1 ausente' in p.stdout

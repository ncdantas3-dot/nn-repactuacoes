# Relatório — v1.2 (23/11/2026)

- **Escopo:** ajuste no código isolado N & N Repactuações, preservando Conta Vinculada.
- **Excel:** cálculo matemático seguro para fórmulas suportadas com cache ausente, falha explícita para expressões desconhecidas; preserva extração das 125 linhas do modelo. Limitação de recálculo Excel completo permanece.
- **M1–M6:** prova sintética de fechamento condicionado de 43 rubricas, com soma R$ 43,00; não é prova de adequação de CCT ou aprovação contratual.
- **PostgreSQL:** schema PostgreSQL próprio, seleção via `NN_DATABASE_URL`, objetos `document_blobs` e recuperação de arquivo; falta homologação integrada em instância real.
- **Autenticação:** bloqueio de setup externo sem `NN_SETUP_TOKEN` suficientemente longo.
- **Testes locais:** 78 testes automatizados aprovados; `py_compile` e integridade ZIP serão confirmados no empacotamento.
- **Não executados:** restauração real de backup PostgreSQL, performance concorrente, isolamento multiorganizacional em servidor PostgreSQL, deploy na VPS/Render, auditoria financeira real de todos os seis módulos e emissão completa de parecer aprovada.
- **Status:** candidata técnica de HOMOLOGAÇÃO, NÃO aprovada comercialmente.

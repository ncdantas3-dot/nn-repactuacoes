"""Leitor XLSX restrito: preserva valores em cache e avalia apenas fórmulas matemáticas autorizadas quando o cache está ausente. Não é um motor Excel completo."""
from pathlib import Path
import posixpath
import re
import zipfile
from decimal import Decimal
from workbook_forensics import load as load_formula_graph, Evaluator, Blocked
from xml.etree import ElementTree as ET

_NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
_REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
_PKGREL = '{http://schemas.openxmlformats.org/package/2006/relationships}'


def read_first_sheet(path: str | Path, *, max_row: int = 125, max_col: int = 5):
    try:
        with zipfile.ZipFile(path) as arc:
            names = set(arc.namelist())
            for required in ('xl/workbook.xml', 'xl/_rels/workbook.xml.rels'):
                if required not in names:
                    raise ValueError('XLSX sem metadados obrigatórios')
            wb = ET.fromstring(arc.read('xl/workbook.xml'))
            sheets = wb.find(_NS + 'sheets')
            if sheets is None or not len(sheets):
                raise ValueError('XLSX sem abas')
            options = list(sheets)
            if len(options) == 1:
                item = options[0]
            else:
                matches = [x for x in options if x.attrib.get('name', '').strip().casefold() == 'vigilante diurno (arm.)']
                if len(matches) != 1:
                    raise ValueError('Planilha com múltiplas abas: aba Vigilante diurno (ARM.) ausente ou ambígua')
                item = matches[0]
                # Seleciona apenas a categoria armada diurna; não audita outras categorias automaticamente.
            sheet_name = item.attrib.get('name', '')
            rel_id = item.attrib.get(_REL + 'id', '')
            relations = ET.fromstring(arc.read('xl/_rels/workbook.xml.rels'))
            target = None
            for relation in relations:
                if relation.attrib.get('Id') == rel_id:
                    target = relation.attrib.get('Target')
                    break
            if not target:
                raise ValueError('Relação da aba não encontrada')
            sheet_path = posixpath.normpath(target.lstrip('/') if target.startswith('/') else posixpath.join('xl', target))
            if not sheet_path.startswith('xl/') or sheet_path not in names:
                raise ValueError('Arquivo interno de planilha inválido')

            strings = []
            if 'xl/sharedStrings.xml' in names:
                tree = ET.fromstring(arc.read('xl/sharedStrings.xml'))
                for si in tree.findall(_NS + 'si'):
                    strings.append(''.join(node.text or '' for node in si.iter(_NS + 't')))

            content = ET.fromstring(arc.read(sheet_path))
            rows = [[None] * max_col for _ in range(max_row)]
            formula_evaluator = None
            sheet_data = content.find(_NS + 'sheetData')
            if sheet_data is None:
                raise ValueError('Aba sem dados')
            for row in sheet_data.findall(_NS + 'row'):
                for cell in row.findall(_NS + 'c'):
                    address = cell.attrib.get('r', '')
                    match = re.fullmatch(r'([A-Z]+)([1-9][0-9]*)', address)
                    if not match:
                        continue
                    letters, digits = match.groups()
                    col = 0
                    for letter in letters:
                        col = col * 26 + ord(letter) - 64
                    row_num = int(digits)
                    if not (1 <= row_num <= max_row and 1 <= col <= max_col):
                        continue
                    type_name = cell.attrib.get('t')
                    value_tag = cell.find(_NS + 'v')
                    formula_tag = cell.find(_NS + 'f')
                    inline = cell.find(_NS + 'is')
                    raw = value_tag.text if value_tag is not None else None
                    if type_name == 'inlineStr':
                        value = ''.join(n.text or '' for n in inline.iter(_NS + 't')) if inline is not None else ''
                    elif type_name == 's':
                        if raw is None:
                            raise ValueError('Índice de texto compartilhado ausente')
                        idx = int(raw)
                        if not 0 <= idx < len(strings):
                            raise ValueError('Índice de texto compartilhado inválido')
                        value = strings[idx]
                    elif type_name == 'b':
                        value = raw == '1'
                    elif type_name in ('str', 'e'):
                        value = raw
                        if type_name == 'e':
                            raise ValueError(f'Erro em célula Excel: {address}')
                    elif raw is not None and raw != '':
                        numeric = float(raw)
                        value = int(numeric) if numeric.is_integer() else numeric
                    elif formula_tag is not None:
                        # Recalcular apenas expressões matemáticas suportadas, sem executar código Excel.
                        if formula_evaluator is None:
                            formula_evaluator = Evaluator(load_formula_graph(path))
                        try:
                            computed = formula_evaluator.get(sheet_name,address)
                            if not isinstance(computed,Decimal) or not computed.is_finite():
                                raise Blocked('RESULTADO_NAO_NUMERICO')
                            value = float(computed)  # compatibilidade com formato JSON legado
                        except (Blocked,ArithmeticError,TypeError,ValueError,KeyError) as exc:
                            raise ValueError(f'Fórmula sem cache não verificável em {address}: {str(exc)[:80]}') from exc
                    else:
                        value = None
                    rows[row_num - 1][col - 1] = value
            return sheet_name, rows
    except zipfile.BadZipFile as exc:
        raise ValueError('Arquivo XLSX inválido') from exc


def workbook_sheet_names(path: str | Path):
    """Nomes das abas do arquivo original, sem ler/executar fórmulas."""
    with zipfile.ZipFile(path) as arc:
        wb = ET.fromstring(arc.read('xl/workbook.xml'))
        sheets = wb.find(_NS + 'sheets')
        if sheets is None:
            raise ValueError('XLSX sem abas')
        return [item.attrib.get('name', '') for item in sheets]

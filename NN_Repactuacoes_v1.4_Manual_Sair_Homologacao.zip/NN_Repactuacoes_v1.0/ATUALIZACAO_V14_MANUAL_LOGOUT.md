# N & N Repactuações Inteligentes — v1.4

## Recursos adicionados

- **Sair do sistema** destacado no menu lateral, confirmação de saída, solicitação de revogação da sessão no servidor e remoção do token local. Caso a comunicação com o servidor falhe, o acesso local é encerrado e a interface informa que a revogação remota não foi confirmada.
- **Manual de utilização** acessível no menu lateral sem adicionar nova aba: procedimentos de primeiro acesso, processos, documentos, auditoria, parecer, segurança e logout.
- Manual com impressão / Salvar PDF pelo próprio navegador; fechamento por botão, área externa ou Escape.

## Dependências e limites

O manual é integrado em `static/index.html` e não exige dependências extras ou migração de banco. A autenticação atual utiliza `/api/logout` para revogação de sessão no backend. Não elimina o risco de persistência SQLite temporária na infraestrutura do Render. Antes de publicar, proteger dados existentes e confirmar PostgreSQL.

## Homologação

- 88 testes automatizados existentes passaram localmente.
- Código JavaScript compilado com Node.js sem erro de sintaxe.
- Não houve publicação no Render nem mudança no N & N Conta Vinculada.
- Testes manuais de interface no navegador e teste real de sessão em produção ainda pendentes.

## Publicação segura

O repositório GitHub está ligado ao ambiente público com deploy automático. Portanto, NÃO carregue a v1.4 na branch `main` sem previamente desativar o deploy automático no serviço público ou usar branch própria de homologação, backup e plano de reversão.

# N & N Repactuações Inteligentes — v1.2, pacote de homologação

## O que foi realmente implementado

1. **Importação Excel:** a planilha padronizada de 125 linhas continua sendo validada. Fórmulas sem resultado em cache podem ser calculadas por um avaliador **estritamente limitado** (aritmética, referências, SUM, ROUND e algumas funções previstas). Fórmulas desconhecidas, referências externas, macros e expressões não suportadas são rejeitadas. Isto **não equivale a um motor Excel completo**. Comparar com a planilha aprovada é obrigatório.
2. **Reconstrução independente em seis módulos:** a engine já existente foi mantida e submetida a teste sintético de cobertura completa das 43 rubricas previstas no modelo fixo, com memória por regra e total **condicionado**. O motor não extrai automaticamente todas as regras reais da CCT; o analista deve documentar bases, incidências e parâmetros. O valor de deferimento permanece vazio até revisão humana.
3. **PostgreSQL:** infraestrutura de tabelas, SQL e operações básicas integrada ao app e ativada **exclusivamente** quando `NN_DATABASE_URL` for configurada. Dados dos documentos são armazenados em `document_blobs` (BYTEA), além do armazenamento temporário local. Restauram-se arquivos da base quando a cópia temporária desaparece. Bancos SQLite anteriores não são migrados automaticamente.
4. **Cadastro inicial:** quando executado no Render ou PostgreSQL, exige `NN_SETUP_TOKEN` de pelo menos 24 caracteres. Se não for configurado, o cadastro público fica bloqueado (503). O token é solicitado na interface durante a primeira instalação e enviado apenas ao endpoint de setup; ele não deve ser enviado por mensagem, comitado nem compartilhado.
5. **Controle transparente:** `/api/storage-status`, autenticado, informa o backend ativo; não certifica backup nem homologação.

## Implantação Render (nova versão, não altera Conta Vinculada)

- Crie **um banco PostgreSQL dedicado** exclusivamente à aplicação `nn-repactuacoes`, com credenciais exclusivas; jamais reutilize URL, credenciais ou base do Conta Vinculada.
- No serviço Render `nn-repactuacoes`, configure `NN_DATABASE_URL` com a **Internal Database URL** do PostgreSQL novo e separado. Configure `NN_SETUP_TOKEN` com segredo aleatório >=24 caracteres. Configure `PYTHON_VERSION` para uma versão validada pela sua suíte (por exemplo, Python 3.12, após testes).
- **Atenção:** mudar de SQLite para PostgreSQL cria um novo banco vazio. A v1.2 NÃO migra usuários, documentos nem análises anteriores. Planeje migração e faça backup antes de trocar o backend.
- Código corrigido v1.2 **não foi publicado automaticamente neste atendimento**. O arquivo `NN_Repactuacoes_v1.2_Excel_PG.zip` deverá ser enviado ao repositório da aplicação, preferencialmente privado, em substituição à versão anterior. Ajuste a construção para selecionar exatamente o ZIP novo.

**Build Command**:

```bash
python -c "import zipfile; zipfile.ZipFile('NN_Repactuacoes_v1.2_Excel_PG.zip').extractall('.')" && pip install -r NN_Repactuacoes_v1.0/requirements.txt
```

**Start Command**:

```bash
cd NN_Repactuacoes_v1.0 && python -m uvicorn app:app --host 0.0.0.0 --port $PORT
```

## Segurança antes de divulgar endereço

- Render Free / banco PostgreSQL efêmero/gratuito **não equivale a armazenamento comercial com backup homologado**. Confirme retenção, renovação e SLA do plano real contratado.
- Ative acesso restrito no gateway/proxy e prepare a instalação com o token em canal privado.
- Teste restauro PostgreSQL + documentos e isolamentos por empresa. Não usar dados reais até homologação.
- Verifique que o cadastro foi concluído; teste acesso anônimo a processos, anexos, auditoria e parecer.
- Consulte `/api/storage-status` com Bearer após login: `motor_banco` deve ser `postgresql` e `documentos_persistidos_no_banco` deve ser `true`.
- Teste uploads/restarts/redeploys e recuperação documental; **não foi feito aqui teste real em Postgres nem no Render**, apenas testes automatizados locais com SQLite e testes do adaptador.

## Limites expressos

A cobertura é de 43 rubricas do **modelo padronizado de vigilante diurno armado**, não leitura universal de qualquer Excel nem reconstrução jurídica automaticamente validada. Diferenças de arredondamento e fórmulas Excel complexas precisam de validação especializada. A CCT anexada não deve ser interpretada como automaticamente validada. Não declarar produto pronto para comercialização.

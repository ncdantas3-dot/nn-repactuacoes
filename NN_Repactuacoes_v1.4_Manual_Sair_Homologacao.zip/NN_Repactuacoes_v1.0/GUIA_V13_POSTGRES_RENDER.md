# Homologação privada da v1.3 com PostgreSQL — sem tocar na Conta Vinculada

## 1. Isolamento obrigatório

- Não substituir automaticamente `https://nn-repactuacoes.onrender.com`.
- Não reutilizar banco, schema, usuários, documentos ou credenciais da Conta Vinculada.
- O PostgreSQL de homologação de Repactuações **já existe** no Render, porém pode estar sendo utilizado pelo serviço `nn-repactuacoes-v2`. Antes de associar a versão nova, conferir o uso e criar banco isolado ou schema específico controlado. Não fazer testes destrutivos no esquema existente.
- O banco existente está com IP allowlist vazia; a ferramenta de consulta externa não consegue acessá-lo. Nunca abrir IP `0.0.0.0/0` só para executar testes.

## 2. Teste da infraestrutura dentro da rede privada do Render

Na aplicação de homologação que utiliza uma **URL de banco exclusivamente destinada a ela**, instalar `psycopg[binary]` conforme `requirements.txt` e executar:

```bash
python postgres_readiness.py
```

Com `NN_DATABASE_URL` definida, exibe nomes das tabelas ausentes, tipo BYTEA, existência de `org_id` e versão do servidor, **sem mostrar a senha**. O script só faz consultas `SELECT`.

## 3. Teste transacional em base isolada

Após verificar que o banco é uma instância de homologação com permissão para criar schema, e com conexão `NN_TEST_DATABASE_URL` exclusiva, executar:

```bash
NN_ALLOW_PG_SMOKE=1 python postgres_integration_smoke.py
```

O script cria schema aleatório, tabelas temporárias por transação, dados fictícios, verifica armazenamento BYTEA/SHA-256 e filtro por organização e sempre encerra com `ROLLBACK`. Não modifica tabelas existentes. Requer privilégio de criação de schema e uma instância PostgreSQL acessível dentro da rede. Não foi executado nesta entrega.

## 4. Publicação da v1.3 (somente após aprovação de teste)

Upload do ZIP `NN_Repactuacoes_v1.3_Homologacao_Parcial.zip` para repositório **privado** do Repactuações, com build explícito:

```bash
python -c "import zipfile; zipfile.ZipFile('NN_Repactuacoes_v1.3_Homologacao_Parcial.zip').extractall('.')" && pip install -r NN_Repactuacoes_v1.0/requirements.txt
```

Start:

```bash
cd NN_Repactuacoes_v1.0 && python -m uvicorn app:app --host 0.0.0.0 --port $PORT
```

Variáveis da nova instância: `NN_DATABASE_URL` (segredo de banco isolado), `NN_SETUP_TOKEN` (segredo exclusivo com pelo menos 24 caracteres) e, se necessário, `PYTHON_VERSION` validado.

**Atenção:** a v1.3 não migra dados automaticamente do SQLite, nem proveu restauração real. Não mudar a variável `NN_DATABASE_URL` do serviço atualmente usado antes de backup, conferência e plano de reversão.

## 5. Critérios para marcar homologação

- PostgreSQL real: esquema, transação, blob original, SHA-256, recuperação após reinício.
- Isolamento por organização em todos os endpoints, autenticação e bloqueio de setup público.
- XLSX multiformato: por ora, somente categoria `Vigilante diurno (ARM.)` comprovada no caso GJ, demais categorias não cobertas.
- Reconstrução por 6 módulos com planilha aprovada e CCT conferida; valor proposto exige aprovação humana.
- Plano de backup/restauração e evidências executadas, não apenas scripts.

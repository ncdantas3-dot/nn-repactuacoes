# N & N Repactuações v1.3 — Resultado da execução (23/11/2026)

## Entrega efetivamente implementada

1. **Leitor Excel** passou a aceitar arquivos de múltiplas abas, selecionando explicitamente **Vigilante diurno (ARM.)** quando existir exatamente uma aba com esse nome. Arquivos com uma única aba continuam suportados. Importação de múltiplas categorias **não foi** implementada; o JSON extraído contém `workbook_sheet_names`, `scope=UMA_CATEGORIA` e `limitations` para impedir inferências de auditoria global.
2. **Motor independente** de 6 módulos mantido. Nenhum cálculo sintético foi promovido a parecer conclusivo; a reconstrução integral com enquadramento jurídico e última planilha aprovada permanece pendente.
3. **PostgreSQL**: adicionados `postgres_readiness.py` (inspeção somente leitura das tabelas, BYTEA e campos de organização) e `postgres_integration_smoke.py` (teste de CREATE SCHEMA em transação isolada, CRUD de dados sintéticos, documentos BYTEA e SHA-256, rollback obrigatório). O teste de escrita só funciona quando o operador fornece `NN_TEST_DATABASE_URL` e `NN_ALLOW_PG_SMOKE=1` em rede autorizada; não foi executado contra banco real.
4. **Persistência local demonstrada**: cadastro, processo e documento foram criados num primeiro processo Python, recuperados após iniciar outro processo, autenticados e baixados com sucesso.
5. **Auditoria documental GJ**: o caso de 2025, com múltiplas abas, agora permite importação da categoria armada diurna, com teste da fórmula de 13º `D25=1/12` contra o valor armazenado. A discrepância de cache não prova cobrança indevida ou valor deferível.

## Resultado verificável

- **88 testes locais passaram** (`python -m pytest -q`).
- **Compilação Python** (`python -m compileall -q .`) concluída.
- Teste da leitura de arquivo Excel real foi executado na sessão local; o arquivo GJ **não está incluído** na entrega.
- `artifact_tool` não conseguiu importar a planilha GJ devido a metadado inválido (`Comment createdAt is required`); o leitor OpenXML restrito do próprio sistema foi usado como meio alternativo e os dados originais não foram modificados.

## Estado do Render / banco real

- Existe o PostgreSQL Render **`nn-repactuacoes-homologacao`** (`dpg-dbuu2td6e07s73emhmjg-a`), PostgreSQL 17, plano Free, status `available`, vencimento informado em **18/12/2026**.
- **Bloqueio confirmado:** a lista de IP permitidos está vazia e a integração externa não pôde executar nem consulta `SELECT` neste banco. Não modifiquei regras de rede ou credenciais.
- O banco é destinado a ambiente Repactuações já existente, e **não foi associado** à v1.3 para evitar compartilhamento acidental de schema ou dados.
- Nenhum deploy, mudança de configuração, cadastro ou mutação de banco foi feito nos serviços Render. **Conta Vinculada não alterado.**

## Impedimentos à homologação final

1. Testes integrados reais PostgreSQL, incluindo persistência após reinício e recuperação de anexos. O teste transacional disponibilizado facilita a validação, mas não substitui teste da aplicação implantada.
2. Backup/restauração comprovados em instância PostgreSQL com política de retenção.
3. Migração controlada do SQLite anterior, **sem sobrescrever usuários ou documentos**.
4. Motor financeiro multi-categoria completo, regras CCT confirmadas, última planilha contratual aprovada e cálculo independente por rubrica com valores de referência homologados.
5. Isolamento multiorganização e autenticação submetidos a testes de segurança em ambiente publicado.
6. Hospedagem PostgreSQL com política de persistência e vencimento compatível com operação real. Plano Free e banco com data de expiração não são garantia de produção.

**Classificação:** pacote de engenharia v1.3 para HOMOLOGAÇÃO, não comercialmente homologado.

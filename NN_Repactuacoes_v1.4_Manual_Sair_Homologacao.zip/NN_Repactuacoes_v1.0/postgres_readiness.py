"""Verificação SOMENTE LEITURA da base exclusiva do N&N Repactuações.
Use a partir da rede privada do Render: NN_DATABASE_URL=... python postgres_readiness.py
Não mostra credenciais, não altera schema, não cria dados.
"""
import json, os, sys

TABLES = {'orgs','users','sessions','processes','documents','document_blobs','runs',
          'decisions','checklist','retroactive_runs','closing_runs','analysis_snapshots',
          'audit_events','independent_costing_runs'}

def inspect_connection(conn):
    result = {'database':None,'schema':None,'server_version':None,
              'required_tables':len(TABLES),'missing_tables':[],
              'document_blob_column':False,'tenant_scoped_tables':False,'ready':False}
    with conn.cursor() as c:
        c.execute('SELECT current_database(),current_schema(),current_setting(%s)',('server_version',))
        result['database'],result['schema'],result['server_version']=c.fetchone()
        c.execute('SELECT table_name FROM information_schema.tables WHERE table_schema=current_schema()')
        found={r[0] for r in c.fetchall()}
        result['missing_tables']=sorted(TABLES-found)
        c.execute('SELECT column_name, data_type FROM information_schema.columns WHERE table_schema=current_schema() AND table_name=%s',('document_blobs',))
        columns=dict(c.fetchall())
        result['document_blob_column']=columns.get('content')=='bytea'
        c.execute('SELECT table_name FROM information_schema.columns WHERE table_schema=current_schema() AND column_name=%s',('org_id',))
        scoped={r[0] for r in c.fetchall()}
        result['tenant_scoped_tables']={'users','processes','documents','runs','decisions','checklist','retroactive_runs','closing_runs','analysis_snapshots','audit_events','independent_costing_runs'}.issubset(scoped)
    result['ready']=not result['missing_tables'] and result['document_blob_column'] and result['tenant_scoped_tables']
    return result

def main():
    url=os.environ.get('NN_DATABASE_URL','').strip()
    if not url:
        print(json.dumps({'ready':False,'reason':'NN_DATABASE_URL ausente'},ensure_ascii=False));return 2
    try:
        import psycopg
        with psycopg.connect(url,connect_timeout=8,options='-c default_transaction_read_only=on') as conn:
            result=inspect_connection(conn)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0 if result['ready'] else 3
    except Exception as exc:
        # Nunca emitir URL ou senha em mensagens de erro.
        print(json.dumps({'ready':False,'reason':type(exc).__name__},ensure_ascii=False))
        return 4
if __name__=='__main__':sys.exit(main())

"""Leitor XLSX isolado (somente leitura) para dados e valores em cache.
Não calcula fórmulas; rejeita fórmula sem valor em cache para não inferir números.
"""
from pathlib import Path
import posixpath
import re
import zipfile
from xml.etree import ElementTree as ET

_NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
_REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
_PKGREL = '{http://schemas.openxmlformats.org/package/2006/relationships}'


def read_first_sheet(path: str | Path, *, max_row: int = 125, max_col: int = 5):
    try:
        with zipfile.ZipFile(path) as arc:
            names = set(arc.namelist())
            for required in ('xl/workbook.xml', 'xl/_rels/workbook.xml.rels'):
                if required not in names:
                    raise ValueError('XLSX sem metadados obrigatórios')
            wb = ET.fromstring(arc.read('xl/workbook.xml'))
            sheets = wb.find(_NS + 'sheets')
            if sheets is None or len(sheets) != 1:
                raise ValueError('Modelo exige exatamente uma aba')
            item = list(sheets)[0]
            sheet_name = item.attrib.get('name', '')
            rel_id = item.attrib.get(_REL + 'id', '')
            relations = ET.fromstring(arc.read('xl/_rels/workbook.xml.rels'))
            target = None
            for relation in relations:
                if relation.attrib.get('Id') == rel_id:
                    target = relation.attrib.get('Target')
                    break
            if not target:
                raise ValueError('Relação da aba não encontrada')
            sheet_path = posixpath.normpath(target.lstrip('/') if target.startswith('/') else posixpath.join('xl', target))
            if not sheet_path.startswith('xl/') or sheet_path not in names:
                raise ValueError('Arquivo interno de planilha inválido')

            strings = []
            if 'xl/sharedStrings.xml' in names:
                tree = ET.fromstring(arc.read('xl/sharedStrings.xml'))
                for si in tree.findall(_NS + 'si'):
                    strings.append(''.join(node.text or '' for node in si.iter(_NS + 't')))

            content = ET.fromstring(arc.read(sheet_path))
            rows = [[None] * max_col for _ in range(max_row)]
            sheet_data = content.find(_NS + 'sheetData')
            if sheet_data is None:
                raise ValueError('Aba sem dados')
            for row in sheet_data.findall(_NS + 'row'):
                for cell in row.findall(_NS + 'c'):
                    address = cell.attrib.get('r', '')
                    match = re.fullmatch(r'([A-Z]+)([1-9][0-9]*)', address)
                    if not match:
                        continue
                    letters, digits = match.groups()
                    col = 0
                    for letter in letters:
                        col = col * 26 + ord(letter) - 64
                    row_num = int(digits)
                    if not (1 <= row_num <= max_row and 1 <= col <= max_col):
                        continue
                    type_name = cell.attrib.get('t')
                    value_tag = cell.find(_NS + 'v')
                    formula_tag = cell.find(_NS + 'f')
                    inline = cell.find(_NS + 'is')
                    raw = value_tag.text if value_tag is not None else None
                    if type_name == 'inlineStr':
                        value = ''.join(n.text or '' for n in inline.iter(_NS + 't')) if inline is not None else ''
                    elif type_name == 's':
                        if raw is None:
                            raise ValueError('Índice de texto compartilhado ausente')
                        idx = int(raw)
                        if not 0 <= idx < len(strings):
                            raise ValueError('Índice de texto compartilhado inválido')
                        value = strings[idx]
                    elif type_name == 'b':
                        value = raw == '1'
                    elif type_name in ('str', 'e'):
                        value = raw
                        if type_name == 'e':
                            raise ValueError(f'Erro em célula Excel: {address}')
                    elif raw is not None and raw != '':
                        numeric = float(raw)
                        value = int(numeric) if numeric.is_integer() else numeric
                    elif formula_tag is not None:
                        raise ValueError(f'Fórmula sem resultado armazenado: {address}; recalcule no Excel antes do envio')
                    else:
                        value = None
                    rows[row_num - 1][col - 1] = value
            return sheet_name, rows
    except zipfile.BadZipFile as exc:
        raise ValueError('Arquivo XLSX inválido') from exc

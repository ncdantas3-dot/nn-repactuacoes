N & N Repactuações v1.0 — correção do deploy Render
- Removida a dependência não distribuída artifact-tool (PyPI).
- Leitor XLSX substituído por leitura OOXML de valores armazenados (somente leitura).
- Fórmulas não são recalculadas neste leitor. Valores em cache ausentes são rejeitados.
- A importação deve ser homologada com amostras reais antes de uso contratual.
- Instância pública não homologada: usar somente documentos fictícios.
Build Command: python -c "import glob,zipfile; zipfile.ZipFile('NN_Repactuacoes_v1.0_Render_Corrigido.zip').extractall('.')" && pip install -r NN_Repactuacoes_v1.0/requirements.txt
Start Command: cd NN_Repactuacoes_v1.0 && python -m uvicorn app:app --host 0.0.0.0 --port $PORT

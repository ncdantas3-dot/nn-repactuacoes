from __future__ import annotations
import os,sqlite3,secrets,hashlib,json,html,time,zipfile,io
from pathlib import Path
from datetime import datetime,timezone
from contextlib import contextmanager
from fastapi import FastAPI,HTTPException,UploadFile,File,Form,Header
from fastapi.responses import FileResponse,HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel,Field
from xlsx_reader import read_first_sheet
from engine import audit, as_decimal, money
from incidence import MATRIX, MATRIX_VERSION, analyze_matrix
from closing import diagnostics, closing_m6
from reconciliation import reconcile
from automatic import automatic_closure, conditional_m6_from_run
from independent_costing import reconstruct, draft_rules, CostingValidationError, VERSION as COSTING_VERSION
from workbook_forensics import inspect_workbook

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('NN_DATA_DIR',str(ROOT/'data'))).resolve()
DATA.mkdir(parents=True,exist_ok=True)
(DATA/'uploads').mkdir(exist_ok=True)
DB=DATA/'nn.sqlite3'
app=FastAPI(title='N & N Repactuacoes — MVP auditavel',version='0.9.0')
app.mount('/static',StaticFiles(directory=str(ROOT/'static')),name='static')

def now():return datetime.now(timezone.utc).isoformat()
@contextmanager
def db():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON')
 try:yield c;c.commit()
 finally:c.close()
with db() as c:
 c.executescript('''CREATE TABLE IF NOT EXISTS orgs(id INTEGER PRIMARY KEY,name TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,username TEXT UNIQUE NOT NULL,pw_hash TEXT NOT NULL,role TEXT NOT NULL,FOREIGN KEY(org_id) REFERENCES orgs(id));
 CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL,created TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id));
 CREATE TABLE IF NOT EXISTS processes(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,company TEXT NOT NULL,cnpj TEXT,contract TEXT NOT NULL,sei TEXT,subject TEXT,regime TEXT,request_date TEXT,status TEXT NOT NULL DEFAULT 'EM_ANALISE',created TEXT NOT NULL,FOREIGN KEY(org_id) REFERENCES orgs(id));
 CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,process_id INTEGER NOT NULL,kind TEXT NOT NULL,filename TEXT NOT NULL,sha256 TEXT NOT NULL,path TEXT NOT NULL,extracted TEXT,created TEXT NOT NULL,FOREIGN KEY(process_id) REFERENCES processes(id));
 CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,process_id INTEGER NOT NULL,results TEXT NOT NULL,cct_piso TEXT,created TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS decisions(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,run_id INTEGER NOT NULL,row_number INTEGER NOT NULL,decision TEXT NOT NULL,justification TEXT NOT NULL,evidence TEXT NOT NULL,actor_id INTEGER NOT NULL,created TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS checklist(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,process_id INTEGER NOT NULL,item TEXT NOT NULL,state TEXT NOT NULL,justification TEXT NOT NULL,actor_id INTEGER NOT NULL,created TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS retroactive_runs(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,process_id INTEGER NOT NULL,actor_id INTEGER NOT NULL,input_json TEXT NOT NULL,result_json TEXT NOT NULL,created TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS closing_runs(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,process_id INTEGER NOT NULL,actor_id INTEGER NOT NULL,source_run_id INTEGER NOT NULL,input_json TEXT NOT NULL,result_json TEXT NOT NULL,created TEXT NOT NULL);
 ''')
 c.executescript('''
 CREATE TABLE IF NOT EXISTS analysis_snapshots(
   id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,process_id INTEGER NOT NULL,
   run_id INTEGER NOT NULL UNIQUE,manifest_json TEXT NOT NULL,manifest_sha256 TEXT NOT NULL,
   status TEXT NOT NULL DEFAULT 'RASCUNHO',author_id INTEGER NOT NULL,
   reviewer_id INTEGER,reviewed TEXT,review_note TEXT,created TEXT NOT NULL,
   FOREIGN KEY(run_id) REFERENCES runs(id));
 CREATE INDEX IF NOT EXISTS idx_analysis_snapshot_org ON analysis_snapshots(org_id,process_id);
 CREATE TABLE IF NOT EXISTS audit_events(id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,
   process_id INTEGER NOT NULL,run_id INTEGER,event TEXT NOT NULL,actor_id INTEGER NOT NULL,
   payload_json TEXT NOT NULL,created TEXT NOT NULL);
 ''')
with db() as c:
 c.execute('''CREATE TABLE IF NOT EXISTS independent_costing_runs (
  id INTEGER PRIMARY KEY,org_id INTEGER NOT NULL,process_id INTEGER NOT NULL,
  run_id INTEGER NOT NULL,source_manifest_sha TEXT NOT NULL,
  rules_json TEXT NOT NULL,result_json TEXT NOT NULL,engine_version TEXT NOT NULL,
  actor_id INTEGER NOT NULL,created TEXT NOT NULL,
  FOREIGN KEY(run_id) REFERENCES runs(id))''')
 c.execute('CREATE INDEX IF NOT EXISTS idx_indep_org_run ON independent_costing_runs(org_id,process_id,run_id)')
# Migração aditiva: referências de auditoria no histórico de retroativos.
with db() as c:
 cols={r['name'] for r in c.execute('PRAGMA table_info(retroactive_runs)')}
 if 'source_run_id' not in cols:c.execute('ALTER TABLE retroactive_runs ADD COLUMN source_run_id INTEGER')
 cols={r['name'] for r in c.execute('PRAGMA table_info(checklist)')}
 if 'source_run_id' not in cols:c.execute('ALTER TABLE checklist ADD COLUMN source_run_id INTEGER')
# Defesas locais: expiracao de sessao, limitacao de falhas e CSP.
SESSION_TTL_SECONDS = 8*60*60
LOGIN_ATTEMPTS = {}
@app.middleware('http')
async def secure_headers(request, call_next):
 response = await call_next(request)
 for key,value in {
   'X-Content-Type-Options':'nosniff', 'X-Frame-Options':'DENY',
   'Referrer-Policy':'no-referrer', 'Cache-Control':'no-store',
   'Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; form-action 'self'; frame-ancestors 'none'"
 }.items():response.headers[key]=value
 return response

def require_role(u, roles=('ADMIN','ANALISTA')):
 if u['role'] not in roles:raise HTTPException(403,'Perfil sem permissao para esta operacao')

def pw_hash(password,salt=None):
 salt=salt or secrets.token_hex(16)
 return salt+':'+hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=2**14,r=8,p=1).hex()
def auth(header):
 if not header or not header.startswith('Bearer '):raise HTTPException(401,'Autenticacao exigida')
 h=hashlib.sha256(header[7:].encode()).hexdigest()
 with db() as c:
  row=c.execute('SELECT u.id,u.org_id,u.role,u.username,s.created FROM sessions s JOIN users u ON u.id=s.user_id WHERE token_hash=?',(h,)).fetchone()
  if row:
   try: age=(datetime.now(timezone.utc)-datetime.fromisoformat(row['created'])).total_seconds()
   except (ValueError, TypeError): age=SESSION_TTL_SECONDS+1
   if age>SESSION_TTL_SECONDS:
    c.execute('DELETE FROM sessions WHERE token_hash=?',(h,));row=None
 if not row:raise HTTPException(401,'Sessao invalida ou expirada')
 return {k:row[k] for k in ('id','org_id','role','username')}
def process(c,id,org):
 p=c.execute('SELECT * FROM processes WHERE id=? AND org_id=?',(id,org)).fetchone()
 if not p: raise HTTPException(404,'Processo nao localizado')
 return dict(p)
class Register(BaseModel):
 org:str=Field(min_length=2);username:str=Field(min_length=3);password:str=Field(min_length=12)
class Login(BaseModel):username:str;password:str
class UserIn(BaseModel):username:str=Field(min_length=3,max_length=60);password:str=Field(min_length=12,max_length=150);role:str
class ProcessIn(BaseModel):company:str=Field(min_length=2);contract:str=Field(min_length=1);cnpj:str='';sei:str='';subject:str='';regime:str='Lei 14.133/2021';request_date:str=''
class RuleDeclaration(BaseModel):
 row:int=Field(ge=1,le=125)
 base_value:str=Field(min_length=1,max_length=40)
 base_description:str=Field(min_length=5,max_length=300)
 evidence:str=Field(min_length=6,max_length=300)
class AuditIn(BaseModel):
 cct_piso:str|None=None
 rules:list[RuleDeclaration]=Field(default_factory=list,max_length=30)
def canonical_hash(value):
 return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def snapshot_valid(c,run,org,pid):
 """Rejeita uso corrente quando qualquer arquivo de origem foi substituido (inclusive mesmo nome)."""
 sources=json.loads(run['results']).get('fontes',{})
 for kind in ('vigente','pedido','cct'):
  latest=c.execute('SELECT id,sha256 FROM documents WHERE org_id=? AND process_id=? AND kind=? ORDER BY id DESC LIMIT 1',(org,pid,kind)).fetchone()
  origin=sources.get(kind)
  if not latest or not origin or int(origin.get('document_id') or 0)!=latest['id'] or origin.get('sha256')!=latest['sha256']:
   return False
 return True

def event(c,org,pid,run_id,actor,code,data):
 c.execute('INSERT INTO audit_events(org_id,process_id,run_id,event,actor_id,payload_json,created) VALUES(?,?,?,?,?,?,?)',
 (org,pid,run_id,code,actor,json.dumps(data,ensure_ascii=False,sort_keys=True),now()))

def snapshot_for(c,run_id,org,pid):
 return c.execute('SELECT * FROM analysis_snapshots WHERE run_id=? AND org_id=? AND process_id=?',(run_id,org,pid)).fetchone()

class ReviewIn(BaseModel):
 run_id:int
 action:str
 note:str=Field(min_length=12,max_length=2000)

class DecisionIn(BaseModel):run_id:int;row_number:int;decision:str;justification:str=Field(min_length=10);evidence:str=Field(min_length=2)
class ChecklistIn(BaseModel):item:str;state:str;justification:str=Field(min_length=3);run_id:int|None=None
@app.get('/',response_class=HTMLResponse)
def home():return (ROOT/'static/index.html').read_text('utf-8')
@app.get('/api/incidence-matrix')
def incidence_matrix(authorization:str|None=Header(None)):
 auth(authorization)
 return {'version':MATRIX_VERSION,'rules':MATRIX,'notice':'Base contratual e aplicação jurídica devem ser validadas antes de deferimento.'}
@app.get('/api/setup-status')
def setup_status():
 with db() as c:return {'setup_required':c.execute('SELECT COUNT(*) FROM users').fetchone()[0]==0}
@app.post('/api/setup')
def setup(a:Register):
 with db() as c:
  if c.execute('SELECT COUNT(*) FROM users').fetchone()[0]:raise HTTPException(403,'Instalacao ja configurada')
  cur=c.execute('INSERT INTO orgs(name) VALUES(?)',(a.org,));c.execute('INSERT INTO users(org_id,username,pw_hash,role) VALUES(?,?,?,?)',(cur.lastrowid,a.username,pw_hash(a.password),'ADMIN'))
 return {'ok':True}
@app.post('/api/login')
def login(a:Login):
 key=a.username.casefold()
 stamp=time.monotonic()
 attempts=[t for t in LOGIN_ATTEMPTS.get(key,[]) if stamp-t<300]
 if len(attempts)>=8:raise HTTPException(429,'Tentativas excedidas; tente novamente mais tarde')
 with db() as c:
  row=c.execute('SELECT * FROM users WHERE username=?',(a.username,)).fetchone()
  if not row or not secrets.compare_digest(pw_hash(a.password,row['pw_hash'].split(':')[0]),row['pw_hash']):
   LOGIN_ATTEMPTS[key]=attempts+[stamp]
   raise HTTPException(401,'Credenciais invalidas')
  LOGIN_ATTEMPTS.pop(key,None)
  token=secrets.token_urlsafe(32);c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),row['id'],now()))
 return {'token':token,'username':row['username'],'role':row['role']}
@app.get('/api/me')
def me(authorization:str|None=Header(None)):return auth(authorization)
@app.post('/api/logout')
def logout(authorization:str|None=Header(None)):
 auth(authorization)
 with db() as c:c.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(authorization[7:].encode()).hexdigest(),))
 return {'ok':True}
@app.get('/api/users')
def list_users(authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u,('ADMIN',))
 with db() as c:return [dict(r) for r in c.execute('SELECT id,username,role FROM users WHERE org_id=? ORDER BY id',(u['org_id'],))]
@app.post('/api/users')
def new_user(item:UserIn,authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u,('ADMIN',))
 if item.role not in ('ADMIN','ANALISTA','REVISOR','CONSULTA'):raise HTTPException(422,'Perfil invalido')
 with db() as c:
  try: cur=c.execute('INSERT INTO users(org_id,username,pw_hash,role) VALUES(?,?,?,?)',(u['org_id'],item.username,pw_hash(item.password),item.role))
  except sqlite3.IntegrityError:raise HTTPException(409,'Nome de usuario indisponivel')
 return {'id':cur.lastrowid,'role':item.role}
@app.get('/api/processes/{pid}/reconciliation')
def reconciliation(pid:int,authorization:str|None=Header(None)):
 u=auth(authorization)
 with db() as c:
  process(c,pid,u['org_id'])
  docs=c.execute('SELECT kind,sha256,id,extracted FROM documents WHERE process_id=? AND org_id=? AND kind IN ("vigente","pedido") ORDER BY id DESC',(pid,u['org_id'])).fetchall()
 out={}
 for d in docs:
  if d['kind'] in out:continue
  if d['extracted']:out[d['kind']]={'document_id':d['id'],'sha256':d['sha256'],**reconcile(json.loads(d['extracted']))}
 return {'planilhas':out,'conclusivo':False,'aviso':'Reconciliação interna; não substitui validação da fórmula nem a planilha contratual aprovada.'}
@app.get('/api/processes')
def processes(authorization:str|None=Header(None)):
 u=auth(authorization)
 with db() as c:return [dict(r) for r in c.execute('SELECT * FROM processes WHERE org_id=? ORDER BY id DESC',(u['org_id'],))]
@app.post('/api/processes')
def create_process(item:ProcessIn,authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u)
 with db() as c:
  cur=c.execute('INSERT INTO processes(org_id,company,cnpj,contract,sei,subject,regime,request_date,created) VALUES(?,?,?,?,?,?,?,?,?)',(u['org_id'],item.company,item.cnpj,item.contract,item.sei,item.subject,item.regime,item.request_date,now()))
 return {'id':cur.lastrowid}
@app.get('/api/template')
def template(authorization:str|None=Header(None)):
 auth(authorization);return FileResponse(ROOT/'assets/modelo_vigilante_diurno_armado.xlsx',filename='NN_Modelo_Vigilante_Diurno_Armado.xlsx')
def extract(path):
 sheet_name, rows = read_first_sheet(path)
 if sheet_name.strip().lower()!='vigilante diurno (arm.)':raise ValueError('Aba esperada: Vigilante diurno (ARM.)')
 checks={16:'Salário',21:'Adicional de Periculosidade',25:'13 º Salário',26:'Férias',35:'Fgts',41:'Auxílio alimentação',83:'Uniformes',93:'Custos Indiretos',94:'Lucro'}
 for i,expected in checks.items():
  label=str(rows[i-1][1] or '')
  if expected.casefold() not in label.casefold():raise ValueError(f'Rubrica alterada na linha {i}: {expected}')
 def jsonable(v):
  if isinstance(v,(str,int,float,bool)) or v is None:return v
  return str(v)
 return {'sheet':sheet_name,'rows':{str(i):{c:jsonable(row[j]) for j,c in enumerate('ABCDE')} for i,row in enumerate(rows,1)},'row_count':len(rows)}
@app.post('/api/processes/{pid}/documents')
async def upload(pid:int,kind:str=Form(...),file:UploadFile=File(...),authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u)
 if kind not in ('vigente','pedido','cct','contrato','outro','planilha_evidencia'):raise HTTPException(400,'Tipo de documento invalido')
 with db() as c:process(c,pid,u['org_id'])
 raw=await file.read(6*1024*1024+1)
 if len(raw)>6*1024*1024:raise HTTPException(413,'Limite 6 MB')
 if not raw:raise HTTPException(400,'Arquivo vazio')
 from zipfile import is_zipfile
 if kind in ('vigente','pedido','planilha_evidencia') and (not file.filename.lower().endswith('.xlsx') or not raw[:2]==b'PK'):
  raise HTTPException(400,'Planilha .xlsx valida necessaria')
 if kind in ('cct','contrato','outro') and not (raw.startswith(b'%PDF') or raw[:2]==b'PK'):raise HTTPException(400,'PDF ou documento Office necessario')
 if raw[:2]==b'PK':
  try:
   with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    members=archive.infolist()
    if len(members)>350 or sum(m.file_size for m in members)>30*1024*1024 or any(m.file_size>8*1024*1024 for m in members):
     raise HTTPException(413,'Planilha com conteudo descompactado acima do limite')
    if any(m.filename.startswith('/') or '..' in m.filename.replace('\\','/').split('/') for m in members):
     raise HTTPException(422,'Arquivo Office com caminhos invalidos')
  except zipfile.BadZipFile:raise HTTPException(422,'Arquivo Office invalido')
 digest=hashlib.sha256(raw).hexdigest();p=DATA/'uploads'/f'{u["org_id"]}_{pid}_{secrets.token_hex(8)}'
 p.write_bytes(raw)
 try: extracted=extract(p) if kind in ('vigente','pedido') else None
 except Exception as e:
  p.unlink(missing_ok=True);raise HTTPException(422,f'Planilha incompatível: {str(e)[:180]}')
 with db() as c:
  cur=c.execute('INSERT INTO documents(org_id,process_id,kind,filename,sha256,path,extracted,created) VALUES(?,?,?,?,?,?,?,?)',(u['org_id'],pid,kind,Path(file.filename).name,digest,str(p),json.dumps(extracted,ensure_ascii=False) if extracted else None,now()))
 return {'id':cur.lastrowid,'sha256':digest,'extracted':{'sheet':extracted['sheet'],'row_count':extracted['row_count']} if extracted else None}

@app.get('/api/processes/{pid}/documents/{doc_id}/formula-audit')
def formula_audit(pid:int,doc_id:int,authorization:str|None=Header(None)):
    """Diagnóstico somente leitura de XLSX; não modifica auditoria histórica."""
    u=auth(authorization)
    with db() as c:
        process(c,pid,u['org_id'])
        d=c.execute('SELECT kind,filename,path,sha256 FROM documents WHERE id=? AND org_id=? AND process_id=?',
                    (doc_id,u['org_id'],pid)).fetchone()
    if not d:raise HTTPException(404,'Documento não encontrado')
    if d['kind'] not in ('planilha_evidencia','vigente','pedido') or not d['filename'].lower().endswith('.xlsx'):
        raise HTTPException(422,'Selecione uma planilha XLSX')
    try:
        report=inspect_workbook(d['path'])
    except (ValueError,KeyError,zipfile.BadZipFile) as exc:
        raise HTTPException(422,'Planilha não verificável: '+str(exc)[:140])
    if report['sha256']!=d['sha256']:raise HTTPException(409,'Integridade do documento original comprometida')
    return report

@app.get('/api/processes/{pid}/documents')
def documents(pid:int,authorization:str|None=Header(None)):
 u=auth(authorization)
 with db() as c:
  process(c,pid,u['org_id']);return [{k:v for k,v in dict(r).items() if k not in ('path','extracted')} for r in c.execute('SELECT * FROM documents WHERE org_id=? AND process_id=? ORDER BY id DESC',(u['org_id'],pid))]
@app.post('/api/processes/{pid}/audit')
def run_audit(pid:int,item:AuditIn,authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u)
 with db() as c:
  process(c,pid,u['org_id'])
  docs=c.execute('SELECT kind,extracted,id,sha256 FROM documents WHERE org_id=? AND process_id=? AND kind IN ("vigente","pedido") ORDER BY id DESC',(u['org_id'],pid)).fetchall()
  latest={}
  for d in docs:
   if d['kind'] not in latest:latest[d['kind']]={'document':json.loads(d['extracted']),'id':d['id'],'sha256':d['sha256']}
  if set(latest)!={'vigente','pedido'}:raise HTTPException(409,'Importe a planilha vigente e a solicitada')
  cct_doc=c.execute('SELECT id,sha256 FROM documents WHERE org_id=? AND process_id=? AND kind="cct" ORDER BY id DESC LIMIT 1',(u['org_id'],pid)).fetchone()
  if not cct_doc:raise HTTPException(409,'Anexe a CCT para instruir a auditoria')
  try:
   result=audit(latest['vigente']['document'],latest['pedido']['document'],item.cct_piso,[r.model_dump() for r in item.rules])
   result=analyze_matrix(latest['vigente']['document'],latest['pedido']['document'],result)
   result['fontes']={k:{'document_id':v['id'],'sha256':v['sha256']} for k,v in latest.items()}
   result['fontes']['cct']={'document_id':cct_doc['id'],'sha256':cct_doc['sha256']}
   result['reconciliacao']={k:reconcile(v['document']) for k,v in latest.items()}
   result['fechamento_diagnostico']=diagnostics(result)
   result['fechamento_automatico']=automatic_closure(result)
  except ValueError as e:raise HTTPException(422,str(e))
  cur=c.execute('INSERT INTO runs(org_id,process_id,results,cct_piso,created) VALUES(?,?,?,?,?)',(u['org_id'],pid,json.dumps(result,ensure_ascii=False),item.cct_piso,now()))
  rid=cur.lastrowid
  manifest={'run_id':rid,'process_id':pid,'fontes':result['fontes'],'motor':'engine-v0.7-partial','matriz':MATRIX_VERSION,'status_financeiro':'PENDENTE'}
  digest=canonical_hash(manifest)
  c.execute('INSERT INTO analysis_snapshots(org_id,process_id,run_id,manifest_json,manifest_sha256,author_id,created) VALUES(?,?,?,?,?,?,?)',
   (u['org_id'],pid,rid,json.dumps(manifest,ensure_ascii=False,sort_keys=True),digest,u['id'],now()))
  event(c,u['org_id'],pid,rid,u['id'],'AUDITORIA_CRIADA',{'manifest_sha256':digest})
 return {'id':rid,'manifest_sha256':digest,**result}

class IndependentCostingIn(BaseModel):
 run_id:int
 rules:list[dict]=Field(min_length=1,max_length=140)

@app.get('/api/independent-costing/template')
def independent_costing_template(authorization:str|None=Header(None)):
 auth(authorization)
 return {'rules':draft_rules(),'notice':'Matriz vazia: preencha documentos, fórmulas e bases; sem validação automática de elegibilidade.'}

@app.post('/api/processes/{pid}/independent-costing')
def calculate_independent_costing(pid:int,item:IndependentCostingIn,authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u)
 with db() as c:
  process(c,pid,u['org_id'])
  run=c.execute('SELECT * FROM runs WHERE id=? AND org_id=? AND process_id=?',(item.run_id,u['org_id'],pid)).fetchone()
  if not run:raise HTTPException(404,'Auditoria não encontrada')
  if not snapshot_valid(c,run,u['org_id'],pid):raise HTTPException(409,'Documentos foram substituídos; execute nova auditoria')
  snapshot=snapshot_for(c,run['id'],u['org_id'],pid)
  if not snapshot:raise HTTPException(409,'Manifesto da análise ausente')
  if snapshot['status'] in ('EM_REVISAO','APROVADO','ENCERRADO'):
   raise HTTPException(409,'Auditoria bloqueada para alterações')
  sources=json.loads(run['results'])['fontes']
  docs={}
  for kind in ('vigente','pedido'):
   origin=sources[kind]
   d=c.execute('SELECT extracted FROM documents WHERE id=? AND org_id=? AND process_id=?',
               (origin['document_id'],u['org_id'],pid)).fetchone()
   if not d or not d['extracted']:raise HTTPException(409,'Fonte indisponível')
   docs[kind]=json.loads(d['extracted'])
  try:r=reconstruct(docs['vigente'],docs['pedido'],item.rules)
  except (CostingValidationError,ValueError) as e:raise HTTPException(422,str(e))
  r['run_id']=run['id'];r['manifest_sha256']=snapshot['manifest_sha256']
  r['rules_sha256']=canonical_hash(item.rules)
  cur=c.execute('INSERT INTO independent_costing_runs(org_id,process_id,run_id,source_manifest_sha,rules_json,result_json,engine_version,actor_id,created) VALUES(?,?,?,?,?,?,?,?,?)',
        (u['org_id'],pid,run['id'],snapshot['manifest_sha256'],json.dumps(item.rules,ensure_ascii=False),json.dumps(r,ensure_ascii=False),COSTING_VERSION,u['id'],now()))
  event(c,u['org_id'],pid,run['id'],u['id'],'RECALCULO_INDEPENDENTE',
       {'costing_id':cur.lastrowid,'rules_sha256':r['rules_sha256'],'status':r['status']})
  return {'costing_id':cur.lastrowid,**r}

@app.get('/api/processes/{pid}/independent-costing')
def get_independent_costing(pid:int,authorization:str|None=Header(None)):
 u=auth(authorization)
 with db() as c:
  process(c,pid,u['org_id'])
  row=c.execute('SELECT id,run_id,source_manifest_sha,result_json FROM independent_costing_runs WHERE org_id=? AND process_id=? ORDER BY id DESC LIMIT 1',(u['org_id'],pid)).fetchone()
  if not row:return {'status':'NAO_EXECUTADO'}
  run=c.execute('SELECT * FROM runs WHERE id=? AND org_id=? AND process_id=?',(row['run_id'],u['org_id'],pid)).fetchone()
  stale=not run or not snapshot_valid(c,run,u['org_id'],pid)
  result=json.loads(row['result_json'])
  if stale:return {'status':'DESATUALIZADO','costing_id':row['id'],'run_id':row['run_id'],'notice':'Fontes alteradas; gere nova auditoria e novo recálculo'}
  return {'costing_id':row['id'],**result}

@app.get('/api/processes/{pid}/automatic-closing')
def get_automatic_closing(pid:int,authorization:str|None=Header(None)):
 u=auth(authorization)
 with db() as c:
  process(c,pid,u['org_id'])
  record=c.execute('SELECT id,results,created FROM runs WHERE org_id=? AND process_id=? ORDER BY id DESC LIMIT 1',(u['org_id'],pid)).fetchone()
  if not record:raise HTTPException(409,'Execute uma auditoria antes do fechamento automático')
  run=json.loads(record['results'])
  for kind in ('vigente','pedido','cct'):
   d=c.execute('SELECT sha256 FROM documents WHERE org_id=? AND process_id=? AND kind=? ORDER BY id DESC LIMIT 1',(u['org_id'],pid,kind)).fetchone()
   if not d or run.get('fontes',{}).get(kind,{}).get('sha256')!=d['sha256']:
    raise HTTPException(409,'Documentos alterados após a auditoria; execute nova análise')
  result=automatic_closure(run)
  return {'auditoria_id':record['id'],'criado_em':record['created'],**result}
class AutoM6In(BaseModel):
 run_id:int
 profit_method:str
@app.post('/api/processes/{pid}/automatic-m6')
def calculate_automatic_m6(pid:int,item:AutoM6In,authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u)
 with db() as c:
  process(c,pid,u['org_id'])
  record=c.execute('SELECT id,results FROM runs WHERE id=? AND process_id=? AND org_id=?',(item.run_id,pid,u['org_id'])).fetchone()
  if not record:raise HTTPException(404,'Auditoria não encontrada')
  run=json.loads(record['results'])
  source=None
  for kind in ('vigente','pedido','cct'):
   d=c.execute('SELECT sha256,extracted FROM documents WHERE org_id=? AND process_id=? AND kind=? ORDER BY id DESC LIMIT 1',(u['org_id'],pid,kind)).fetchone()
   if not d or run.get('fontes',{}).get(kind,{}).get('sha256')!=d['sha256']:
    raise HTTPException(409,'Documentos substituídos; execute nova auditoria')
   if kind=='vigente':source=json.loads(d['extracted'])
  try:result=conditional_m6_from_run(source,run,item.profit_method)
  except ValueError as ex:raise HTTPException(422,str(ex))
  return {'auditoria_id':record['id'],**result}
@app.get('/api/processes/{pid}/audits')
def audits(pid:int,authorization:str|None=Header(None)):
 u=auth(authorization)
 with db() as c:
  process(c,pid,u['org_id']);return [{'id':r['id'],'created':r['created'],'cct_piso':r['cct_piso'],'results':json.loads(r['results'])} for r in c.execute('SELECT * FROM runs WHERE process_id=? AND org_id=? ORDER BY id DESC',(pid,u['org_id']))]
@app.get('/api/processes/{pid}/versions')
def list_versions(pid:int,authorization:str|None=Header(None)):
 u=auth(authorization)
 with db() as c:
  process(c,pid,u['org_id'])
  result=[]
  for s in c.execute('SELECT * FROM analysis_snapshots WHERE org_id=? AND process_id=? ORDER BY id DESC',(u['org_id'],pid)):
   run=c.execute('SELECT * FROM runs WHERE id=?',(s['run_id'],)).fetchone()
   result.append({'id':s['id'],'run_id':s['run_id'],'status':s['status'],'manifest_sha256':s['manifest_sha256'],
    'manifest':json.loads(s['manifest_json']),'current_documents':snapshot_valid(c,run,u['org_id'],pid),
    'author_id':s['author_id'],'reviewer_id':s['reviewer_id'],'created':s['created'],'reviewed':s['reviewed']})
  return result

@app.post('/api/processes/{pid}/review')
def review(pid:int,item:ReviewIn,authorization:str|None=Header(None)):
 u=auth(authorization)
 if item.action=='ENVIAR_REVISAO':require_role(u,('ADMIN','ANALISTA'))
 elif item.action in ('DEVOLVER','APROVAR'):require_role(u,('ADMIN','REVISOR'))
 else:raise HTTPException(422,'Ação inválida')
 with db() as c:
  process(c,pid,u['org_id'])
  r=c.execute('SELECT * FROM runs WHERE id=? AND org_id=? AND process_id=?',(item.run_id,u['org_id'],pid)).fetchone()
  snap=snapshot_for(c,item.run_id,u['org_id'],pid) if r else None
  if not snap:raise HTTPException(404,'Versão de análise inexistente')
  if not snapshot_valid(c,r,u['org_id'],pid):raise HTTPException(409,'Fontes alteradas; reexecute a auditoria')
  old=snap['status']
  if item.action=='ENVIAR_REVISAO':
   if old not in ('RASCUNHO','DEVOLVIDO'):raise HTTPException(409,'Estado incompatível')
   new='EM_REVISAO'
  elif item.action=='DEVOLVER':
   if old!='EM_REVISAO':raise HTTPException(409,'Versão não está em revisão')
   new='DEVOLVIDO'
  else:
   if old!='EM_REVISAO':raise HTTPException(409,'Versão não está em revisão')
   if snap['author_id']==u['id']:raise HTTPException(403,'Autor não pode aprovar sua própria análise')
   # Enquanto o motor for parcial, permitir revisão documental, mas NÃO uma aprovação de deferimento.
   raise HTTPException(409,'Aprovação final bloqueada: motor financeiro incompleto e pendências jurídicas')
  c.execute('UPDATE analysis_snapshots SET status=?,reviewer_id=?,reviewed=?,review_note=? WHERE id=?',
    (new,u['id'] if item.action=='DEVOLVER' else None,now(),item.note,snap['id']))
  event(c,u['org_id'],pid,item.run_id,u['id'],item.action,{'de':old,'para':new,'nota':item.note})
 return {'run_id':item.run_id,'status':new}

@app.post('/api/processes/{pid}/decisions')
def decision(pid:int,item:DecisionIn,authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u)
 if item.decision not in ('MANTER','CONGELAR','EXCLUIR_ACRESCIMO','PENDENTE'):raise HTTPException(400,'Decisao invalida')
 with db() as c:
  process(c,pid,u['org_id']);run=c.execute('SELECT results FROM runs WHERE id=? AND process_id=? AND org_id=?',(item.run_id,pid,u['org_id'])).fetchone()
  if not run:raise HTTPException(404,'Auditoria inexistente')
  origin=c.execute('SELECT * FROM runs WHERE id=? AND process_id=? AND org_id=?',(item.run_id,pid,u['org_id'])).fetchone()
  if not snapshot_valid(c,origin,u['org_id'],pid):raise HTTPException(409,'Auditoria desatualizada; reexecute com os documentos atuais')
  snap=snapshot_for(c,item.run_id,u['org_id'],pid)
  if snap and snap['status'] in ('APROVADO','ENCERRADO','EM_REVISAO'):
   raise HTTPException(409,'Versão bloqueada para edição; crie uma nova auditoria')
  if item.row_number not in [r['row'] for r in json.loads(run['results'])['rubricas']]:raise HTTPException(400,'Rubrica inexistente')
  cur=c.execute('INSERT INTO decisions(org_id,run_id,row_number,decision,justification,evidence,actor_id,created) VALUES(?,?,?,?,?,?,?,?)',(u['org_id'],item.run_id,item.row_number,item.decision,item.justification,item.evidence,u['id'],now()))
  event(c,u['org_id'],pid,item.run_id,u['id'],'DECISAO_REGISTRADA',{'linha':item.row_number,'decisao':item.decision,'evidencia':item.evidence})
 return {'id':cur.lastrowid}
@app.post('/api/processes/{pid}/checklist')
def check(pid:int,item:ChecklistIn,authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u)
 if item.state not in ('CONFORME','PENDENTE','NAO_CONFORME'):raise HTTPException(400,'Situacao invalida')
 with db() as c:
  process(c,pid,u['org_id'])
  latest=c.execute('SELECT * FROM runs WHERE org_id=? AND process_id=? ORDER BY id DESC LIMIT 1',(u['org_id'],pid)).fetchone()
  rid=(item.run_id or latest['id']) if latest else None
  if item.run_id and (not latest or rid!=latest['id']):raise HTTPException(409,'Use a versão atual da auditoria')
  if latest:
   if not snapshot_valid(c,latest,u['org_id'],pid):raise HTTPException(409,'Documentos substituídos; execute nova auditoria')
   snap=snapshot_for(c,latest['id'],u['org_id'],pid)
   if snap and snap['status'] in ('EM_REVISAO','APROVADO','ENCERRADO'):raise HTTPException(409,'Checklist bloqueado nesta etapa de revisão')
  cur=c.execute('INSERT INTO checklist(org_id,process_id,item,state,justification,actor_id,created,source_run_id) VALUES(?,?,?,?,?,?,?,?)',(u['org_id'],pid,item.item,item.state,item.justification,u['id'],now(),rid))
  event(c,u['org_id'],pid,rid,u['id'],'CHECKLIST_ATUALIZADO',{'item':item.item,'estado':item.state})
 return {'id':cur.lastrowid}
def c_latest_source(pid, org):
 with db() as c:
  docs=c.execute('SELECT kind,sha256 FROM documents WHERE process_id=? AND org_id=? AND kind IN ("vigente","pedido") ORDER BY id DESC',(pid,org)).fetchall()
 out={}
 for d in docs:
  if d['kind'] not in out:out[d['kind']]=d['sha256']
 return out
@app.get('/api/processes/{pid}/report',response_class=HTMLResponse)
def report(pid:int,authorization:str|None=Header(None),token:str|None=None):
 # token por query nao e aceito: evita exposicao em logs e historico
 u=auth(authorization)
 with db() as c:
  p=process(c,pid,u['org_id']);run=c.execute('SELECT * FROM runs WHERE org_id=? AND process_id=? ORDER BY id DESC LIMIT 1',(u['org_id'],pid)).fetchone()
  docs=c.execute('SELECT filename,kind,sha256 FROM documents WHERE org_id=? AND process_id=?',(u['org_id'],pid)).fetchall()
  decisions=c.execute('SELECT d.row_number,d.decision,d.justification,d.evidence,d.created FROM decisions d WHERE d.run_id=? AND d.org_id=? ORDER BY d.id DESC',(run['id'] if run else -1,u['org_id'])).fetchall()
  checks=c.execute('SELECT item,state,justification FROM checklist WHERE process_id=? AND org_id=? AND source_run_id=?',(pid,u['org_id'],run['id'] if run else -1)).fetchall()
  retro=c.execute('SELECT result_json,created FROM retroactive_runs WHERE process_id=? AND org_id=? AND source_run_id=? ORDER BY id DESC LIMIT 1',(pid,u['org_id'],run['id'] if run else -1)).fetchone()
  closing=c.execute('SELECT result_json,created FROM closing_runs WHERE process_id=? AND org_id=? AND source_run_id=? ORDER BY id DESC LIMIT 1',(pid,u['org_id'],run['id'] if run else -1)).fetchone()
  costed=c.execute('SELECT result_json,engine_version,created FROM independent_costing_runs WHERE process_id=? AND org_id=? AND run_id=? ORDER BY id DESC LIMIT 1',(pid,u['org_id'],run['id'] if run else -1)).fetchone()
 result=json.loads(run['results']) if run else None
 with db() as meta_db: snap=snapshot_for(meta_db,run['id'],u['org_id'],pid) if run else None
 
 with db() as check_db: stale=bool(run and not snapshot_valid(check_db,run,u['org_id'],pid))
 esc=lambda v:html.escape(str(v if v is not None else '—'))
 retro_data=json.loads(retro['result_json']) if retro else None
 closing_data=json.loads(closing['result_json']) if closing else None
 cost_data=json.loads(costed['result_json']) if costed else None
 cost_html=('<h3>Recálculo financeiro independente (condicionado)</h3><p>'+esc(cost_data['status'])+' | Total: '+esc(cost_data['recalculo_financeiro_condicionado'])+' | Deferimento: PENDENTE.</p><table><tr><th>Rubrica</th><th>Fórmula</th><th>Solicitado</th><th>Apurado</th><th>Diferença</th></tr>'+''.join('<tr><td>'+esc(x['id'])+'</td><td>'+esc(x['formula'])+'</td><td>'+esc(x['requested'])+'</td><td>'+esc(x['amount'])+'</td><td>'+esc(x['difference'])+'</td></tr>' for x in cost_data['rubricas'])+'</table>' if cost_data and not stale else '<h3>Recálculo financeiro independente</h3><p>Não disponível para esta versão documental.</p>')
 recon=result.get('reconciliacao',{}) if result else {}
 recon_summary='; '.join(f'{k}: {v.get("inconsistencias",0)} divergências e {v.get("pendencias",0)} grupos incompletos' for k,v in recon.items())
 closing_html=(f'<h3>Módulo 6 — cenário aritmético condicionado</h3><p>Preço demonstrativo: {esc(closing_data["preco_cenario"])}; não é valor de deferimento.</p><ul>'+''.join(f'<li>{esc(x)}</li>' for x in closing_data['memoria'])+'</ul>' if closing_data else '<h3>Módulo 6</h3><p>Não há cenário condicionado registrado.</p>')
 retro_detail=(''.join(f'<tr><td>{esc(x["competencia"])}</td><td>{esc(x["quantidade"])}</td><td>{esc(x["bruto"])}</td><td>{esc(x["ja_pago"])}</td><td>{esc(x["glosa"])}</td><td>{esc(x["liquido"])}</td></tr>' for x in retro_data['competencias']) if retro_data else '')
 rows=''.join(f'<tr><td>{esc(x["row"])}</td><td>{esc(x["module"])}</td><td>{esc(x["rubrica"])}</td><td>{esc(x["solicitado"])}</td><td>{esc(x["apurado"])}</td><td>{esc(x["status"])}</td></tr>' for x in result['rubricas']) if result else ''
 return f'''<!doctype html><html lang="pt-br"><meta charset="utf-8"><title>N & N — Minuta</title><style>body{{font:14px Arial;color:#122a4a;max-width:1080px;margin:35px auto}}header{{background:#122a4a;color:white;padding:28px}}h1{{font-size:21px}}table{{border-collapse:collapse;width:100%;font-size:11px}}td,th{{border:1px solid #ccd5e0;padding:7px;text-align:left}}th{{background:#eaf1f8}}.mark{{color:#b45309;font-weight:bold}}@media print{{body{{margin:12mm}}}}</style><header><h1>N & N — GOVERNANÇA EM CONTRATOS PÚBLICOS</h1><p>Relatório de análise de repactuação</p></header><p class="mark">MINUTA — SUJEITA À REVISÃO. RESULTADO PARCIAL, NÃO HOMOLOGADO.</p><p class="mark">{'ATENÇÃO: DOCUMENTOS SUBSTITUÍDOS APÓS A AUDITORIA. EXECUTE NOVA ANÁLISE.' if stale else ''}</p><p><strong>Versão da auditoria:</strong> {esc(run['id'] if run else None)} | <strong>Manifesto SHA-256:</strong> {esc(snap['manifest_sha256'] if snap else None)} | <strong>Estado:</strong> {esc(snap['status'] if snap else 'LEGADO')}</p><h2>Processo {esc(p['sei'])}</h2><p>Empresa: {esc(p['company'])} | Contrato: {esc(p['contract'])} | Regime informado: {esc(p['regime'])}</p><h3>Documentos e integridade</h3><ul>{''.join(f'<li>{esc(d['kind'])}: {esc(d['filename'])} — SHA-256 {esc(d['sha256'])}</li>' for d in docs)}</ul><h3>Reconciliação dos quadros-resumo</h3><p>{esc(recon_summary)}</p><h3>Resultados analíticos</h3><p>Valor solicitado: {esc(result['valor_solicitado'] if result else None)} | Apurado integral: PENDENTE | Proposto: PENDENTE</p><table><thead><tr><th>Linha</th><th>Módulo</th><th>Rubrica</th><th>Solicitado</th><th>Recálculo parcial</th><th>Situação</th></tr></thead><tbody>{rows}</tbody></table><h3>Decisões registradas</h3><ul>{''.join(f'<li>Linha {esc(d['row_number'])}: {esc(d['decision'])} — {esc(d['justification'])} (evidência: {esc(d['evidence'])})</li>' for d in decisions)}</ul><h3>Verificação jurídica</h3><ul>{''.join(f'<li>{esc(d['item'])}: {esc(d['state'])} — {esc(d['justification'])}</li>' for d in checks)}</ul><h3>Retroativos — demonstração condicionada</h3><p>Último cálculo provisório registrado: {esc(retro_data['total_provisorio'] if retro_data else None)}. Quantias dependem de validação das medições e do período de efeitos.</p><table><thead><tr><th>Competência</th><th>Quantidade</th><th>Bruto</th><th>Já pago</th><th>Glosa</th><th>Líquido</th></tr></thead><tbody>{retro_detail}</tbody></table>{closing_html}{cost_html}<h3>Conclusão preliminar</h3><p>Não há base suficiente para decisão conclusiva. É indispensável validar a planilha aprovada, a CCT aplicável, a metodologia dos seis módulos e as incidências não mapeadas.</p><footer><hr>Emitido em {esc(now())} — N & N Repactuações | Minuta técnica</footer></html>'''



class ClosingIn(BaseModel):
 run_id:int
 module_totals:dict[str,str]
 evidences:dict[str,str]
 profit_method:str
@app.post('/api/processes/{pid}/closing')
def calculate_closing(pid:int,item:ClosingIn,authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u)
 with db() as c:
  process(c,pid,u['org_id'])
  r=c.execute('SELECT results FROM runs WHERE id=? AND process_id=? AND org_id=?',(item.run_id,pid,u['org_id'])).fetchone()
  if not r:raise HTTPException(404,'Auditoria de origem não localizada')
  source=c.execute('SELECT extracted FROM documents WHERE org_id=? AND process_id=? AND kind="vigente" ORDER BY id DESC LIMIT 1',(u['org_id'],pid)).fetchone()
  if not source or not source['extracted']:raise HTTPException(409,'Planilha vigente necessária')
  run=json.loads(r['results'])
  last_hash=source['extracted'] and c.execute('SELECT sha256 FROM documents WHERE org_id=? AND process_id=? AND kind="vigente" ORDER BY id DESC LIMIT 1',(u['org_id'],pid)).fetchone()['sha256']
  current=c.execute('SELECT * FROM runs WHERE id=? AND org_id=? AND process_id=?',(item.run_id,u['org_id'],pid)).fetchone()
  if not snapshot_valid(c,current,u['org_id'],pid):raise HTTPException(409,'Documentos de origem alterados; execute nova auditoria')
  try:result=closing_m6(json.loads(source['extracted']),item.module_totals,item.evidences,item.profit_method)
  except ValueError as ex:raise HTTPException(422,str(ex))
  result['auditoria_origem']=item.run_id
  result['diagnostico']=diagnostics(run)
  cur=c.execute('INSERT INTO closing_runs(org_id,process_id,actor_id,source_run_id,input_json,result_json,created) VALUES(?,?,?,?,?,?,?)',(u['org_id'],pid,u['id'],item.run_id,item.model_dump_json(),json.dumps(result,ensure_ascii=False),now()))
 return {'id':cur.lastrowid,**result}
@app.get('/api/processes/{pid}/closing')
def list_closings(pid:int,authorization:str|None=Header(None)):
 u=auth(authorization)
 with db() as c:
  process(c,pid,u['org_id'])
  return [{'id':r['id'],'created':r['created'],'source_run_id':r['source_run_id'],'result':json.loads(r['result_json'])} for r in c.execute('SELECT * FROM closing_runs WHERE org_id=? AND process_id=? ORDER BY id DESC',(u['org_id'],pid))]

class Competence(BaseModel):
 month:str=Field(pattern=r'^\d{4}-(0[1-9]|1[0-2])$')
 quantity:str=Field(min_length=1,max_length=35)
 previous_unit:str=Field(min_length=1,max_length=35)
 new_unit:str=Field(min_length=1,max_length=35)
 executed_fraction:str=Field(default='1',max_length=35)
 previous_paid:str=Field(default='0',max_length=35)
 glosa:str=Field(default='0',max_length=35)
 justification:str=Field(min_length=5,max_length=300)
class RetroactiveIn(BaseModel):
 lines:list[Competence]=Field(min_length=1,max_length=120)
@app.post('/api/processes/{pid}/retroactive')
def calculate_retroactive(pid:int,item:RetroactiveIn,authorization:str|None=Header(None)):
 u=auth(authorization);require_role(u)
 with db() as c:process(c,pid,u['org_id'])
 results=[];total=__import__('decimal').Decimal('0');seen=set()
 for line in item.lines:
  if line.month in seen:raise HTTPException(422,'Competência repetida: '+line.month)
  seen.add(line.month)
  data={k:as_decimal(getattr(line,k)) for k in ('quantity','previous_unit','new_unit','executed_fraction','previous_paid','glosa')}
  if any(v is None for v in data.values()):raise HTTPException(422,'Valor inválido em '+line.month)
  q,old,new,frac,paid,glosa=(data[k] for k in ('quantity','previous_unit','new_unit','executed_fraction','previous_paid','glosa'))
  if not (q>=0 and q<=100000 and old>=0 and new>=0 and old<=1_000_000_000 and new<=1_000_000_000 and 0<=frac<=1 and 0<=paid<=1_000_000_000 and 0<=glosa<=1_000_000_000):raise HTTPException(422,'Parâmetros fora dos limites em '+line.month)
  gross=money((new-old)*q*frac)
  net=money(gross-paid-glosa)
  total+=net
  results.append({'competencia':line.month,'quantidade':str(q),'unitario_anterior':str(money(old)),'unitario_novo':str(money(new)),'fracao_executada':str(frac),'bruto':str(gross),'ja_pago':str(money(paid)),'glosa':str(money(glosa)),'liquido':str(net),'justificativa':line.justification})
 out={'competencias':results,'total_provisorio':str(money(total)),'homologado':False,'aviso':'Memória aritmética condicionada à confirmação das medições, da data de efeitos e dos valores contratuais. Não autoriza pagamento.'}
 with db() as c:
  latest=c.execute('SELECT * FROM runs WHERE org_id=? AND process_id=? ORDER BY id DESC LIMIT 1',(u['org_id'],pid)).fetchone()
  source_run_id=latest['id'] if latest and snapshot_valid(c,latest,u['org_id'],pid) else None
  if latest and not source_run_id:raise HTTPException(409,'Documentos alterados: reexecute auditoria antes do retroativo')
  out['auditoria_origem']=source_run_id
  out['vinculo']='AUDITORIA_ATUAL' if source_run_id else 'SEM_AUDITORIA'
  cur=c.execute('INSERT INTO retroactive_runs(org_id,process_id,actor_id,source_run_id,input_json,result_json,created) VALUES(?,?,?,?,?,?,?)',(u['org_id'],pid,u['id'],source_run_id,item.model_dump_json(),json.dumps(out,ensure_ascii=False),now()))
  event(c,u['org_id'],pid,source_run_id,u['id'],'RETROATIVO_CONDICIONADO',{'total':out['total_provisorio'],'source_run_id':source_run_id})
 return {'id':cur.lastrowid,**out}
@app.get('/api/processes/{pid}/retroactive')
def list_retroactives(pid:int,authorization:str|None=Header(None)):
 u=auth(authorization)
 with db() as c:
  process(c,pid,u['org_id'])
  return [{'id':r['id'],'created':r['created'],'results':json.loads(r['result_json'])} for r in c.execute('SELECT * FROM retroactive_runs WHERE org_id=? AND process_id=? ORDER BY id DESC',(u['org_id'],pid))]

@app.get('/api/processes/{pid}/documents/{doc_id}/download')
def download_document(pid:int,doc_id:int,authorization:str|None=Header(None)):
    """Documento original por identidade do locatario; nunca aceita path informado pelo cliente."""
    u=auth(authorization)
    with db() as c:
        process(c,pid,u['org_id'])
        doc=c.execute('SELECT path,filename,sha256 FROM documents WHERE id=? AND process_id=? AND org_id=?',(doc_id,pid,u['org_id'])).fetchone()
    if doc is None:raise HTTPException(404,'Documento indisponivel')
    path=Path(doc['path'])
    if not path.exists() or not path.is_file():raise HTTPException(404,'Arquivo fisico indisponivel')
    if hashlib.sha256(path.read_bytes()).hexdigest()!=doc['sha256']:
        raise HTTPException(409,'Integridade do documento comprometida')
    return FileResponse(path,filename=doc['filename'],media_type='application/octet-stream')
